# 与后半部分编排器对接

> 上游：ReqRound 需求快照（本项目）　｜　下游：IdeaFlow 单 Agent 编排器（合作同学项目）
>
> 依据：合作项目 `python/agent.py`、`README.md`、`json/contract_package_v1.1.json` 的逐行核对（行号指该项目源文件）。

## 1. 结论先行

推荐 **方案 B：上游直接生成 tasks，POST 给 `/api/start`**。

- 编排器只保留 6 个任务字段：`task_id / name / deliverable / acceptance_items / suggested_role / priority`；
- 其余字段（`description / spec_refs / source / estimate_days`）会被**静默丢弃**；
- 完整来源引用保留在我们的 `handoff.json` 与快照库中，任务名带 `REQ-xxx`，用 `task_id` 作为跨系统外键；
- `POST /api/start` 同步、只能成功一次；客户端超时建议 ≥ 240s，409 必须读 `error` 文案。

`handoff_orchestrator.json` 就是可直接投递的包：

```json
{
  "schema_version": "1.1",
  "spec_id": "SNP-20261120143908-xxxx",
  "spec_version": "v1.0",
  "list_version": "v1.0",
  "review_status": "approved",
  "generated_by": "reqround",
  "created_at": "2026-11-20T14:39:08+08:00",
  "tasks": [
    {
      "task_id": "T1",
      "name": "设备台账增删改查与字段维护（REQ-001）",
      "deliverable": "设备台账增删改查与字段维护功能实现",
      "acceptance_items": ["新增一台设备后可按设备编号查询到该记录"],
      "suggested_role": "ai",
      "priority": "high"
    }
  ]
}
```

## 2. 下游接口事实

### 2.1 启动

```powershell
py -3 python/agent.py serve --host 127.0.0.1 --port 8000 --out output/chat_miniapp
```

- 纯标准库 HTTP 服务；`--mock` 可跳过模型依赖分析；
- 启动不读任务文件、不自动开始，只有 `POST /api/start` 后才建图；
- 重复 `POST /api/start` 返回 **409**，无 reset 接口，重跑只能重启进程。

### 2.2 `/api/start` 接受的输入

| 形态 | 触发条件 | 处理 |
| --- | --- | --- |
| `{"requirement": "一句话"}` | 无 `tasks` 且 `requirement` 非空 | 调模型拆 5-12 个任务 |
| 契约包 | 顶层含 `task_list_approved_v1.2` | 只取该子对象的 `tasks/spec_version/list_version` |
| `{"tasks":[...]}` | dict 且无 approved 键 | 直接当作任务清单 |
| 纯任务数组 | JSON array | 直接当作任务清单 |

任务字段处理（`agent.py:76-83`）：

| 字段 | 默认 | 说明 |
| --- | --- | --- |
| `task_id` | `T{index+1}` | 重复直接 400；建议由上游显式给 |
| `name` | `""` | 不校验非空；下游依赖分析只能看到 6 字段，必须自解释 |
| `deliverable` | `""` | 产物名，不是动作 |
| `acceptance_items` | `[]` | 必须是字符串数组；传字符串会被 `list("abc")` 拆成字符 |
| `suggested_role` | `"ai"` | `"human" in role` 即视为人工门；**不要写 `ai+human`** |
| `priority` | `"medium"` | `high/medium/low`，只影响队列顺序 |
| 其他字段 | — | 全部丢弃 |

### 2.3 返回与事件

- `POST /api/start` 返回 `{"accepted": true, "progress": {...}}`，**没有 edges**；
- 依赖边要再调 `GET /api/progress`；
- `POST /api/events` 返回 **202**，但 202 只代表入队，业务错误写 `last_error`，必须轮询 `progress` 确认；
- `GET /api/progress?since=N&limit=200` 返回状态 + `event_log`；`since` 是 seq 不是下标。

## 3. 两种对接方案

### 方案 A：只 POST 一段需求摘要

```json
{"requirement": "项目：高校实验室设备预约管理系统。以下是需求快照 v1.0……[REQ-001]……”}
```

优点：最省事，交给下游 PM Agent 拆解。

缺点：

- 上游的编号、来源、验收要点只能作为自然语言提示，不能保证被保留；
- 同一段文本两次拆解结果不同，不可复现；
- 下游任务与需求条款没有稳定外键，审计断链；
- 只适合演示/口头需求，不适合作为交付基线。

### 方案 B：上游生成 6 字段 tasks（推荐）

`handoff.py` 的 `to_orchestrator_payload()` 生成：

- 一条 REQ → 一条 AI 实现任务；任务名保留 `（REQ-xxx）`；
- 一条约束核验任务（human）；
- 一条需求验收与范围签收任务（human）；
- `acceptance_items` 取自快照的验收要点；
- 额外字段 `source_req_ids / source_citations` 保留在 `handoff.json`，下游丢弃但可用于回查。

优点：可复现、可追溯、任务与快照有稳定外键；缺点：任务粒度较粗，依赖关系仍由下游模型重算。

### 混合建议

1. 用方案 B 投递任务，拿到 `progress` 后核对 `total` 与 `task_id` 集合；
2. 若必须锁定依赖图：`start` 后再发一个 `change` 包，带完整 `tasks` + `edges` 整图覆盖（该路径不调模型）；
3. 下游执行时用 `task_id` 回查我们的 `handoff.json` 取来源引用。

## 4. 已知坑与规避

| 坑 | 规避 |
| --- | --- |
| `start` 同步持锁、最多 2×90s 模型调用，期间 `progress` 也会阻塞 | 客户端超时 ≥ 240s；不要重复 POST；用 `/api/health` 轻量探活 |
| 409 同时表示“重复启动”和“模型失败” | 读 `error` 文案区分；把“已投递”当成功，不要盲目重发 |
| 500 可能没有 JSON（缺 matplotlib 等） | 客户端按“无响应体”兜底；先确认 `/api/health` |
| `ai+human` 会被当成纯人工门 | 拆成 AI 任务 + human 任务 + force 边 |
| `acceptance_items` 传字符串会拆字符 | 永远传数组 |
| `change` 带 tasks 但漏 edges 会变成全并行 | 整图覆盖必须同时给 `tasks` 与 `edges` |
| `reopen` 只恢复 blocked/failed，且要连上游一起列 | 恢复下游时把上游阻塞任务一并列入 |
| 事件重启后 `event_log` 清空但 seq 续增 | 完整历史读 `events.jsonl`，不要只依赖内存事件 |
| 一次实例只能 start 一次 | 演示前重启进程；或每次新建实例目录 |

## 5. 对接验证步骤

```powershell
# 1. 启动上游
cd G:\DeepSeek工程\reqround
py -3 run.py serve --port 8770

# 2. 启动下游（建议先 --mock，避免模型额度影响）
cd path\to\ideaflow_orchestrator
py -3 python/agent.py serve --host 127.0.0.1 --port 8000 --mock --out output\reqround_test

# 3. 用上游网页的「推送编排器」按钮，或直接 POST
$json = Get-Content G:\DeepSeek工程\reqround\examples\lab_booking\handoff_orchestrator.json -Raw -Encoding UTF8
Invoke-RestMethod -Uri "http://127.0.0.1:8000/api/start" -Method Post `
  -ContentType "application/json; charset=utf-8" `
  -Body ([System.Text.Encoding]::UTF8.GetBytes($json)) -TimeoutSec 300

# 4. 核对
Invoke-RestMethod "http://127.0.0.1:8000/api/progress" | Select-Object status,total,done,analysis
```

通过标准：

- `accepted=true`；
- `progress.total` 等于 `handoff_orchestrator.json` 的 `tasks` 数；
- `progress.tasks[].task_id` 与本包一致；
- 人工门任务（约束核验、验收签收）出现且只有一个处于 waiting；
- 重复 POST 返回 409，且文案是“实例已启动，不能重复输入任务清单”。

## 6. 需要下游配合的字段

如果合作同学愿意扩展 `normalize_tasks`，建议保留两个字段（当前会被丢弃）：

```python
"source_req_ids": item.get("source_req_ids") or [],
"source_snapshot": item.get("source_snapshot") or "",
```

这样任务卡可直接回指 `REQ-001 / v1.0`，评审时能逐条对照。若暂不扩展，任务名里的 `（REQ-xxx）` 是当前可用的追溯锚点。

## 7. 实测结果（2026-11-20）

在本地把合作项目复制到 `.integration/ideaflow/`，用 `--mock` 启动下游：

```powershell
py -3 python/agent.py serve --host 127.0.0.1 --port 8001 --mock --out output\reqround_test
```

投递 `examples/lab_booking/handoff_orchestrator.json` 后：

- `accepted=true`，`progress.total=13`，`status=running`；
- 13 个任务按 mock 规则串行分成 13 层；
- `task_id` 与上游完全一致，人工门 T12/T13 被识别为 `human`；
- 再次 POST 返回 409：`{"error": "实例已启动，不能重复输入任务清单"}`；
- 下游生成 `runtime_state.json`、`event_stream_example.json`、`events.jsonl`、`task_flow.png`。

一个观察：下游 `progress` 里的 `acceptance_items` 是**空格拼接的字符串**（其 `snapshot()` 的展示逻辑），而 `runtime_state.json` 内仍是数组。若下游要继续消费数组，应读 `runtime_state.json` 或扩展接口，不要依赖 `progress` 里的字符串形态。

## 8. 反向数据流（可选）

下游执行完成后，可把每个任务的：

- `task_id`
- `result`（done/failed）
- `deliverable` 路径
- `acceptance_items` 的实际结果

回写成 `reqround.handoff.result.v1`，与快照的 `REQ` 编号对齐，形成“需求 → 任务 → 验收”的闭环。本项目暂未实现，接口位置预留在 `handoff.py`。
