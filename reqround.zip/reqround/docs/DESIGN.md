# ReqRound 设计说明

> 版本：v1.0　｜　对应实现：`reqround/` 包与 `run.py`　｜　演示运行：`R-20261120-143847-e3e7`

## 1. 目标与边界

### 1.1 目标

把用户的一段原始输入，经过**多 Agent 多轮讨论**，整理成一份：

1. 带稳定编号（REQ/CON/OQ/OOS/DEC）；
2. 带版本（v0.1 … v1.0）且旧版本只读；
3. 区分明确要求、约束、待澄清项；
4. 每条都能回溯到原文逐字引用；
5. 可直接交给下游任务分解/编排器的需求快照。

### 1.2 不做的事

- 不生成技术方案或代码（那是“独立出案”和后续阶段）；
- 不做通用代码生成、部署、多租户；
- 不用模型自述替代程序校验：覆盖率、引用有效性、门禁全部由 Python 计算；
- 不追求“一次输出完美需求”，而是通过轮次、澄清和版本迭代收敛。

## 2. 角色设计：4 位讨论者 + 1 位主持人

| 角色 | 关注点 | 典型产出 |
| --- | --- | --- |
| 需求分析师 | 覆盖、范围、优先级、可验收 | REQ、OOS、验收要点 |
| 架构评审 | 可实现性、非功能、集成、边界 | CON、技术风险、OQ |
| 验收测试 | 可测试性、边界、异常、口径 | OQ、验收补充 |
| 用户代言人 | 用户目标、场景、采纳成本、过度设计 | OQ、OOS、价值判断 |
| 主持人 / 规格员 | 合并、裁决、落库、收敛判断 | ops、轮次摘要、DEC |

为什么是 4 位：

- 四个立场覆盖“业务要求 / 技术约束 / 可验收性 / 用户价值”，这是需求评审最容易互相打架的四面；
- 再增加角色会产生大量重复提案，边际收益低；
- 主持人独立，不参与讨论，避免“运动员兼裁判”，也让“讨论文本”和“正式规则”分离。

隔离规则：

- R1：4 位 Agent **互不可见**，只读原文，减少锚定；
- R2 起：只看到当前快照、上一轮**未解决的 blocking 发现**、人类澄清与主持人聚焦建议，不直接传其他 Agent 的全文；
- 每次调用的 `context_manifest` 记录可见的段、条目、发现、澄清 ID，便于审计。

## 3. 轮次协议

### 3.1 默认四轮

```text
R1 独立发散 → v0.1
R2 交叉质询 → v0.2
R3 聚焦收敛 → v0.3
   │
   ├─ 有 blocking OQ 且未到上限 → 暂停，等待人工澄清
   └─ 无 blocking 或选择自动假设 → 继续
R4 定稿签署 → v0.4 候选
   │
人工批准 → v1.0
```

| 轮次 | 模式 | 讨论者任务 | 主持人任务 |
| --- | --- | --- | --- |
| 1 | `diverge` | 独立通读，尽量覆盖原文，不受其他角色影响 | 从零建立 v0.1：合并提案、补全要求/约束/待澄清 |
| 2 | `challenge` | 挑战当前快照与上一轮阻塞发现，补验收、找冲突 | 增量修订、补齐来源、合并同主题条目 |
| 3 | `converge` | 把模糊点收敛为 OQ 或明确假设，减少新增 | 补验收要点、合并同主题 OQ、判断是否可提前收敛 |
| 4 | `finalize` | 只列仍阻塞的问题并投票（accept / accept_with_comments / reject） | 落库人类澄清；无人回答的 blocking 写默认假设并标注 |

### 3.2 轮数上限

- 默认 `max_rounds=4`，硬上限 `6`（配置 `Settings.max_rounds_cap`）。
- 理由：实测 4 轮已覆盖“发散—质询—收敛—签署”；第 5/6 轮主要处理返工或重大变更，不应默认开启。
- 提前收敛：若在某轮后已无 blocking、覆盖率/验收/引用达标，且主持人判断收敛，可直接进入待批准，节省轮次。

### 3.3 澄清门

默认在第 `max_rounds - 1` 轮后设澄清门：

- 若仍有 `blocking` 且无人回答，运行状态置 `paused`，网页澄清台列出问题；
- 人工回答后 `continue`，进入定稿轮；
- 若选择 `--auto-assume`，不暂停，定稿轮由主持人给默认假设，条目上明确标 `answer_source=assumption`，不计为用户确认。

### 3.4 状态机

```text
created → running → paused → running → awaiting_approval → approved
                    │                      │
                    ├→ failed ←────────────┘（可 retry 复用发言）
                    └→ stopped
```

- `running`：轮次进行中；同一运行只允许一个推进线程。
- `paused`：等待人工澄清，可回答、可继续（带已有回答或默认假设）。
- `awaiting_approval`：定稿候选已生成，等待人批准。
- `approved`：v1.0 基线，只读。
- `failed`：主持人/全部 Agent 失败；`retry_failed_round` 可复用已保存发言，只重跑综合。
- `stopped`：人工停止。

## 4. 数据模型

### 4.1 快照顶层

```json
{
  "schema": "reqround.snapshot.v1",
  "snapshot_id": "SNP-20261120143908-xxxx",
  "version": "v1.0",
  "parent_version": "v0.4",
  "status": "approved",
  "round": 4,
  "max_rounds": 4,
  "project": {"project_id": "PRJ-...", "title": "...", "summary": "...", "domain": "MIS"},
  "source": {
    "source_id": "SRC-001",
    "sha256": "...",
    "sha256_short": "5cc71c99b42c",
    "segment_count": 46,
    "segments": [
      {"seg_id": "S-001", "text": "...", "start": 0, "end": 24, "kind": "heading|content"}
    ]
  },
  "items": [],
  "counters": {"REQ": 11, "CON": 6, "OQ": 13, "OOS": 0, "DEC": 0},
  "coverage": {"total": 43, "covered": 43, "rate": 1.0, "uncovered": [], "mapping": {}},
  "metrics": {},
  "quality": {"passed": true, "gates": {}, "issues": []},
  "round_summaries": [],
  "ignored_segments": [],
  "clarifications": [],
  "approval": {"by": "课程验收组", "note": "...", "at": "..."}
}
```

### 4.2 条目

```json
{
  "id": "REQ-001",
  "type": "requirement",
  "title": "设备台账增删改查与字段维护",
  "statement": "系统应支持设备台账的新增、查询、修改、删除，覆盖……",
  "priority": "must",
  "origin": "explicit",
  "status": "active",
  "sources": [
    {"kind": "input_span", "seg_id": "S-008", "quote": "设备台账要能维护……", "start": 303, "end": 380, "valid": true}
  ],
  "acceptance": ["新增一台设备后可按设备编号查询到该记录", "……"],
  "category": null,
  "blocking": false,
  "suggested_assumption": null,
  "assumption": null,
  "answer": null,
  "answer_source": null,
  "related": ["OQ-003"],
  "revision": 2,
  "fingerprint": "9f3c…",
  "created_round": 1,
  "updated_round": 2,
  "history": [
    {"version": "v0.2", "round": 2, "action": "modified", "by": "moderator", "fields": ["acceptance"], "at": "..."}
  ],
  "citation_ok": true
}
```

设计要点：

- **`sources` 是事实来源**：`input_span` 指向原文段，`discussion` 指向某轮某 Agent 的发言；程序逐条校验 quote 是否出现。
- **`suggested_assumption` 不等于 `assumption`**：前者是讨论中的建议默认值；后者是主持人/人类正式采纳的假设，只有 `answer_question` op 才能写入。
- **`status`**：`active` / `superseded` / `rejected`；合并用 `superseded_by` 指向替代条目。
- **`revision` 与快照版本分离**：`revision` 是条目自身被改的次数，用于审计；版本号是整份快照的。
- **`fingerprint`**：规范化文本（去空白/统一标点）的哈希，用于判断“同一条目是否只是换行/标点变化”。

### 4.3 类型语义

| 类型 | 前缀 | 判定标准 | 必须有 |
| --- | --- | --- | --- |
| requirement | REQ | 用户明确提出、系统应做到的功能 | 来源 + 至少一条可判定验收 |
| constraint | CON | 技术/业务/合规/质量/工期/成本限制 | 来源 + 类别 |
| open_question | OQ | 原文缺失、冲突、口径不明 | why + blocking + 选项/建议默认值 |
| out_of_scope | OOS | 明确不做或讨论判定首版不做 | 来源 |
| decision | DEC | 讨论中达成的裁决（可选） | 理由 + 关联 |

## 5. 版本、编号与变更

### 5.1 版本规则

- 轮次快照：`v0.{round}`；若同轮重复综合，用 `v0.{round}.2` 等后缀。
- 批准基线：`v1.0`，`parent_version` 指向候选版本（如 `v0.4`）。
- 旧版本文件不可覆盖；`latest.json` 只是副本，失败时仍可从版本文件恢复。
- 每版保存：
  - `snapshots/vX.Y.json`
  - `documents/需求快照_vX.Y.md`
  - `documents/变更_vX.Y.md`（相对上一版的 diff）
  - `events.jsonl` 追加事件

### 5.2 编号分配

- 类型前缀 + 三位序号：`REQ-001`、`CON-001`、`OQ-001`、`OOS-001`、`DEC-001`。
- 编号由 `counters` 单调分配，永不复用。
- 合并/删除不释放编号；旧条目保留 `status=superseded` 与 `superseded_by`。
- 新条目在 ops 中不写 id，由 `apply_ops` 分配，避免模型伪造/改号。

### 5.3 变更记录

`diff_snapshots(old, new)` 输出：

- `added` / `modified` / `answered` / `assumed` / `superseded` / `removed`；
- 每条变化的字段、摘要；
- 每轮摘要里记录 `ops` 计数与被拒绝的 op 原因。

这样可以回答三个问题：**哪一版改了什么、为什么改、谁改的**。

## 6. 来源引用与覆盖率

### 6.1 逐字引用

- 输入先按句切段，保留 `start/end` 字符偏移；标题识别为 `kind=heading`，不计入覆盖率。
- 模型必须输出 `{"kind":"input_span","seg_id":"S-008","quote":"……"}`；
- `verify_input_source` 依次尝试：
  1. quote 在对应段内逐字匹配；
  2. 带省略号的分段匹配；
  3. 全文定位并换算回所属段；
  4. 去空白后的宽松匹配。
- 失败则 `valid=false`，计入引用有效率，并在条目上标 `citation_ok=false`。
- 讨论引用同样校验：必须在某轮某 Agent 的发言文本中逐字出现。

### 6.2 覆盖率

- 分母 = 所有 `kind=content` 的原文段；
- 分子 = 至少被一条 **active** 条目的有效 `input_span` 引用的段；
- 寒暄/背景可用 `ignore_segment` 显式说明忽略，计入覆盖；
- 标题行不计入；未覆盖段在追踪矩阵中标红。

### 6.3 为什么不用行号

行号是位置派生的：在前面插入一句，后续行号全漂移。本项目用**段 ID + 字符偏移 + 原文哈希**：

- `seg_id` 在单次运行内稳定；
- `start/end` 是当时原文的坐标，用于前端高亮；
- `sha256` 标识整份原文，防止“换了一份输入还对旧引用”。

## 7. 综合：ops 而不是整份重写

主持人每轮输出：

```json
{
  "summary": "本轮综合结论",
  "project_summary": "仅第一轮填",
  "ops": [
    {"op": "add_item", "item": {...}},
    {"op": "update_item", "id": "REQ-001", "patch": {"acceptance": ["..."]}},
    {"op": "supersede_item", "id": "OQ-004", "superseded_by": "OQ-001"},
    {"op": "answer_question", "id": "OQ-001", "answer": "...", "answer_source": "user|assumption"},
    {"op": "link", "id": "REQ-001", "add_related": ["OQ-001"]},
    {"op": "ignore_segment", "seg_id": "S-012", "reason": "背景说明"},
    {"op": "set_project_summary", "summary": "..."}
  ],
  "next_focus": ["..."],
  "converged": false,
  "convergence_reason": "..."
}
```

`apply_ops` 的确定性规则：

- 只允许已知 op；未知 op 拒绝并记录原因；
- 新增条目校验类型、必填字段、来源有效性、同类型同标题重复；
- 更新只允许白名单字段；不允许改 id/type/created_round/history；
- 合并只做 `supersede`，不物理删除；
- 单条 op 失败不影响整轮；拒绝原因进入 `round_summaries.rejected_ops` 与事件流。

为什么不直接让模型输出完整快照：

- 完整重写会丢条目、改编号、无法判断“这条是新增还是改写”；
- 大 JSON 容易被截断（真实调试中确实发生过 `finish_reason=length`）；
- ops 可逐条校验、逐条重放，适合审计与回滚。

## 8. 质量门禁与收敛

### 8.1 门禁

由 `finalize_snapshot` 计算：

| gate | 计算 | 阈值 |
| --- | --- | --- |
| coverage | 有效引用覆盖的内容段 / 内容段总数 | ≥ 0.90 |
| citation | 有效来源 / 全部来源 | ≥ 0.90 |
| acceptance | 有验收要点的 REQ / REQ 总数 | = 1.00 |
| requirement_sourced | 有原文来源的 REQ / REQ 总数 | ≥ 0.90 |
| no_duplicates | 同类型同标题条目数 | = 0 |
| blocking_resolved | 无回答且无采纳假设的 blocking OQ | = 0 |

### 8.2 收敛判定

`convergence = 无 blocking OQ + 无 reject 票 + 门禁通过 +（定稿轮 或 主持人判断收敛）`

- 主持人 `converged` 只是建议，最终由程序复核；
- 定稿轮必须有 4 位 Agent 的 vote（允许部分 Agent 缺席，但会记录）；
- 若门禁不过，仍可进入 `awaiting_approval`，但批准时需要显式 `accept_open`。

## 9. 人工介入

- **澄清台**：把阻塞 OQ 展示为问题卡，可填答案或采用建议默认值；
- **回答不直接改快照**：先记为 run 级 clarification；下一轮主持人用 `answer_question` 落库，避免“人一改就悄悄变版本”；
- **批准**：批准前把未落库的回答确定性落库（不调模型），再生成 v1.0；
- **带风险批准**：仍有阻塞项时必须勾选 `accept_open`，v1.0 状态为 `approved_with_open_questions`，文档保留未决项。

## 10. 失败、重试与降级

### 10.1 Agent 失败

- 每个 Agent 最多 3 次（`llm_max_attempts`），网络/5xx/429 重试；4xx 不重试；
- 单个 Agent 失败不拖垮整轮：其他发言照常综合，失败角色在轮次摘要中标 `failed`；
- 下一轮该角色可再次参与；如果持续失败，最终文档记录“本轮缺席”。

### 10.2 主持人失败

- 主持人输出截断/JSON 无效会重试；仍失败则整轮失败；
- `retry_failed_round` 复用已保存的 Agent 发言，**只重跑主持人**，避免重新花 4 次 Agent 调用；
- 该能力在真实调试中救回过一次因 `finish_reason=length` 中断的运行。

### 10.3 离线降级

- `--local-moderator`：Agent 可走真实模型，综合用 `localmod.py` 的确定性规则；
- `--local`：Agent 与综合都用本地规则（不访问网络）；
- `--replay`：回放一次真实运行的 Agent 发言，未录制轮次退回本地 Agent；
- 所有降级路径共用同一套版本、引用校验、门禁与文档渲染，不会产生“另一套格式”。

`localmod.py` 的规则不是随机假数据：

1. 先吸收 Agent 真实提案（去重、补验收/来源）；
2. 把未覆盖的原文句按“问句/约束/背景/功能句”分类补成 OQ/CON/REQ，或显式忽略背景；
3. R2 起合并同主题 OQ、补齐验收要点；
4. 定稿轮把仍阻塞的问题落成默认假设（若无人回答）；
5. 每一步都产出标准 ops，仍受 `apply_ops` 校验。

## 11. Prompt 设计

- 系统提示词固定“铁律”：只能依据原文、必须逐字引用、不得替用户做价值判断、拿不准写成 OQ；
- 每个角色有独立视角与输出上限（发现/提案各 5 条），避免无限发散；
- 主持人有额外“输出预算”：ops ≤ 16、statement ≤ 120 字、同主题合并；
- 失败重试时把错误信息回填给模型（“你上次输出无法使用：……”），要求只输出修正后的 JSON；
- 模型调用参数：`response_format=json_object`、低温度（主持人 0.15，讨论者 0.45 左右）、明确的 `max_tokens`；
- 所有调用记录 `usage`（含 reasoning tokens，如服务返回）与耗时，便于成本分析。

## 12. 并发、存储与安全

- `ThreadingHTTPServer` + 每轮 `ThreadPoolExecutor` 并行 4 位 Agent；
- 每个 run 一个目录，JSON 写入用临时文件 + `os.replace` 原子替换；
- `run.json` 读改写由 per-run `RLock` 保护；事件流 `events.jsonl` 追加写；
- 网页与 API 默认只绑定 `127.0.0.1`，无鉴权；
- `.env` 保存模型 Key，已被 `.gitignore` 排除；运行产物默认在 `runs/`，同样不提交。

## 13. 下一阶段：A/B 独立出案

本模块只负责“需求快照”，但已经为“两个方案存在实际取舍、一组失败后可单独重试”预留了契约：

1. **快照引用**：下游用 `{snapshot_id, version}` 绑定本轮需求；快照不可变，保证 A/B 看到同一份输入。
2. **条款级引用**：每个方案主张必须带 `requirement_ids`（指向 REQ/CON），可校验是否引用了未登记需求。
3. **独立上下文**：A/B 两组各自只读快照 + 自己的提示词，不共享草案；失败组只重跑自己。
4. **评审与决策**：对 A/B 的评分必须引用具体 claim；人工只能通过决策关闭未决项，模型不得自行“合并掉”争议。
5. **版本**：方案版本与需求快照版本分开；需求快照 revision 与方案 revision 分开，避免“改一个标点全量重评”。

这些约束与本模块的 `REQ/CON/OQ` 编号、来源引用、版本冻结直接兼容。

## 14. 参考项目的借鉴与规避

参考：[Anjin001/SE-Development-Process-Agent](https://github.com/Anjin001/SE-Development-Process-Agent)。

借鉴：

- 引用必须可回原文、且由程序校验；
- 内容版本与修订号分离、确认后不可覆盖；
- 全覆盖闸门（每条需求必须落到决策或未决项）；
- 失败按组隔离、只重跑失败组；
- 未决项是一等公民（blocking / options / resolution）。

规避：

- 不用位置派生 ID（插入一句后编号全漂移）；
- 不用“新版本整份重写、新开项目”的方式做迭代；
- 不用关键词特判假装通用冲突识别；
- 不把“确认”建立在自由文本逐字相等上。

详见 [`COMPARISON.md`](COMPARISON.md)。

## 15. 局限

- 语义质量依赖模型；本地规则只保证流程与格式，不保证需求洞察。
- 网页无鉴权、无多用户隔离，适合单机演示/课程项目。
- 并发为单机线程；没有分布式调度与幂等键。
- 没有实现“模型投票自动裁决”；最终批准始终保留人工门。
- 对超长输入（>20 万字符）会直接拒绝，未做分片。
