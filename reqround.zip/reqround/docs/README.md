# 文档索引

| 文档 | 内容 | 适合谁看 |
| --- | --- | --- |
| [`../README.md`](../README.md) | 项目定位、快速开始、四轮协议、API、测试 | 第一次接触项目的人 |
| [`DESIGN.md`](DESIGN.md) | 角色、轮次、数据模型、版本、ops、门禁、失败恢复、A/B 扩展点 | 想评审设计/答辩的人 |
| [`DEMO.md`](DEMO.md) | 实验室预约案例的四轮演化、两个真实取舍、三分钟演示脚本 | 演示者、评审老师 |
| [`INTEGRATION.md`](INTEGRATION.md) | 与后半部分编排器的 6 字段契约、409/超时/ai+human 坑、实测结果 | 合作同学、集成者 |
| [`COMPARISON.md`](COMPARISON.md) | 与参考项目的对照：学到的 5 点、刻意规避的 5 点 | 关心“有没有抄”的人 |
| [`需求快照_高校实验室设备预约管理系统_v1.0.docx`](需求快照_高校实验室设备预约管理系统_v1.0.docx) | Word 版最终需求文档（15 页） | 交作业/评审 |
| [`screenshots/ui-discussion.png`](screenshots/ui-discussion.png) | 圆桌讨论页截图 | 答辩 PPT |
| [`screenshots/ui-snapshot.png`](screenshots/ui-snapshot.png) | 需求快照页截图 | 答辩 PPT |

## 建议阅读顺序

1. README 第 1–5 节：知道它解决什么问题、怎么跑、案例结果；
2. DEMO：看四轮怎么演化、两个真实取舍；
3. DESIGN：看数据模型、版本与门禁、失败恢复；
4. INTEGRATION：看和后半部分怎么接；
5. COMPARISON：看与参考项目的关系。
