from __future__ import annotations

import json
import shutil
import sys
import unittest
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from reqround.config import Settings  # noqa: E402
from reqround.intake import build_source, verify_input_source  # noqa: E402
from dataclasses import replace  # noqa: E402

from reqround.llm import LocalClient, MockClient, ReplayClient, ScriptedClient  # noqa: E402
from reqround.model import (  # noqa: E402
    apply_ops,
    diff_snapshots,
    finalize_snapshot,
    new_snapshot,
)
from reqround.orchestrator import Orchestrator  # noqa: E402
from reqround.store import RunStore  # noqa: E402

CASE = """实验室要做一个设备预约系统，支持设备台账和按时间段预约。
系统要避免同一设备同一时段被重复预约。
必须部署在校内网，并满足 12 周工期。
预约冲突时谁优先，目前没有明确。
首版不做收费，以后再说。"""


def source_item(seg_id: str, quote: str) -> dict:
    return {"kind": "input_span", "seg_id": seg_id, "quote": quote}


def agent_response(findings=None, items=None, vote=None, stance="完成"):
    data = {"stance": stance, "findings": findings or [], "proposed_items": items or [], "notes": ""}
    if vote:
        data["vote"] = vote
    return data


def moderator_response(ops, summary="本轮综合", converged=False, focus=None, summary_project=None):
    return {
        "summary": summary,
        "project_summary": summary_project,
        "ops": ops,
        "next_focus": focus or [],
        "converged": converged,
        "convergence_reason": "测试脚本",
    }


def build_script():
    s = CASE.splitlines()
    req1 = {
        "type": "requirement",
        "title": "设备预约",
        "statement": "系统应支持设备台账与按时间段预约。",
        "priority": "must",
        "origin": "explicit",
        "acceptance": ["可按设备查看空闲时段并提交预约"],
        "sources": [source_item("S-001", s[0])],
    }
    req2 = {
        "type": "requirement",
        "title": "冲突检测",
        "statement": "系统应避免同一设备同一时段被重复预约。",
        "priority": "must",
        "origin": "explicit",
        "acceptance": ["同一设备同一时段第二次提交被拒绝"],
        "sources": [source_item("S-002", s[1])],
    }
    con = {
        "type": "constraint",
        "title": "校内网与工期",
        "statement": "系统必须部署在校内网，并在 12 周内交付首版。",
        "priority": "must",
        "origin": "explicit",
        "category": "technical",
        "sources": [source_item("S-003", s[2])],
    }
    oq = {
        "type": "open_question",
        "title": "冲突优先级",
        "statement": "预约冲突时按什么规则决定谁优先？",
        "priority": "must",
        "origin": "explicit",
        "blocking": True,
        "why": "影响冲突检测与审批规则",
        "options": ["教师优先", "先到先得"],
        "assumption": "先到先得，教师可申诉",
        "sources": [source_item("S-004", s[3])],
    }
    oos = {
        "type": "out_of_scope",
        "title": "收费",
        "statement": "首版不做收费功能。",
        "priority": "wont",
        "origin": "explicit",
        "sources": [source_item("S-005", s[4])],
    }
    r1_ops = [
        {"op": "add_item", "item": req1, "reason": "明确要求"},
        {"op": "add_item", "item": req2, "reason": "明确要求"},
        {"op": "add_item", "item": con, "reason": "明确约束"},
        {"op": "add_item", "item": oq, "reason": "原文歧义"},
        {"op": "add_item", "item": oos, "reason": "明确不做"},
    ]
    script = {
        ("analyst", 1): agent_response(items=[req1, req2]),
        ("architect", 1): agent_response(items=[con]),
        ("qa", 1): agent_response(
            findings=[
                {
                    "kind": "ambiguity",
                    "target_id": "REQ-002",
                    "statement": "冲突优先级未定义",
                    "why_it_matters": "会导致同一时段争议",
                    "severity": "blocking",
                    "proposal": "请用户明确",
                    "question": "教师优先还是先到先得？",
                    "sources": [source_item("S-004", s[3])],
                }
            ],
            items=[oq],
        ),
        ("user", 1): agent_response(items=[oos]),
        ("moderator", 1): moderator_response(
            r1_ops, summary="建立 v0.1：2 条要求、1 条约束、1 个阻塞问题、1 项范围外",
            summary_project="面向校内实验室的设备台账与分时预约系统。",
            focus=["澄清冲突优先级", "补齐验收要点"],
        ),
        ("analyst", 2): agent_response(vote="accept"),
        ("architect", 2): agent_response(vote="accept"),
        ("qa", 2): agent_response(vote="accept"),
        ("user", 2): agent_response(vote="accept"),
        ("moderator", 2, "finalize"): moderator_response(
            [
                {
                    "op": "answer_question",
                    "id": "OQ-001",
                    "answer": "先到先得，教师可申诉",
                    "answer_source": "assumption",
                    "assumption": "先到先得，教师可申诉",
                    "reason": "定稿轮无人回答，落默认假设",
                }
            ],
            summary="定稿：以默认假设关闭冲突优先级问题",
            converged=True,
        ),
        ("moderator", 2, "converge"): moderator_response(
            [], summary="收敛轮：保留冲突优先级问题等待人工澄清", focus=["冲突优先级"],
            converged=False,
        ),
        ("analyst", 3): agent_response(vote="accept"),
        ("architect", 3): agent_response(vote="accept"),
        ("qa", 3): agent_response(vote="accept"),
        ("user", 3): agent_response(vote="accept"),
        ("moderator", 3): moderator_response([], summary="定稿签署", converged=True),
    }
    return script


def scripted_client():
    script = build_script()
    missing = []

    def responder(call):
        purpose = call.get("purpose", "")
        parts = purpose.split(":")
        role = parts[0] if parts else ""
        try:
            round_no = int(parts[1][1:]) if len(parts) > 1 else 0
        except ValueError:
            round_no = 0
        mode = parts[2] if len(parts) > 2 else ""
        key = (role, round_no, mode)
        if key not in script:
            key = (role, round_no)
        if key not in script:
            missing.append(key)
            return {"stance": "missing", "findings": [], "proposed_items": []}
        return script[key]

    client = ScriptedClient(responder=responder)
    client.missing = missing
    return client


class IntakeTests(unittest.TestCase):
    def test_segment_offsets_and_headings(self):
        raw = "# 标题\n- 第一句要求。\n第二句要求？\n---\n"
        source = build_source(raw, "")
        self.assertEqual(source["title"], "标题")
        self.assertEqual([s["kind"] for s in source["segments"]], ["heading", "content", "content"])
        first = source["segments"][1]
        self.assertEqual(first["text"], "第一句要求。")
        self.assertEqual(raw[first["start"]:first["end"]], "第一句要求。")

    def test_verify_quote(self):
        source = build_source("系统应支持预约。必须保留三年。")
        good = verify_input_source({"seg_id": "S-001", "quote": "系统应支持预约。"}, source)
        self.assertTrue(good["valid"])
        bad = verify_input_source({"seg_id": "S-001", "quote": "系统应支持支付。"}, source)
        self.assertFalse(bad["valid"])
        loose = verify_input_source({"seg_id": "S-001", "quote": "系统应…预约"}, source)
        self.assertTrue(loose["valid"])


class SnapshotTests(unittest.TestCase):
    def setUp(self):
        self.source = build_source(CASE)
        self.snapshot = new_snapshot(self.source, "测试项目", "PRJ-T", 4)
        self.snapshot = finalize_snapshot(self.snapshot, self.source, version="v0.0")

    def test_add_update_answer_and_diff(self):
        req = {
            "type": "requirement",
            "title": "预约",
            "statement": "系统应支持预约。",
            "priority": "must",
            "origin": "explicit",
            "acceptance": ["可提交预约"],
            "sources": [source_item("S-001", "实验室要做一个设备预约系统，支持设备台账和按时间段预约。")],
        }
        snap1, applied, rejected = apply_ops(
            self.snapshot, [{"op": "add_item", "item": req}], self.source, 1, "v0.1"
        )
        self.assertEqual(len(applied), 1, rejected)
        self.assertEqual(snap1["items"][0]["id"], "REQ-001")
        self.assertEqual(snap1["items"][0]["fingerprint"], snap1["items"][0]["fingerprint"])
        snap2, applied, rejected = apply_ops(
            snap1,
            [{"op": "update_item", "id": "REQ-001", "patch": {"acceptance": ["可提交预约", "冲突时拒绝"]}}],
            self.source, 2, "v0.2",
        )
        self.assertEqual(len(applied), 1, rejected)
        self.assertEqual(snap2["items"][0]["revision"], 2)
        diff = diff_snapshots(snap1, snap2)
        self.assertEqual(diff["counts"].get("modified"), 1)
        finalize_snapshot(snap2, self.source, version="v0.2")
        self.assertEqual(snap2["coverage"]["rate"], 0.2)

    def test_duplicate_and_supersede(self):
        req = {
            "type": "requirement", "title": "预约", "statement": "系统应支持预约。", "priority": "must",
            "origin": "explicit", "sources": [source_item("S-001", "实验室要做一个设备预约系统，支持设备台账和按时间段预约。")],
        }
        snap1, _, _ = apply_ops(self.snapshot, [{"op": "add_item", "item": req}], self.source, 1, "v0.1")
        snap2, applied, rejected = apply_ops(snap1, [{"op": "add_item", "item": req}], self.source, 2, "v0.2")
        self.assertEqual(applied, [])
        self.assertIn("同名同类型条目已存在", rejected[0]["reason"])
        snap3, applied, _ = apply_ops(
            snap2,
            [{"op": "supersede_item", "id": "REQ-001", "superseded_by": None, "reason": "不再需要"}],
            self.source, 3, "v0.3",
        )
        self.assertEqual(snap3["items"][0]["status"], "superseded")
        finalize_snapshot(snap3, self.source, version="v0.3")
        self.assertEqual(snap3["metrics"]["requirements"], 0)


class OrchestratorTests(unittest.TestCase):
    def setUp(self):
        self.tmp_path = ROOT / ".tmp-tests" / uuid.uuid4().hex
        self.tmp_path.mkdir(parents=True, exist_ok=True)
        self.store = RunStore(self.tmp_path)
        self.settings = Settings(api_key="", max_rounds=4, runs_dir=self.tmp_path)

    def tearDown(self):
        shutil.rmtree(self.tmp_path, ignore_errors=True)

    def _create(self, max_rounds=2, auto_assume=True):
        client = scripted_client()
        engine = Orchestrator.create(
            self.store, self.settings, CASE, title="预约系统",
            client=client, max_rounds=max_rounds, auto_assume=auto_assume,
        )
        return engine, client

    def test_two_round_auto_and_approve(self):
        engine, client = self._create(max_rounds=2, auto_assume=True)
        engine.run_until_pause()
        self.assertFalse(client.missing, client.missing)
        state = engine.state()
        self.assertEqual(state["run"]["status"], "awaiting_approval")
        self.assertEqual(state["run"]["latest_version"], "v0.2")
        snapshot = engine.snapshot()
        self.assertEqual(snapshot["metrics"]["requirements"], 2)
        self.assertEqual(snapshot["metrics"]["constraints"], 1)
        self.assertEqual(snapshot["metrics"]["open_questions"], 1)
        self.assertEqual(snapshot["metrics"]["blocking_open"], 0)
        self.assertEqual(snapshot["coverage"]["rate"], 1.0)
        self.assertTrue(snapshot["quality"]["passed"], snapshot["quality"])
        approved = engine.approve(by="tester", note="测试批准")
        self.assertEqual(approved["version"], "v1.0")
        self.assertEqual(approved["status"], "approved")
        handoff = json.loads((self.store.path(engine.run_id, "handoff.json")).read_text(encoding="utf-8"))
        self.assertEqual(len(handoff["requirements"]), 2)
        self.assertTrue(handoff["tasks"])
        self.assertTrue((self.store.path(engine.run_id, "documents", "需求快照_v1.0.md")).exists())

    def test_pause_clarify_continue(self):
        engine, client = self._create(max_rounds=3, auto_assume=False)
        # 第 1 轮后 gate 未到；第 2 轮后应暂停
        engine.run_until_pause()
        self.assertFalse(client.missing, client.missing)
        state = engine.state()
        self.assertEqual(state["run"]["status"], "paused", state["run"].get("pause_reason"))
        self.assertEqual(state["run"]["round"], 2)
        self.assertEqual(len(state["open_questions"]), 1)
        record = engine.answer_question("OQ-001", "教师优先，需实名")
        self.assertEqual(record["oq_id"], "OQ-001")
        engine.continue_run()
        state = engine.state()
        self.assertEqual(state["run"]["status"], "awaiting_approval")
        snapshot = engine.snapshot()
        self.assertEqual(snapshot["version"], "v0.3")
        oq = next(i for i in snapshot["items"] if i["id"] == "OQ-001")
        self.assertEqual(oq["answer"], "教师优先，需实名")
        self.assertEqual(oq["answer_source"], "user")

    def test_retry_reuses_saved_agent_turns(self):
        script = build_script()
        script[("moderator", 1)] = {"__raise__": "模拟主持人输出截断", "retryable": False}

        def responder(call):
            purpose = call.get("purpose", "")
            parts = purpose.split(":")
            role = parts[0] if parts else ""
            round_no = int(parts[1][1:]) if len(parts) > 1 else 0
            mode = parts[2] if len(parts) > 2 else ""
            key = (role, round_no, mode)
            if key not in script:
                key = (role, round_no)
            if key not in script:
                return {"stance": "missing", "findings": [], "proposed_items": []}
            return script[key]

        client = ScriptedClient(responder=responder)
        engine = Orchestrator.create(
            self.store, self.settings, CASE, title="重试测试", client=client, max_rounds=2, auto_assume=True
        )
        engine.run_until_pause()
        self.assertEqual(engine.state()["run"]["status"], "failed")
        engine.settings = replace(engine.settings, local_moderator=True)
        snapshot = engine.retry_failed_round()
        self.assertEqual(snapshot["version"], "v0.1")
        self.assertTrue(snapshot["items"])
        self.assertEqual(engine.state()["run"]["status"], "running")

    def test_replay_client_matches_purpose_key(self):
        path = self.tmp_path / "replay.json"
        path.write_text(
            json.dumps({"entries": {"analyst:1:diverge": {"stance": "replay", "findings": [], "proposed_items": []}}}),
            encoding="utf-8",
        )
        client = ReplayClient(str(path))
        result = client.complete_json([], purpose="analyst:r1:diverge")
        self.assertEqual(result.data["stance"], "replay")

    def test_local_fallback_completes_with_full_coverage(self):
        settings = Settings(
            api_key="", max_rounds=2, runs_dir=self.tmp_path,
            local_agents=True, local_moderator=True,
        )
        engine = Orchestrator.create(
            self.store, settings, CASE, title="本地降级", client=LocalClient(),
            max_rounds=2, auto_assume=True,
        )
        engine.run_until_pause()
        state = engine.state()
        self.assertEqual(state["run"]["status"], "awaiting_approval")
        snapshot = engine.snapshot()
        self.assertGreaterEqual(snapshot["metrics"]["requirements"], 2)
        self.assertGreaterEqual(snapshot["coverage"]["rate"], 0.9)
        self.assertTrue(snapshot["quality"]["passed"], snapshot["quality"])
        self.assertEqual(snapshot["metrics"]["duplicate_titles"], 0)

    def test_agent_failure_does_not_kill_round(self):
        script = build_script()
        script[("architect", 1)] = {"__raise__": "模拟架构 Agent 超时", "retryable": False}
        missing = []

        def responder(call):
            parts = call.get("purpose", "").split(":")
            role = parts[0] if parts else ""
            round_no = int(parts[1][1:]) if len(parts) > 1 else 0
            mode = parts[2] if len(parts) > 2 else ""
            key = (role, round_no, mode)
            if key not in script:
                key = (role, round_no)
            if key not in script:
                missing.append(key)
                return {"stance": "missing", "findings": [], "proposed_items": []}
            return script[key]

        client = ScriptedClient(responder=responder)
        engine = Orchestrator.create(
            self.store, self.settings, CASE, title="失败降级", client=client, max_rounds=2, auto_assume=True
        )
        engine.run_until_pause()
        state = engine.state()
        self.assertEqual(state["run"]["status"], "awaiting_approval")
        failures = [
            e for e in self.store.read_events(engine.run_id)
            if e.get("type") == "agent_failed" and e.get("agent") == "architect"
        ]
        self.assertEqual(len(failures), 1)
        snapshot = engine.snapshot()
        self.assertEqual(snapshot["metrics"]["requirements"], 2)
        # 架构 Agent 失败，但主持人仍按其他角色提供的材料保留了约束，运行没有被拖垮
        self.assertEqual(snapshot["metrics"]["constraints"], 1)


if __name__ == "__main__":
    unittest.main()
