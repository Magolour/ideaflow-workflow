from __future__ import annotations

import json
import shutil
import sys
import threading
import time
import unittest
import urllib.error
import urllib.request
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from reqround.config import Settings  # noqa: E402
from reqround.server import App, Handler, Server  # noqa: E402

CASE = """实验室要做一个设备预约系统，支持设备台账和按时间段预约。
系统要避免同一设备同一时段被重复预约。
必须部署在校内网，并满足 12 周工期。
预约冲突时谁优先，目前没有明确。
首版不做收费，以后再说。"""


class HttpTests(unittest.TestCase):
    def setUp(self):
        self.tmp = ROOT / ".tmp-tests" / uuid.uuid4().hex
        self.tmp.mkdir(parents=True, exist_ok=True)
        settings = Settings(api_key="", runs_dir=self.tmp)
        self.app = App(settings)
        self.httpd = Server(("127.0.0.1", 0), Handler, self.app)
        self.port = self.httpd.server_address[1]
        self.thread = threading.Thread(target=self.httpd.serve_forever, daemon=True)
        self.thread.start()
        self.base = f"http://127.0.0.1:{self.port}"

    def tearDown(self):
        self.httpd.shutdown()
        self.httpd.server_close()
        shutil.rmtree(self.tmp, ignore_errors=True)

    def _request(self, method: str, path: str, body: dict | None = None):
        data = json.dumps(body or {}, ensure_ascii=False).encode("utf-8") if method == "POST" else None
        req = urllib.request.Request(
            self.base + path, data=data, method=method,
            headers={"Content-Type": "application/json; charset=utf-8"},
        )
        try:
            with urllib.request.urlopen(req, timeout=30) as response:
                raw = response.read().decode("utf-8")
                return response.status, json.loads(raw) if raw else None
        except urllib.error.HTTPError as exc:
            raw = exc.read().decode("utf-8", "replace")
            return exc.code, json.loads(raw) if raw else None

    def _get_text(self, path: str) -> str:
        with urllib.request.urlopen(self.base + path, timeout=30) as response:
            return response.read().decode("utf-8")

    def test_health_and_demo_case(self):
        status, data = self._request("GET", "/api/health")
        self.assertEqual(status, 200)
        self.assertEqual(data["status"], "ok")
        case_text = self._get_text("/api/demo-case")
        self.assertIn("实验室设备预约", case_text)

    def test_mock_run_end_to_end(self):
        status, created = self._request("POST", "/api/runs", {
            "input_text": CASE, "title": "HTTP 测试", "mock": True,
            "max_rounds": 2, "auto_assume": True,
        })
        self.assertEqual(status, 200, created)
        run_id = created["run_id"]
        deadline = time.time() + 40
        state = None
        while time.time() < deadline:
            status, state = self._request("GET", f"/api/runs/{run_id}")
            self.assertEqual(status, 200)
            if state["run"]["status"] in ("awaiting_approval", "approved", "failed"):
                break
            time.sleep(0.3)
        self.assertEqual(state["run"]["status"], "awaiting_approval", state["run"].get("error"))

        status, snapshot = self._request("GET", f"/api/runs/{run_id}/snapshot?version=latest")
        self.assertEqual(status, 200)
        self.assertTrue(snapshot["items"])
        self.assertEqual(snapshot["coverage"]["rate"], 1.0)

        doc = self._get_text(f"/api/runs/{run_id}/document?version=latest")
        self.assertIn("需求快照", doc)

        status, events = self._request("GET", f"/api/runs/{run_id}/events?since=0&limit=100")
        self.assertEqual(status, 200)
        self.assertTrue(events["events"])
        self.assertGreaterEqual(events["next_since"], 1)

        status, diff = self._request("GET", f"/api/runs/{run_id}/diff?from=v0.1&to=v0.2")
        self.assertEqual(status, 200)

        status, approved = self._request("POST", f"/api/runs/{run_id}/approve", {"by": "tester", "note": "http"})
        self.assertEqual(status, 200, approved)
        self.assertEqual(approved["snapshot"]["version"], "v1.0")

        status, handoff = self._request("GET", f"/api/runs/{run_id}/handoff")
        self.assertEqual(status, 200)
        self.assertTrue(handoff["tasks"])
        status, payload = self._request("GET", f"/api/runs/{run_id}/handoff?format=orchestrator")
        self.assertEqual(status, 200)
        self.assertEqual(set(payload["tasks"][0]), {"task_id", "name", "deliverable", "acceptance_items", "suggested_role", "priority"})

    def test_bad_run_id(self):
        status, data = self._request("GET", "/api/runs/not-a-run")
        self.assertIn(status, (400, 404))


if __name__ == "__main__":
    unittest.main()
