# ReqRound 需求圆桌

**把一段原始需求，谈成一份带编号、带版本、带来源引用的需求快照。**

ReqRound 是软件工程大作业「需求整理与独立出案」的前半部分：4 位立场不同的 Agent 先独立解读用户原话，再交叉质询、聚焦收敛，主持人把每一轮结论落成不可变的需求快照版本。人只在真正需要拍板的问题上介入；最终产出 `v1.0` 需求文档、机器可读快照与下游交接包。

![圆桌讨论](docs/screenshots/ui-discussion.png)

---

## 1. 它解决什么问题

直接把一段需求丢给一个大模型，常见结果是：

- **不可追溯**：产出的需求条目说不清来自用户哪句话；
- **混在一起**：功能要求、技术约束、还没想清楚的问题被写成同一坨；
- **没有版本**：讨论改了哪一条、为什么改，事后无法复盘；
- **无限发散**：多 Agent 越聊越多，没有收敛判据和轮数上限；
- **一问就崩**：某个 Agent 调用失败，整轮白跑。

ReqRound 用五个约束把这件事工程化：

1. **先切段、再引用**：原文按句切段编号（`S-001`），每条结论必须带逐字引用，程序校验引用是否真的出现在原文里。
2. **四类分栏 + 稳定编号**：`REQ` 明确要求 / `CON` 约束 / `OQ` 待澄清项 / `OOS` 范围外，另有 `DEC` 决策；编号一经分配永不复用。
3. **每轮一个不可变版本**：`v0.1 → v0.4 → v1.0`，版本文件只读，变更用 diff 和条目历史留痕。
4. **有明确轮数与收敛门禁**：默认 4 轮（发散 → 质询 → 收敛 → 定稿），最多 6 轮；覆盖率、引用有效率、验收完整率、阻塞项全部由程序判定。
5. **失败可降级、可重试**：单个 Agent 失败不拖垮整轮；主持人失败可复用已保存的 Agent 发言，只重跑综合；模型不可用时可切本地规则综合或回放真实发言。

## 2. 四轮圆桌协议

| 轮次 | 模式 | 谁在做什么 | 产出 |
| --- | --- | --- | --- |
| R1 | 独立发散 | 4 位 Agent 只读原文、互不可见，各自提需求/约束/问题 | `v0.1` |
| R2 | 交叉质询 | 看到当前快照与上一轮阻塞发现，挑战、补强、去重 | `v0.2` |
| R3 | 聚焦收敛 | 把模糊点收敛成待澄清项或默认假设，补齐验收要点 | `v0.3` |
| R4 | 定稿签署 | 4 位 Agent 投票；主持人落库人类澄清、关闭阻塞项 | `v0.4` 候选 |
| 人工 | 批准 | 人确认基线 | `v1.0` |

- **4 位讨论 Agent**：需求分析师、架构评审、验收测试、用户代言人。立场刻意冲突，避免“一个模型自己跟自己点头”。
- **1 位主持人 / 规格员**：不参与讨论，只做合并、裁决、落库与收敛判断；防止讨论文本直接升级成规则。
- **停在第三轮后**：如果仍有阻塞待澄清项，运行暂停，人在网页“澄清台”回答；继续后进入定稿轮。也可以选择 `--auto-assume` 让主持人写默认假设（会明确标注未经用户确认）。
- **提前收敛**：若中途已无阻塞项且质量门禁通过，可提前进入待批准，不浪费轮次。

## 3. 快照里有什么

```text
snapshot_v1.0.json
├── project            项目名 / 摘要 / 领域
├── source             原文、SHA-256、逐句分段与字符偏移
├── items[]            所有条目（含已合并/替代的历史）
│   ├── id             REQ-001 / CON-002 / OQ-013 ...
│   ├── type           requirement | constraint | open_question | out_of_scope | decision
│   ├── statement      规范化后的陈述
│   ├── priority       must / should / could / wont
│   ├── origin         explicit（原文明确）/ derived（讨论推导）/ assumed
│   ├── sources[]      {seg_id, quote, start, end, valid}
│   ├── acceptance[]   可判定的验收要点
│   ├── revision       条目修订号（与快照版本分开）
│   └── history[]      每一版谁改了什么、为什么
├── coverage           原文逐段覆盖映射与未覆盖清单
├── metrics / quality  指标与门禁
├── round_summaries    每轮发言、op、阻塞数、结论
└── clarifications     人类澄清记录
```

版本规则：

- `v0.N` = 第 N 轮综合后的快照；`v1.0` = 人工批准后的只读基线。
- 父版本写在 `parent_version`，旧版本文件永不覆盖。
- 条目编号稳定；合并/删除用 `status=superseded` + `superseded_by` 留痕，不抹掉历史。
- 每条条目还有 `fingerprint`（规范化文本哈希），用于判断“这句话是否被实质修改”。

## 4. 快速开始

### 4.1 启动网页

```powershell
cd G:\DeepSeek工程\reqround
py -3 run.py serve --port 8770
# 浏览器打开 http://127.0.0.1:8770
```

网页不依赖任何前端构建，也不需要 CDN。启动后：

1. 点「新建运行」，贴入需求原文；
2. 看 4 位 Agent 逐轮发言与版本变化；
3. 在澄清台回答阻塞问题，点「继续下一轮」；
4. 批准后下载 v1.0 文档、查看交接包、推送到后半部分编排器。

### 4.2 命令行跑一次

```powershell
# 真实模型（需要 .env 配好 AI_API_KEY / AI_BASE_URL / AI_MODEL）
py -3 run.py run --input cases\lab_booking.md --title "高校实验室设备预约管理系统" --max-rounds 4

# 无 API Key / 模型额度不足时的完整演示（本地规则 Agent + 本地规则综合）
py -3 run.py run --input cases\lab_booking.md --local --max-rounds 4 --auto-assume

# 回放一次真实运行的 Agent 发言，综合用本地规则（本仓库演示基线即此模式）
py -3 run.py run --input cases\lab_booking.md --replay cases\lab_booking_replay.json --local-moderator --max-rounds 4

py -3 run.py list
py -3 run.py show --run R-...
py -3 run.py answer --run R-... --oq OQ-001 --answer "先到先得"
py -3 run.py continue --run R-...
py -3 run.py approve --run R-... --by 验收组
py -3 run.py export --run R-... --format md,handoff
```

### 4.3 配置

复制 `.env.example` 为 `.env`：

```ini
AI_API_KEY=sk-...
AI_BASE_URL=https://your-provider.example.com/compatible-mode/v1
AI_MODEL=your-model-name
AI_TIMEOUT=300
```

任何兼容 OpenAI `chat/completions` + `response_format=json_object` 的服务都可以。**`.env` 已被 `.gitignore` 排除，不要提交。**

## 5. 演示案例

- 原始需求：[`cases/lab_booking.md`](cases/lab_booking.md)
- 最终文档（Markdown）：[`examples/lab_booking/需求快照_v1.0.md`](examples/lab_booking/需求快照_v1.0.md)
- 最终文档（Word）：[`docs/需求快照_高校实验室设备预约管理系统_v1.0.docx`](docs/需求快照_高校实验室设备预约管理系统_v1.0.docx)
- 机器可读快照：[`examples/lab_booking/snapshot_v1.0.json`](examples/lab_booking/snapshot_v1.0.json)
- 交接包：[`examples/lab_booking/handoff.json`](examples/lab_booking/handoff.json)
- 编排器任务包：[`examples/lab_booking/handoff_orchestrator.json`](examples/lab_booking/handoff_orchestrator.json)

本仓库的演示基线（`R-20261120-143847-e3e7`）结果：

| 指标 | 值 |
| --- | --- |
| 轮次 / 版本 | 4 轮，v0.0 → v0.1 → v0.2 → v0.3 → v0.4 → v1.0 |
| 明确要求 | 11 |
| 约束 | 6 |
| 待澄清项 | 13（全部由验收组回答，0 个默认假设） |
| 原文覆盖率 | 100% |
| 引用有效率 | 100% |
| 验收要点完整率 | 100% |
| 阻塞项 | 0 |
| 下游任务种子 | 13（11 AI 实现 + 1 约束核验 + 1 人工验收） |

> 说明：第一轮 4 位 Agent 的发言来自一次真实模型调用并已录制；该 Key 当日额度/权限中断后，主持人综合与后续轮次由本地规则综合器完成。接入可用模型后去掉 `--replay --local-moderator` 即可全链路真实运行。详见 [`docs/DEMO.md`](docs/DEMO.md)。

![需求快照](docs/screenshots/ui-snapshot.png)

## 6. 架构

```text
输入 Markdown/文本
      │
      ▼
 intake.py  切段、编号、SHA-256、字符偏移
      │
      ▼
 orchestrator.py  轮次状态机（发散→质询→收敛→定稿→批准）
      │        ├── 4 个 Agent 并行（可重试、可缺席）
      │        ├── 主持人综合 → ops
      │        ├── apply_ops 确定性落库（不信任模型直接改 JSON）
      │        ├── 来源逐条校验 / 覆盖率 / 质量门禁 / diff
      │        └── 暂停等待人工澄清
      ▼
 snapshots/v0.1…v1.0.json + 文档 + 版本 diff
      │
      ▼
 handoff.py  需求摘要 / 任务种子 / 编排器兼容包
```

设计上刻意把“模型生成”和“程序裁决”分开：

- 模型只能输出 **ops**（add/update/supersede/answer/ignore），由 `apply_ops` 校验后落库；
- 编号、版本、覆盖率、引用有效性、门禁全部由 Python 计算，不采信模型自述；
- 每次模型调用记录 `usage`、耗时、上下文清单（看了哪些条目/段/澄清），可审计。

## 7. 质量门禁

| 门禁 | 阈值 | 说明 |
| --- | --- | --- |
| `coverage` | ≥ 90% | 原文每个有效段落至少被一条条目引用，或显式说明忽略 |
| `citation` | ≥ 90% | 所有来源引用必须能在原文/讨论记录中逐字定位 |
| `acceptance` | = 100% | 每条明确要求至少一条可判定验收要点 |
| `requirement_sourced` | ≥ 90% | 每条明确要求至少一条原文来源 |
| `no_duplicates` | = 0 | 同类型条目标题不重复 |
| `blocking_resolved` | = 0 | 阻塞待澄清项必须有回答或明确的默认假设 |

批准时门禁未过不阻止，但必须显式 `accept_open`，未决项会原样写入 v1.0 并标注。

## 8. HTTP API

| 方法 | 路径 | 作用 |
| --- | --- | --- |
| `GET` | `/api/health` | 健康检查 |
| `GET` | `/api/runs` | 运行列表 |
| `POST` | `/api/runs` | 新建运行（`input_text/title/max_rounds/auto_assume/local/replay_path`） |
| `GET` | `/api/runs/{id}` | 状态、版本、未决问题、澄清记录 |
| `GET` | `/api/runs/{id}/events?since=&limit=` | 增量事件 |
| `GET` | `/api/runs/{id}/snapshot?version=` | 快照 JSON |
| `GET` | `/api/runs/{id}/document?version=` | Markdown 文档（`download=1` 下载） |
| `GET` | `/api/runs/{id}/diff?from=&to=` | 版本 diff |
| `GET` | `/api/runs/{id}/transcript` | 每轮发言与上下文清单 |
| `POST` | `/api/runs/{id}/clarifications` | 回答待澄清项（`continue=true` 可直接推进） |
| `POST` | `/api/runs/{id}/continue` | 继续下一轮（异步，202 语义） |
| `POST` | `/api/runs/{id}/approve` | 批准冻结 v1.0 |
| `POST` | `/api/runs/{id}/retry` | 失败后复用 Agent 发言只重跑综合 |
| `POST` | `/api/runs/{id}/push` | 把交接包推送到编排器 |
| `GET` | `/api/runs/{id}/handoff` | 交接包（`format=orchestrator` 返回 6 字段任务包） |
| `GET` | `/api/demo-case` | 内置演示案例原文 |

## 9. 与后半部分编排器对接

`handoff_orchestrator.json` 只保留编排器认识的 6 个字段：

```json
{
  "schema_version": "1.1",
  "spec_version": "v1.0",
  "list_version": "v1.0",
  "review_status": "approved",
  "tasks": [
    {
      "task_id": "T1",
      "name": "设备台账增删改查与字段维护（REQ-001）",
      "deliverable": "设备台账增删改查与字段维护功能实现",
      "acceptance_items": ["新增一台设备后可按设备编号查询到该记录"],
      "suggested_role": "ai",
      "priority": "high"
    }
  ]
}
```

- 任务名保留 `REQ-xxx`，方便下游回查快照；完整来源引用在 `handoff.json` 的 `source_req_ids` / `source_citations` 中。
- 编排器 `POST /api/start` 是同步长任务且只能启动一次，客户端超时建议 ≥ 240s；409 要读 `error` 文案区分“重复启动”与“模型失败”。
- 更详细的字段、坑与两种对接方案见 [`docs/INTEGRATION.md`](docs/INTEGRATION.md)。

## 10. 测试

```powershell
py -3 -m unittest discover -s tests -v
```

覆盖：

- 切段/偏移/标题识别、引用逐字校验（含省略号、跨段）；
- ops 应用、重复检测、合并替代、版本 diff、覆盖率；
- 两轮 mock 全流程、暂停—澄清—继续、Agent 失败降级；
- HTTP API 端到端（创建、轮询、快照、文档、事件、diff、批准、交接包）。

## 11. 目录

```text
reqround/
├── run.py                  # CLI
├── reqround/
│   ├── orchestrator.py     # 轮次状态机、并行 Agent、暂停/重试
│   ├── model.py            # 条目/ops/版本 diff/覆盖率/门禁
│   ├── localmod.py         # 本地规则综合（离线降级）
│   ├── roles.py            # 4 位 Agent 与主持人的提示词
│   ├── llm.py              # OpenAI 兼容客户端 / 回放 / 本地 / mock
│   ├── intake.py           # 切段与引用校验
│   ├── snapshot.py         # 紧凑视图与 Markdown 渲染
│   ├── handoff.py          # 下游交接包
│   ├── server.py           # 标准库 HTTP 服务
│   └── store.py            # 运行目录、原子写、事件流
├── web/                    # 单页前端（无构建）
├── cases/                  # 原始案例与真实发言回放
├── docs/                   # 设计、对接、演示、对比
├── examples/lab_booking/   # v1.0 真实产物
├── tests/                  # 单元 + 端到端
└── runs/                   # 运行产物（git 忽略）
```

## 12. 设计取舍与参考

- **为什么是 4 个讨论 Agent**：覆盖“业务要求 / 技术约束 / 可验收性 / 用户价值”四个最容易互相打架的立场；再多人会重复，再少人会漏。主持人单独设，避免运动员兼裁判。
- **为什么默认 4 轮**：R1 发散、R2 质询、R3 收敛、R4 签署；实测再增加轮次主要产生重复，边际收益低。上限 6 轮留给复杂项目。
- **为什么用 ops 而不是让模型重写整份快照**：整份重写会丢条目、改编号、无法审计；ops 让每次修改可验证、可拒绝、可 diff。
- **为什么保留本地规则综合**：模型额度/网络不可控；演示和回归测试需要确定性。本地规则只做“提案去重 + 原文兜底分类”，质量低于 LLM，但流程与门禁完全一致。

参考了老师推荐项目 [SE-Development-Process-Agent](https://github.com/Anjin001/SE-Development-Process-Agent) 的几个工程做法（稳定引用、版本与修订分离、全覆盖闸门、失败隔离），但**没有照抄代码**，并在 [`docs/COMPARISON.md`](docs/COMPARISON.md) 中写明借鉴点与刻意规避的问题。

## 13. 已知限制

- 本地规则综合的语义质量明显低于 LLM，只作为降级/演示路径；真实使用应配可用模型。
- 网页是单机工具，无鉴权、无多用户隔离；默认只绑定 `127.0.0.1`。
- 讨论并发为线程级并行；同一运行同时只允许一个推进流程，没有分布式锁。
- 尚未实现“同一需求快照上让 A/B 两组独立出案”的赛马模块；它属于本项目的下一阶段，接口预留见 `docs/DESIGN.md` 第 13 节。
- 模型输出仍是概率性的，提示词与校验只能降低而不能消除幻觉；程序会把无法验证的引用标为无效并计入质量指标。
