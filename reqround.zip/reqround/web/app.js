"use strict";

/* =========================================================
   ReqRound 前端：无框架、无构建，只通过 /api 与本地运行目录交互
   ========================================================= */

const API = {
  async get(path) {
    const res = await fetch(path, { headers: { "Accept": "application/json" } });
    const data = await res.json().catch(() => null);
    if (!res.ok) throw new Error((data && data.error) || `HTTP ${res.status}`);
    return data;
  },
  async post(path, body) {
    const res = await fetch(path, {
      method: "POST",
      headers: { "Content-Type": "application/json; charset=utf-8" },
      body: JSON.stringify(body || {}),
    });
    const data = await res.json().catch(() => null);
    if (!res.ok) throw new Error((data && data.error) || `HTTP ${res.status}`);
    return data;
  },
};

const RUN_STATUS = {
  created: ["待启动", "created"],
  running: ["讨论中", "running"],
  paused: ["等待澄清", "paused"],
  awaiting_approval: ["待批准", "awaiting_approval"],
  approved: ["已批准", "approved"],
  failed: ["失败", "failed"],
  stopped: ["已停止", "stopped"],
};
const SNAPSHOT_STATUS = {
  draft: "草稿",
  candidate: "候选待批准",
  approved: "已批准",
  approved_with_open_questions: "已批准（含未决项）",
};
const MODES = {
  diverge: "独立发散",
  challenge: "交叉质询",
  converge: "聚焦收敛",
  finalize: "定稿签署",
};
const TYPES = {
  requirement: ["REQ", "明确要求"],
  constraint: ["CON", "约束"],
  open_question: ["OQ", "待澄清项"],
  out_of_scope: ["OOS", "范围外"],
  decision: ["DEC", "关键决策"],
};
const PRIORITY = { must: "Must", should: "Should", could: "Could", wont: "Won't" };
const ORIGIN = { explicit: "原文明确", derived: "讨论推导", assumed: "默认假设" };
const CATEGORY = {
  technical: "技术", business: "业务", legal: "合规", quality: "质量",
  schedule: "工期", cost: "成本", security: "安全", other: "其他",
};
const ROLES = {
  analyst: { name: "需求分析师", short: "分析师", color: "#2f6f8f", symbol: "◈" },
  architect: { name: "架构评审", short: "架构", color: "#8a5a2b", symbol: "▤" },
  qa: { name: "验收测试", short: "测试", color: "#3d7a4f", symbol: "◇" },
  user: { name: "用户代言人", short: "用户", color: "#8a3b5c", symbol: "○" },
  moderator: { name: "主持人 · 规格员", short: "主持人", color: "#20241f", symbol: "◎" },
};
const ROLE_ORDER = ["analyst", "architect", "qa", "user"];
const EVENTS = {
  run_created: "创建", run_started: "开始", round_started: "轮次",
  agent_started: "发言", agent_done: "完成", agent_failed: "失败",
  moderator_started: "综合", moderator_failed: "综合失败",
  snapshot_published: "快照", convergence_check: "收敛",
  clarification_requested: "待澄清", clarification_received: "澄清",
  run_paused: "暂停", run_continued: "继续", run_awaiting_approval: "待批准",
  run_approved: "批准", run_failed: "失败", run_stopped: "停止",
  answers_applied: "落地",
};
const EVENT_CLASS = {
  agent_failed: "bad", moderator_failed: "bad", run_failed: "bad",
  snapshot_published: "ok", run_approved: "ok", convergence_check: "hot",
  run_paused: "hot", clarification_requested: "hot",
};

const state = {
  runs: [],
  runId: null,
  data: null,
  snapshot: null,
  transcript: [],
  events: [],
  since: 0,
  tab: "discussion",
  selectedVersion: "latest",
  search: "",
  answers: {},
  diffData: null,
  handoff: null,
  handoffLoading: false,
  timer: null,
  polling: false,
  loading: false,
  lastVersion: null,
};

/* ---------------- 基础工具 ---------------- */

const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

function esc(value) {
  return String(value ?? "").replace(/[&<>"']/g, (ch) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;",
  }[ch]));
}

function fmtTime(ts) {
  if (!ts) return "";
  return String(ts).slice(5, 16).replace("T", " ");
}

function vkey(v) {
  return String(v).replace(/^v/, "").split(".").map((n) => Number(n) || 0);
}

function sortVersions(list) {
  return [...list].sort((a, b) => {
    const ka = vkey(a), kb = vkey(b);
    for (let i = 0; i < Math.max(ka.length, kb.length); i += 1) {
      if ((ka[i] || 0) !== (kb[i] || 0)) return (ka[i] || 0) - (kb[i] || 0);
    }
    return 0;
  });
}

function statusPill(status) {
  const [label, cls] = RUN_STATUS[status] || [status, ""];
  return `<span class="status-pill ${cls}">${esc(label)}</span>`;
}

function toast(message, kind = "") {
  const el = $("#toast");
  el.textContent = message;
  el.className = kind;
  el.classList.add("show");
  clearTimeout(toast._t);
  toast._t = setTimeout(() => el.classList.remove("show"), 2800);
}

function modal(html) {
  const root = $("#modal-root");
  root.innerHTML = `<div class="modal-mask" id="modal-mask"><div class="modal" role="dialog" aria-modal="true">${html}</div></div>`;
  $("#modal-mask").addEventListener("click", (event) => {
    if (event.target.id === "modal-mask") closeModal();
  });
}

function closeModal() {
  $("#modal-root").innerHTML = "";
}

function loadingButton(btn, text) {
  if (!btn) return () => {};
  const old = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = `<span class="spinner"></span> ${esc(text)}`;
  return () => { btn.disabled = false; btn.innerHTML = old; };
}

/* ---------------- 启动与轮询 ---------------- */

document.addEventListener("DOMContentLoaded", init);

async function init() {
  bindEvents();
  try {
    await loadRuns();
    const hash = location.hash.replace("#", "");
    const target = state.runs.find((r) => r.run_id === hash) || state.runs[0];
    if (target) {
      await selectRun(target.run_id);
      const params = new URLSearchParams(location.search);
      const tab = params.get("tab");
      if (["discussion", "snapshot", "trace", "quality", "raw"].includes(tab)) state.tab = tab;
      const version = params.get("version");
      if (version) await loadSnapshot(version);
      renderAll();
    } else {
      renderAll();
    }
  } catch (err) {
    toast(`初始化失败：${err.message}`, "error");
    renderAll();
  }
}

async function loadRuns() {
  const data = await API.get("/api/runs");
  state.runs = data.runs || [];
  renderRunSelect();
}

async function selectRun(runId) {
  if (!runId) return;
  state.runId = runId;
  state.data = null;
  state.snapshot = null;
  state.transcript = [];
  state.events = [];
  state.since = 0;
  state.selectedVersion = "latest";
  state.search = "";
  state.answers = {};
  state.diffData = null;
  state.handoff = null;
  state.tab = "discussion";
  location.hash = runId;
  state.loading = true;
  try {
    await refreshState(true);
    await Promise.all([loadTranscript(), loadEvents(0)]);
    renderAll();
    schedulePoll(600);
  } catch (err) {
    toast(`加载运行失败：${err.message}`, "error");
    renderAll();
  } finally {
    state.loading = false;
  }
}

async function refreshState(forceSnapshot = false) {
  const data = await API.get(`/api/runs/${state.runId}`);
  const previousVersion = state.snapshot ? state.snapshot.version : state.lastVersion;
  state.data = data;
  if (data.run) {
    const index = state.runs.findIndex((run) => run.run_id === data.run.run_id);
    if (index >= 0) state.runs[index] = { ...state.runs[index], ...data.run };
  }
  const latest = data.latest || {};
  const versionChanged = forceSnapshot
    || (state.selectedVersion === "latest" && previousVersion !== latest.version);
  if (versionChanged) {
    state.diffData = null;
    await loadSnapshot("latest");
    await loadTranscript();
  }
  if (data.run && data.run.status === "approved" && !state.handoff && !state.handoffLoading) {
    loadHandoff();
  }
  state.lastVersion = latest.version;
}

async function loadSnapshot(version) {
  const snap = await API.get(`/api/runs/${state.runId}/snapshot?version=${encodeURIComponent(version)}`);
  state.snapshot = snap;
  state.selectedVersion = version === "latest" ? "latest" : snap.version;
}

async function loadTranscript() {
  const data = await API.get(`/api/runs/${state.runId}/transcript`);
  state.transcript = data.records || [];
}

async function loadEvents(since) {
  const data = await API.get(`/api/runs/${state.runId}/events?since=${since}&limit=400`);
  const incoming = data.events || [];
  if (incoming.length) {
    const seen = new Set(state.events.map((e) => e.seq));
    for (const event of incoming) {
      if (!seen.has(event.seq)) {
        state.events.push(event);
        seen.add(event.seq);
      }
    }
    state.events.sort((a, b) => a.seq - b.seq);
    state.since = Math.max(state.since, data.next_since || 0);
  }
}

async function loadHandoff() {
  if (!state.runId) return;
  state.handoffLoading = true;
  try {
    state.handoff = await API.get(`/api/runs/${state.runId}/handoff`);
    renderHandoff();
  } catch (err) {
    state.handoff = null;
  } finally {
    state.handoffLoading = false;
  }
}

function schedulePoll(delay = 1600) {
  clearTimeout(state.timer);
  if (!state.runId) return;
  const status = state.data && state.data.run ? state.data.run.status : "";
  if (["approved", "failed", "stopped"].includes(status)) return;
  state.timer = setTimeout(poll, document.hidden ? Math.max(4000, delay) : delay);
}

async function poll() {
  if (!state.runId || state.polling) return;
  state.polling = true;
  const root = $("#tab-content");
  const scroll = window.scrollY;
  const active = document.activeElement;
  const editingClarify = active && active.closest("#clarify-panel") && active.tagName === "TEXTAREA";
  const typingSearch = active && active.id === "snapshot-search";
  try {
    const beforeVersion = state.snapshot ? state.snapshot.version : null;
    const beforeRounds = state.transcript.length;
    await refreshState(false);
    await loadEvents(state.since);
    const afterVersion = state.snapshot ? state.snapshot.version : null;
    const status = state.data.run.status;
    if (beforeVersion !== afterVersion || state.transcript.length !== beforeRounds) {
      // refreshState 已按需拉取，这里只补齐版本未变但记录变多的情况
      if (state.transcript.length === beforeRounds) await loadTranscript();
    }
    renderHeader();
    renderRunList();
    renderVersions();
    renderMetrics();
    renderEvents();
    if (!typingSearch) renderTab();
    if (!editingClarify) renderClarify();
    renderHandoff();
    renderRunSelect();
    if (!typingSearch) window.scrollTo(0, scroll);
  } catch (err) {
    // 单次轮询失败不打断页面，下一次继续
    console.warn("poll failed", err);
  } finally {
    state.polling = false;
    const status = state.data && state.data.run ? state.data.run.status : "";
    const delay = status === "running" ? 1400 : 3200;
    schedulePoll(delay);
  }
}

/* ---------------- 渲染：顶栏与左栏 ---------------- */

function renderAll(options = {}) {
  renderRunSelect();
  renderHeader();
  renderRunList();
  renderVersions();
  renderMetrics();
  renderTab(options);
  renderClarify();
  renderHandoff();
  renderEvents();
}

function renderRunSelect() {
  const select = $("#run-select");
  if (!select) return;
  const current = state.runId || "";
  select.innerHTML = state.runs.length
    ? state.runs.map((run) => `<option value="${esc(run.run_id)}" ${run.run_id === current ? "selected" : ""}>${esc(run.title || run.run_id)} · ${esc((RUN_STATUS[run.status] || [run.status])[0])}</option>`).join("")
    : `<option value="">暂无运行</option>`;
}

function renderRunList() {
  const list = $("#run-list");
  const count = $("#run-count");
  if (!list) return;
  count.textContent = String(state.runs.length);
  if (!state.runs.length) {
    list.innerHTML = `<div class="empty-state small">还没有运行<br>点击右上角「新建运行」开始</div>`;
    return;
  }
  list.innerHTML = state.runs.map((run) => {
    const metrics = run.metrics || {};
    const [, cls] = RUN_STATUS[run.status] || [];
    return `<button class="run-item ${run.run_id === state.runId ? "active" : ""}" data-run="${esc(run.run_id)}">
      <div class="rt"><span>${esc(shortTitle(run.title))}</span><span class="dot ${cls}"></span></div>
      <div class="rm"><span>${esc(run.latest_version || "")}</span><span>${run.round || 0}/${run.max_rounds || 0} 轮</span><span>阻塞 ${metrics.blocking_open ?? "-"}</span></div>
    </button>`;
  }).join("");
}

function renderHeader() {
  const hero = $("#hero");
  if (!hero) return;
  const run = state.data && state.data.run;
  const snap = state.snapshot;
  if (!run) {
    hero.innerHTML = `
      <div class="hero-top"><div>
        <h2>把一段原始需求，谈成一份可评审的快照</h2>
        <p class="summary">4 位立场不同的 Agent 先独立解读，再交叉质询，主持人在每一轮把结论落成带编号、带来源、可 diff 的新版本。人在澄清台回答真正需要拍板的问题。</p>
        <div class="meta"><span>明确要求 / 约束 / 待澄清项三类分栏</span><span>每条引用原文逐字校验</span><span>v0.1 → v1.0 版本留痕</span></div>
      </div></div>
      <div class="hero-actions">
        <button class="btn accent" data-act="new">新建一次需求圆桌</button>
        <button class="btn" data-act="load-demo-new">载入实验室预约案例</button>
      </div>`;
    return;
  }
  const status = run.status;
  const title = snap && snap.project ? snap.project.title : run.title;
  const summary = snap && snap.project ? snap.project.summary : "";
  const round = run.round || 0;
  const maxRounds = run.max_rounds || 0;
  const blocking = snap && snap.metrics ? (snap.metrics.blocking_open ?? 0) : 0;
  const dots = Array.from({ length: maxRounds }, (_, index) => {
    const n = index + 1;
    const cls = n <= round ? "done" : (n === round + 1 && status === "running" ? "current" : "");
    return `<span class="round-dot ${cls}" title="第 ${n} 轮">${n}</span>${n < maxRounds ? '<span class="round-line"></span>' : ""}`;
  }).join("");
  const actions = [];
  if (status === "running") {
    actions.push(`<button class="btn" disabled><span class="spinner"></span> 第 ${round} 轮进行中</button>`);
    actions.push(`<button class="btn ghost danger" data-act="stop">停止</button>`);
  } else if (status === "paused") {
    actions.push(`<button class="btn accent" data-act="continue">继续下一轮</button>`);
    actions.push(`<button class="btn ghost" data-act="goto-clarify">去澄清台</button>`);
    actions.push(`<button class="btn ghost danger" data-act="stop">停止</button>`);
  } else if (status === "awaiting_approval") {
    actions.push(`<button class="btn accent" data-act="approve">批准并冻结 v1.0</button>`);
    actions.push(`<button class="btn" data-act="tab" data-tab="quality">先看质量门禁</button>`);
  } else if (status === "approved") {
    actions.push(`<a class="btn accent" href="/api/runs/${run.run_id}/document?version=v1.0&download=1">下载需求文档</a>`);
    actions.push(`<button class="btn" data-act="handoff-view">查看交接包</button>`);
    actions.push(`<button class="btn" data-act="push">推送编排器</button>`);
  } else if (status === "created") {
    actions.push(`<button class="btn accent" data-act="continue">启动讨论</button>`);
  } else if (status === "failed") {
    actions.push(`<button class="btn accent" data-act="retry">复用发言重试</button>`);
    actions.push(`<button class="btn" data-act="error">查看错误</button>`);
    actions.push(`<button class="btn" data-act="new">新建运行</button>`);
  } else {
    actions.push(`<button class="btn" data-act="new">新建运行</button>`);
  }
  if (state.selectedVersion !== "latest") {
    actions.unshift(`<button class="btn" data-act="back-latest">回到最新版本</button>`);
  }
  hero.innerHTML = `
    <div class="hero-top">
      <div style="min-width:0">
        <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
          ${statusPill(status)}
          <span class="small muted mono">${esc(run.run_id)}</span>
          ${state.selectedVersion !== "latest" ? `<span class="pill changed">历史版本 ${esc(snap ? snap.version : "")}</span>` : ""}
        </div>
        <h2 style="margin-top:10px">${esc(title)}</h2>
        <p class="summary">${esc(summary || "（项目摘要将在第一轮综合后生成）")}</p>
        <div class="meta">
          <span>版本 <b class="mono">${esc(snap ? snap.version : run.latest_version || "")}</b></span>
          <span>第 ${round} / ${maxRounds} 轮</span>
          <span>原文 ${snap && snap.source ? snap.source.segment_count : "-"} 段 · <span class="mono">${esc(snap && snap.source ? snap.source.sha256_short : "")}</span></span>
          <span>模型 ${esc((run.config && run.config.model) || "-")}</span>
          ${blocking ? `<span style="color:var(--accent)">阻塞待澄清 ${blocking}</span>` : ""}
          ${run.approved_at ? `<span>批准于 ${esc(fmtTime(run.approved_at))}</span>` : ""}
        </div>
      </div>
    </div>
    <div class="rounds">${dots}</div>
    <div class="hero-actions">${actions.join("")}</div>`;
}

function renderVersions() {
  const list = $("#version-list");
  const count = $("#version-count");
  if (!list) return;
  const versions = state.data && state.data.versions ? sortVersions(state.data.versions).reverse() : [];
  count.textContent = String(versions.length);
  if (!versions.length) {
    list.innerHTML = `<li class="small muted">暂无版本</li>`;
    return;
  }
  const active = state.selectedVersion === "latest"
    ? (state.data.latest && state.data.latest.version)
    : state.selectedVersion;
  list.innerHTML = versions.map((version, index) => {
    const isLatest = index === 0;
    const label = version === "v0.0" ? "空快照" : (version === "v1.0" ? "批准基线" : `第 ${version.replace(/^v0\./, "")} 轮`);
    return `<li><button class="version-item ${version === active ? "active" : ""}" data-version="${esc(version)}">
      <span class="v">${esc(version)}</span><span class="vs">${esc(isLatest ? (version === "v1.0" ? "基线" : "最新") : label)}</span>
    </button></li>`;
  }).join("");
}

function renderMetrics() {
  const grid = $("#metric-grid");
  if (!grid) return;
  const snap = state.snapshot;
  if (!snap) {
    grid.innerHTML = `<div class="empty-state small" style="grid-column:1/-1">暂无指标</div>`;
    return;
  }
  const m = snap.metrics || {};
  const coverage = Number(m.coverage_rate || 0);
  const citation = Number(m.citation_rate || 0);
  const blocking = Number(m.blocking_open || 0);
  const items = [
    ["明确要求", m.requirements ?? 0, ""],
    ["约束", m.constraints ?? 0, ""],
    ["待澄清", m.open_questions ?? 0, blocking ? "warn" : ""],
    ["阻塞项", blocking, blocking ? "bad" : "ok"],
    ["覆盖率", `${Math.round(coverage * 100)}%`, coverage >= 0.9 ? "ok" : "warn"],
    ["引用有效", `${Math.round(citation * 100)}%`, citation >= 0.9 ? "ok" : "warn"],
  ];
  grid.innerHTML = items.map(([label, value, cls]) => `<div class="metric ${cls}"><b>${esc(value)}</b><span>${esc(label)}</span></div>`).join("");
}

function renderEvents() {
  const list = $("#event-list");
  if (!list) return;
  const events = state.events.slice(-90);
  if (!events.length) {
    list.innerHTML = `<li class="small muted">等待事件 …</li>`;
    return;
  }
  const atBottom = list.scrollTop + list.clientHeight >= list.scrollHeight - 20;
  list.innerHTML = events.map((event) => {
    const cls = EVENT_CLASS[event.type] || "";
    return `<li class="${cls}"><span class="et">${esc(fmtTime(event.ts).slice(6))}</span><span class="en">${esc(EVENTS[event.type] || event.type)}</span><span>${esc(eventText(event))}</span></li>`;
  }).join("");
  if (atBottom) list.scrollTop = list.scrollHeight;
}

function eventText(event) {
  if (event.type === "round_started") return `第 ${event.round} 轮 · ${event.mode_label || MODES[event.mode] || ""}`;
  if (event.type === "agent_done") return `${event.name || event.agent}：${event.findings} 发现 / ${event.items} 提案`;
  if (event.type === "agent_failed") return `${event.name || event.agent} 失败`;
  if (event.type === "snapshot_published") return `${event.version} 发布`;
  if (event.type === "convergence_check") return event.converged ? "已收敛" : `未收敛${event.reasons && event.reasons.length ? "：" + event.reasons[0] : ""}`;
  if (event.type === "run_paused") return "等待人工澄清";
  if (event.type === "clarification_requested") return (event.questions || []).map((q) => q.id).join("、");
  if (event.type === "clarification_received") return `${event.oq_id}`;
  if (event.type === "run_awaiting_approval") return `${event.version || ""}`;
  if (event.type === "run_approved") return `${event.version} by ${event.by || ""}`;
  if (event.type === "run_failed") return String(event.error || "").slice(0, 40);
  if (event.type === "answers_applied") return `${event.version} 落地 ${event.answered} 条`;
  if (event.type === "run_continued") return "继续下一轮";
  return "";
}

/* ---------------- 主区 Tab ---------------- */

function activeTab() {
  return state.tab || "discussion";
}

function setTab(tab) {
  state.tab = tab;
  $$("#tabs button").forEach((btn) => btn.classList.toggle("active", btn.dataset.tab === tab));
  renderTab();
}

function renderTab(options = {}) {
  const root = $("#tab-content");
  if (!root) return;
  $$("#tabs button").forEach((btn) => btn.classList.toggle("active", btn.dataset.tab === activeTab()));
  if (!state.data) {
    root.innerHTML = `<div class="empty-state"><strong>还没有选择运行</strong>新建一次运行，或从左侧选择已有运行。</div>`;
    return;
  }
  if (activeTab() === "discussion") root.innerHTML = renderDiscussion();
  else if (activeTab() === "snapshot") root.innerHTML = renderSnapshot();
  else if (activeTab() === "trace") root.innerHTML = renderTrace();
  else if (activeTab() === "quality") root.innerHTML = renderQuality();
  else if (activeTab() === "raw") root.innerHTML = renderRaw();
  if (activeTab() === "snapshot") filterItems();
}

function shortTitle(title) {
  const text = String(title || "未命名");
  return text.length > 22 ? text.slice(0, 22) + "…" : text;
}

/* ---------------- 圆桌讨论 ---------------- */

function renderDiscussion() {
  const snap = state.snapshot;
  if (!snap) return `<div class="empty-state">快照尚未生成。</div>`;
  const run = state.data.run;
  const byRound = new Map();
  for (const record of state.transcript) {
    if (!record.round || record.round > snap.round) continue;
    if (!byRound.has(record.round)) byRound.set(record.round, []);
    byRound.get(record.round).push(record);
  }
  const summaries = snap.round_summaries || [];
  const rounds = [];
  for (let n = 1; n <= snap.round; n += 1) rounds.push(n);
  if (run.status === "running" && !byRound.has(run.round)) rounds.push(run.round);
  if (!rounds.length) {
    return `<div class="empty-state"><strong>圆桌还没有开始</strong>${esc(run.status === "created" ? "点击上方「启动讨论」，或等待后台任务。" : "等待第一轮发言。")}</div>`;
  }
  return rounds.map((roundNo) => {
    const records = byRound.get(roundNo) || [];
    const summary = summaries.find((s) => Number(s.round) === roundNo);
    const mode = summary ? summary.mode : (roundNo === 1 ? "diverge" : (roundNo === snap.max_rounds ? "finalize" : "challenge"));
    const version = summary ? summary.version : (roundNo <= snap.round ? `v0.${roundNo}` : "进行中");
    const live = run.status === "running" && roundNo === run.round && !records.length;
    const head = `<div class="round-head">
      <div class="round-no">${roundNo}</div>
      <div>
        <h3>第 ${roundNo} 轮 · ${esc(MODES[mode] || mode)}</h3>
        <div class="mode">${version ? `<span class="mono">${esc(version)}</span>` : ""}${summary && summary.duration_ms ? ` · ${(summary.duration_ms / 1000).toFixed(1)}s` : ""}</div>
      </div>
      <span class="spacer"></span>
      ${summary && summary.blocking_open !== undefined ? `<span class="pill ${summary.blocking_open ? "blocking" : ""}">阻塞 ${summary.blocking_open}</span>` : ""}
      ${summary && summary.quality_passed ? `<span class="pill new">门禁通过</span>` : ""}
    </div>`;
    const summaryBar = summary && summary.summary ? `<div class="round-summary">${esc(summary.summary)}</div>` : "";
    let body = "";
    if (live) {
      body = `<div class="agent-grid">${ROLE_ORDER.map((role) => liveAgentCard(role)).join("")}</div>
        <div class="moderator-card"><div class="live-round"><span class="spinner"></span> 等待 4 位 Agent 发言，随后由主持人综合成新版本 …</div></div>`;
    } else {
      const discussants = ROLE_ORDER.map((role) => {
        const record = records.find((r) => r.agent === role && r.kind === "discussant");
        return record ? agentCard(record) : liveAgentCard(role);
      }).join("");
      const moderator = records.find((r) => r.kind === "moderator");
      body = `<div class="agent-grid">${discussants}</div>${moderatorCard(moderator, summary)}`;
    }
    return `<section class="round-block">${head}${summaryBar}${body}</section>`;
  }).join("");
}

function liveAgentCard(role) {
  const info = ROLES[role] || { name: role, color: "#888", symbol: "?" };
  const agent = state.data && state.data.run.agents ? state.data.run.agents[role] : null;
  const failed = agent && agent.status === "failed";
  const text = failed ? `调用失败：${esc((agent.last_error || "").slice(0, 90))}` : "正在阅读原文、形成判断 …";
  return `<article class="agent-card ${failed ? "failed" : ""}" style="--role:${info.color}">
    <div class="agent-head"><div class="avatar">${esc(info.symbol)}</div><div><h4>${esc(info.name)}</h4><div class="st">${failed ? "本轮缺席" : "发言中"}</div></div></div>
    <div class="empty"><span class="spinner"></span> ${text}</div>
  </article>`;
}

function agentCard(record) {
  const role = record.agent;
  const info = ROLES[role] || { name: role, color: "#888", symbol: "?" };
  const response = record.response || {};
  const failed = record.status !== "ok";
  const findings = response.findings || [];
  const items = response.proposed_items || [];
  const vote = response.vote ? `<span class="pill ${response.vote === "reject" ? "blocking" : "new"}">${esc(voteLabel(response.vote))}</span>` : "";
  const head = `<div class="agent-head">
      <div class="avatar">${esc(info.symbol)}</div>
      <div style="min-width:0"><h4>${esc(info.name)} ${vote}</h4>
      <div class="st">${failed ? "本轮缺席" : `${(record.duration_ms || 0) / 1000}s · ${findings.length} 发现 · ${items.length} 提案`}</div></div>
    </div>`;
  if (failed) {
    return `<article class="agent-card failed" style="--role:${info.color}">${head}<div class="empty">${esc((record.error || "调用失败").slice(0, 180))}</div></article>`;
  }
  return `<article class="agent-card" style="--role:${info.color}">
    ${head}
    ${response.stance ? `<div class="stance">${esc(response.stance)}</div>` : ""}
    ${findings.length ? findings.map(findingHtml).join("") : `<div class="empty">本轮没有提出新的问题。</div>`}
    ${items.length ? `<div class="proposals">${items.map(proposalHtml).join("")}</div>` : ""}
  </article>`;
}

function voteLabel(vote) {
  return { accept: "签署：接受", accept_with_comments: "有条件接受", reject: "反对" }[vote] || vote;
}

function findingHtml(finding) {
  const sev = finding.severity || "major";
  return `<div class="finding">
    <div class="f-head">
      <span class="sev ${esc(sev)}">${esc(sev)}</span>
      <span class="mono small">${esc(finding.finding_id || "")}</span>
      ${finding.target_id ? `<span class="pill">${esc(finding.target_id)}</span>` : ""}
      <span class="small muted">${esc(finding.kind || "")}</span>
    </div>
    <div class="f-statement">${esc(finding.statement || "")}</div>
    ${finding.why_it_matters ? `<div class="f-why">${esc(finding.why_it_matters)}</div>` : ""}
    ${finding.proposal ? `<div class="f-proposal">建议：${esc(finding.proposal)}</div>` : ""}
    ${finding.question ? `<div class="f-question">待确认：${esc(finding.question)}</div>` : ""}
    <div style="margin-top:4px">${sourceChips(finding.sources)}</div>
  </div>`;
}

function proposalHtml(item) {
  const type = item.type || "requirement";
  return `<div class="proposal">
    <div class="p-head">
      <span class="type-tag ${esc(type)}">${esc((TYPES[type] || [type])[0])}</span>
      <b>${esc(item.title || "")}</b>
      ${item.priority ? `<span class="pill ${esc(item.priority)}">${esc(PRIORITY[item.priority] || item.priority)}</span>` : ""}
    </div>
    <div style="margin-top:3px">${esc(item.statement || "")}</div>
    ${item.acceptance && item.acceptance.length ? `<div class="small muted" style="margin-top:3px">验收：${esc(item.acceptance.join("；"))}</div>` : ""}
    <div style="margin-top:4px">${sourceChips(item.sources)}</div>
  </div>`;
}

function moderatorCard(record, summary) {
  if (!record) {
    return `<div class="moderator-card"><div class="live-round"><span class="spinner"></span> 等待主持人综合本轮发言 …</div></div>`;
  }
  const response = record.response || {};
  const ops = (summary && summary.ops) || {};
  const rejected = (summary && summary.rejected_ops) || [];
  return `<div class="moderator-card">
    <div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap">
      <div class="avatar" style="--role:#20241f">◎</div>
      <h4>主持人综合 · ${esc(summary ? summary.version : "")}</h4>
      ${response.converged ? `<span class="pill new">判断：已收敛</span>` : `<span class="pill">判断：未收敛</span>`}
      ${summary && summary.quality_passed ? `<span class="pill new">质量门禁通过</span>` : ""}
    </div>
    <div style="margin-top:6px">${esc(response.summary || (summary && summary.summary) || "")}</div>
    ${response.convergence_reason ? `<div class="small muted" style="margin-top:3px">${esc(response.convergence_reason)}</div>` : ""}
    <div class="ops-row">
      <span class="op-chip">新增 ${ops.added || 0}</span>
      <span class="op-chip">修订 ${ops.updated || 0}</span>
      <span class="op-chip">合并 ${ops.superseded || 0}</span>
      <span class="op-chip">回答 ${ops.answered || 0}</span>
      <span class="op-chip">忽略段 ${ops.ignored || 0}</span>
      ${rejected.length ? `<span class="op-chip" style="color:var(--red)">拒绝 op ${rejected.length}</span>` : ""}
    </div>
    ${rejected.length ? `<details class="item-details"><summary>查看被拒绝的 op（${rejected.length}）</summary><div class="detail-body"><ul>${rejected.map((r) => `<li><span class="mono">${esc(r.op || "")}</span>：${esc(r.reason || "")}</li>`).join("")}</ul></div></details>` : ""}
    ${response.next_focus && response.next_focus.length ? `<div class="small muted" style="margin-top:5px">下一轮聚焦：${esc(response.next_focus.join("；"))}</div>` : ""}
  </div>`;
}

/* ---------------- 需求快照 ---------------- */

function renderSnapshot() {
  const snap = state.snapshot;
  if (!snap) return `<div class="empty-state">快照尚未生成。</div>`;
  const groups = [
    ["requirement", "明确要求", "REQ", "req"],
    ["constraint", "约束", "CON", "con"],
    ["open_question", "待澄清项", "OQ", "oq"],
    ["out_of_scope", "范围外", "OOS", "oos"],
    ["decision", "关键决策", "DEC", "dec"],
  ];
  const active = (snap.items || []).filter((item) => item.status === "active");
  const toolbar = `<div class="snapshot-toolbar">
    <input type="search" id="snapshot-search" placeholder="搜索编号、标题或陈述 …" value="${esc(state.search)}">
    <span class="small muted">${esc(snap.version)} · ${active.length} 条有效条目</span>
  </div>`;
  const sections = groups.map(([type, label, prefix, cls]) => {
    const items = active.filter((item) => item.type === type);
    if (!items.length) return "";
    return `<div class="section-title"><h3>${esc(label)}</h3><span class="count">${items.length}</span><span class="rule"></span><span class="small muted mono">${prefix}</span></div>
      ${items.map((item) => itemCard(item, snap, cls)).join("")}`;
  }).join("");
  const superseded = (snap.items || []).filter((item) => item.status === "superseded");
  const supersededBlock = superseded.length ? `<details class="item-details" style="margin-top:18px"><summary>已合并/替代的条目（${superseded.length}）</summary><div class="detail-body"><ul>${superseded.map((item) => `<li><span class="mono">${esc(item.id)}</span> ${esc(item.title)} → ${esc(item.superseded_by || "（无替代）")}</li>`).join("")}</ul></div></details>` : "";
  const notice = state.selectedVersion !== "latest" ? `<div class="round-summary" style="border-left-color:var(--blue)">正在查看历史版本 ${esc(snap.version)}，内容只读；澄清与批准始终基于最新版本。</div>` : "";
  return `${notice}${toolbar}${sections || `<div class="empty-state">本版还没有条目。</div>`}${supersededBlock}`;
}

function itemCard(item, snap, cls) {
  const type = item.type;
  const isNew = Number(item.created_round) === Number(snap.round) && Number(snap.round) > 0;
  const isChanged = !isNew && Number(item.updated_round) === Number(snap.round) && Number(item.revision) > 1;
  const badges = [];
  if (item.priority) badges.push(`<span class="pill ${esc(item.priority)}">${esc(PRIORITY[item.priority] || item.priority)}</span>`);
  if (isNew) badges.push(`<span class="pill new">本版新增</span>`);
  if (isChanged) badges.push(`<span class="pill changed">本版修订</span>`);
  if (type === "open_question") {
    if (item.answer) badges.push(`<span class="pill answered">已回答</span>`);
    else if (item.assumption) badges.push(`<span class="pill assumed">默认假设</span>`);
    else if (item.blocking) badges.push(`<span class="pill blocking">阻塞</span>`);
  }
  const sourceChipsHtml = sourceChips(item.sources);
  const details = [];
  if (item.acceptance && item.acceptance.length) {
    details.push(`<div><span class="muted">验收要点</span><ul class="acceptance">${item.acceptance.map((a) => `<li>${esc(a)}</li>`).join("")}</ul></div>`);
  }
  if (type === "open_question") {
    if (item.why) details.push(`<div><span class="muted">为什么重要：</span>${esc(item.why)}</div>`);
    if (item.options && item.options.length) details.push(`<div><span class="muted">可选项：</span>${esc(item.options.join("；"))}</div>`);
    if (item.suggested_assumption && !item.assumption && !item.answer) details.push(`<div><span class="muted">建议默认值（未采纳）：</span>${esc(item.suggested_assumption)}</div>`);
    if (item.answer) details.push(`<div><span class="muted">回答：</span>${esc(item.answer)} <span class="small muted">（${esc(item.answer_source || "")}）</span></div>`);
    else if (item.assumption) details.push(`<div><span class="muted">已采纳默认假设：</span>${esc(item.assumption)} <span class="small muted">（未经用户确认）</span></div>`);
  }
  if (item.category) details.push(`<div><span class="muted">类别：</span>${esc(CATEGORY[item.category] || item.category)}</div>`);
  if (item.related && item.related.length) details.push(`<div><span class="muted">关联：</span>${item.related.map((id) => `<span class="mono small">${esc(id)}</span>`).join("、")}</div>`);
  if (item.history && item.history.length) {
    details.push(`<div class="history"><span class="muted">变更历史：</span>${item.history.map((h) => `${esc(h.version)} ${esc(h.action)}${h.fields ? `（${esc(h.fields.join("、"))}）` : ""}`).join(" · ")}</div>`);
  }
  const detailHtml = details.length ? `<details class="item-details"><summary>验收 · 依据 · 历史</summary><div class="detail-body">${details.join("")}</div></details>` : "";
  const locator = firstSegId(item.sources);
  return `<article class="item-card ${cls}" id="item-${esc(item.id)}" data-search="${esc([item.id, item.title, item.statement, type].join(" "))}">
    <div class="item-head">
      <span class="item-id">${esc(item.id)}</span>
      <h4>${esc(item.title)}</h4>
      ${badges.join("")}
    </div>
    <div class="item-statement">${esc(item.statement)}</div>
    <div class="item-meta">
      <span>${esc(ORIGIN[item.origin] || item.origin || "")}</span>
      <span>rev.${esc(item.revision || 1)}</span>
      ${sourceChipsHtml || `<span class="muted">无有效来源</span>`}
      ${locator ? `<button class="link" data-seg="${esc(locator)}">定位原文 ↗</button>` : ""}
    </div>
    ${detailHtml}
  </article>`;
}

function firstSegId(sources) {
  const source = (sources || []).find((s) => s.kind !== "discussion" && s.valid !== false && s.seg_id);
  return source ? source.seg_id : "";
}

function sourceChips(sources) {
  return (sources || []).map((src) => {
    if (src.kind === "discussion") {
      return `<span class="src-chip" title="${esc(src.quote || "")}">R${esc(src.round || "?")} · ${esc(src.agent || "")}</span>`;
    }
    const quote = String(src.quote || "");
    const short = quote.length > 26 ? quote.slice(0, 26) + "…" : quote;
    return `<button class="src-chip ${src.valid === false ? "invalid" : ""}" data-seg="${esc(src.seg_id || "")}" title="${esc(quote)}">${esc(src.seg_id || "?")} <span class="q">“${esc(short)}”</span></button>`;
  }).join("");
}

function filterItems() {
  const query = state.search.trim().toLowerCase();
  $$("#tab-content .item-card").forEach((card) => {
    const haystack = (card.dataset.search || "").toLowerCase();
    card.style.display = !query || haystack.includes(query) ? "" : "none";
  });
}

/* ---------------- 来源追踪 ---------------- */

function renderTrace() {
  const snap = state.snapshot;
  if (!snap) return `<div class="empty-state">快照尚未生成。</div>`;
  const mapping = (snap.coverage && snap.coverage.mapping) || {};
  const ignored = new Set((snap.coverage && snap.coverage.ignored) || []);
  const rows = (snap.source.segments || []).map((seg) => {
    const refs = mapping[seg.seg_id] || [];
    let stateText = "已覆盖";
    let cls = "state-ok";
    if (seg.kind === "heading") {
      stateText = "结构标题"; cls = "muted";
    } else if (!refs.length && ignored.has(seg.seg_id)) {
      stateText = "已说明忽略"; cls = "muted";
    } else if (!refs.length) {
      stateText = "未覆盖"; cls = "state-bad";
    }
    return `<tr class="${seg.kind === "heading" ? "head-row" : ""}" data-seg="${esc(seg.seg_id)}">
      <td class="seg-id">${esc(seg.seg_id)}</td>
      <td>${esc(seg.text)}</td>
      <td>${refs.length ? refs.map((id) => `<button class="link mono" data-item="${esc(id)}">${esc(id)}</button>`).join("、") : "—"}</td>
      <td class="${cls}">${stateText}</td>
    </tr>`;
  }).join("");
  const total = snap.coverage ? snap.coverage.total : 0;
  const covered = snap.coverage ? snap.coverage.covered : 0;
  return `<div class="round-summary">覆盖 ${covered} / ${total} 个有效段落（${Math.round((snap.coverage ? snap.coverage.rate : 0) * 100)}%）。标题行不计入覆盖率；点击任意行可跳到原文对应位置。</div>
    <table class="trace-table"><thead><tr><th style="width:70px">段号</th><th>原文</th><th style="width:180px">被引用条目</th><th style="width:90px">状态</th></tr></thead><tbody>${rows}</tbody></table>`;
}

/* ---------------- 质量门禁 ---------------- */

function renderQuality() {
  const snap = state.snapshot;
  if (!snap) return `<div class="empty-state">快照尚未生成。</div>`;
  const gates = (snap.quality && snap.quality.gates) || {};
  const metrics = snap.metrics || {};
  const gateMeta = [
    ["schema_valid", "结构合法"],
    ["coverage", "原文覆盖 ≥ 90%"],
    ["citation", "引用有效 ≥ 90%"],
    ["acceptance", "要求均有验收"],
    ["requirement_sourced", "要求均有原文来源"],
    ["no_duplicates", "无重复条目"],
    ["blocking_resolved", "阻塞项已处理"],
  ];
  const gateHtml = gateMeta.map(([key, label]) => {
    const pass = !!gates[key];
    const value = key === "coverage" ? metrics.coverage_rate
      : key === "citation" ? metrics.citation_rate
        : key === "acceptance" ? metrics.acceptance_rate
          : key === "requirement_sourced" ? metrics.requirement_source_rate
            : key === "blocking_resolved" ? metrics.blocking_open
              : key === "no_duplicates" ? metrics.duplicate_titles : "—";
    return `<div class="gate ${pass ? "pass" : "fail"}"><span class="g-ico">${pass ? "✓" : "!"}</span><span class="g-name">${esc(label)}</span><span class="g-val">${esc(value ?? "")}</span></div>`;
  }).join("");
  const issues = (snap.quality && snap.quality.issues) || [];
  const issueHtml = issues.length
    ? `<div class="issue-list">${issues.map((issue) => `<li>${esc(issue)}</li>`).join("")}</div>`
    : `<p class="small muted" style="margin-bottom:14px">本版没有自动检测到的质量问题。</p>`;
  const rows = (snap.round_summaries || []).map((row) => `<tr>
    <td>${row.round}</td><td>${esc(MODES[row.mode] || row.mode)}</td><td class="mono">${esc(row.version)}</td>
    <td>${row.ops ? row.ops.added : 0}</td><td>${row.ops ? row.ops.updated : 0}</td>
    <td>${row.ops ? row.ops.answered : 0}</td><td>${row.blocking_open ?? "-"}</td>
    <td>${Math.round((row.coverage_rate || 0) * 100)}%</td><td>${row.quality_passed ? "通过" : "未通过"}</td>
  </tr>`).join("");
  const versions = sortVersions(state.data.versions || []);
  const diffFrom = versions.length > 1 ? versions[versions.length - 2] : versions[0] || "";
  const diffTo = versions.length ? versions[versions.length - 1] : "";
  const options = versions.map((v) => `<option value="${esc(v)}" ${v === diffFrom ? "selected" : ""}>${esc(v)}</option>`).join("");
  const optionsTo = versions.map((v) => `<option value="${esc(v)}" ${v === diffTo ? "selected" : ""}>${esc(v)}</option>`).join("");
  return `<div class="section-title"><h3>质量门禁</h3><span class="rule"></span><span class="small muted">程序校验，不依赖模型自述</span></div>
    <div class="quality-grid">${gateHtml}</div>
    ${issueHtml}
    <div class="section-title"><h3>逐轮指标</h3><span class="rule"></span></div>
    <table class="quality-table"><thead><tr><th>轮次</th><th>模式</th><th>版本</th><th>新增</th><th>修订</th><th>回答</th><th>阻塞</th><th>覆盖</th><th>门禁</th></tr></thead><tbody>${rows || `<tr><td colspan="9" class="muted">暂无轮次记录</td></tr>`}</tbody></table>
    <div class="section-title"><h3>版本对比</h3><span class="rule"></span></div>
    <div class="snapshot-toolbar">
      <select id="diff-from">${options}</select>
      <span class="small muted">→</span>
      <select id="diff-to">${optionsTo}</select>
      <button class="btn small" data-act="diff">生成对比</button>
    </div>
    <div id="diff-result">${state.diffData ? renderDiff(state.diffData) : `<p class="small muted">选择两个版本，查看新增、修订、合并与回答。</p>`}</div>`;
}

function renderDiff(diff) {
  const counts = diff.counts || {};
  const rows = (diff.changes || []).map((change) => `<tr>
    <td>${esc(change.kind)}</td><td class="mono">${esc(change.id)}</td><td>${esc(change.title)}</td><td>${esc(change.summary || "")}</td>
  </tr>`).join("");
  return `<div class="round-summary">${esc(diff.from)} → ${esc(diff.to)}：新增 ${counts.added || 0}，修订 ${counts.modified || 0}，回答 ${counts.answered || 0}，合并 ${counts.superseded || 0}，采纳假设 ${counts.assumed || 0}。</div>
    <table class="diff-table"><thead><tr><th>类型</th><th>编号</th><th>标题</th><th>说明</th></tr></thead><tbody>${rows || `<tr><td colspan="4" class="muted">没有差异</td></tr>`}</tbody></table>`;
}

/* ---------------- 原文 ---------------- */

function renderRaw() {
  const snap = state.snapshot;
  if (!snap) return `<div class="empty-state">原文尚未载入。</div>`;
  const mapping = (snap.coverage && snap.coverage.mapping) || {};
  const ignored = new Set((snap.coverage && snap.coverage.ignored) || []);
  const segments = snap.source.segments || [];
  const body = segments.map((seg) => {
    const refs = mapping[seg.seg_id] || [];
    const uncovered = seg.kind !== "heading" && !refs.length && !ignored.has(seg.seg_id);
    const cls = ["seg", seg.kind === "heading" ? "heading" : "", uncovered ? "uncovered" : ""].filter(Boolean).join(" ");
    return `<span class="${cls}" id="seg-${esc(seg.seg_id)}" data-seg="${esc(seg.seg_id)}" title="${esc(seg.seg_id)}${seg.kind === "heading" ? " · 结构标题" : uncovered ? " · 未覆盖" : ""}">${esc(seg.text)}</span> `;
  }).join("");
  return `<div class="raw-toolbar">
      <span class="small muted">${esc(snap.source.segment_count)} 段 · 指纹 <span class="mono">${esc(snap.source.sha256_short)}</span> · 淡红底为尚未覆盖的内容</span>
      <button class="btn small" data-act="copy-raw">复制原文</button>
    </div>
    <div class="raw-paper">${body}</div>`;
}

/* ---------------- 澄清台 ---------------- */

function renderClarify() {
  const root = $("#clarify-panel");
  const count = $("#clarify-count");
  if (!root) return;
  if (!state.data) {
    count.textContent = "0";
    root.innerHTML = `<div class="clarify-empty">选择或新建一次运行。</div>`;
    return;
  }
  const run = state.data.run;
  const snapshot = state.snapshot || {};
  const open = state.data.open_questions || [];
  const blocking = open.filter((q) => q.blocking);
  count.textContent = String(open.length);
  count.classList.toggle("hot", blocking.length > 0);

  if (run.status === "approved") {
    root.innerHTML = `<div class="clarify-empty">快照已批准为 <b class="mono">v1.0</b>。${blocking.length ? `仍有 ${blocking.length} 个未决项，已随基线记录。` : "所有阻塞问题都已处理。"}<br><br><button class="btn small" data-act="handoff-view">查看交接包</button></div>`;
    return;
  }
  if (run.status === "running") {
    root.innerHTML = `<div class="clarify-empty"><span class="spinner"></span> 第 ${run.round} 轮讨论中，等主持人综合后如有阻塞问题会在这里向人提问。</div>`;
    return;
  }
  if (run.status === "failed") {
    root.innerHTML = `<div class="clarify-empty" style="color:var(--red)">运行失败：${esc((run.error || "").slice(0, 160))}</div>
      <div style="margin-top:8px"><button class="btn small accent" data-act="retry">复用已保存的 Agent 发言重试</button></div>`;
    return;
  }
  if (run.status === "stopped") {
    root.innerHTML = `<div class="clarify-empty">运行已停止。</div>`;
    return;
  }
  if (!open.length) {
    root.innerHTML = `<div class="clarify-empty">当前没有未决的待澄清项。${run.status === "awaiting_approval" ? "可以直接批准冻结 v1.0。" : "可以继续下一轮。"}</div>
      ${run.status === "awaiting_approval" ? approveBox(snapshot) : ""}
      ${run.status === "paused" ? `<div style="margin-top:8px"><button class="btn accent small" data-act="continue">继续下一轮</button></div>` : ""}`;
    return;
  }
  const cards = open.map((q) => {
    const suggested = q.suggested_assumption;
    const value = state.answers[q.id] || "";
    return `<div class="q-card ${q.blocking ? "blocking" : ""}">
      <div class="q-head">
        <span class="q-id">${esc(q.id)}</span>
        ${q.blocking ? `<span class="pill blocking">阻塞</span>` : `<span class="pill">一般</span>`}
        <span class="small muted">${esc(q.title || "")}</span>
      </div>
      <div class="q-text">${esc(q.question || "")}</div>
      ${q.why ? `<div class="q-why">${esc(q.why)}</div>` : ""}
      ${q.options && q.options.length ? `<div class="q-opts">${q.options.map((opt) => `<button class="opt" data-suggest="${esc(q.id)}" data-value="${esc(opt)}">${esc(opt)}</button>`).join("")}</div>` : ""}
      ${suggested ? `<div class="suggest">建议默认：${esc(suggested)} <button class="link" data-suggest="${esc(q.id)}" data-value="${esc(suggested)}">采用</button></div>` : ""}
      <textarea id="ans-${esc(q.id)}" data-oq="${esc(q.id)}" placeholder="写下你的决定或口径 …">${esc(value)}</textarea>
      <div class="q-actions"><button class="btn small accent" data-act="answer" data-oq="${esc(q.id)}">记录澄清</button></div>
    </div>`;
  }).join("");
  const pending = (state.data.pending_clarifications || []);
  const pendingHtml = pending.length
    ? `<div class="pending-list">${pending.map((p) => `<li>已记录 ${esc(p.oq_id)}：${esc(String(p.answer || "").slice(0, 46))}</li>`).join("")}</div>`
    : "";
  const continueBtn = run.status === "paused" || run.status === "created"
    ? `<div style="margin-top:10px"><button class="btn accent small" data-act="continue">带着以上澄清进入下一轮</button></div>`
    : "";
  const approve = run.status === "awaiting_approval" ? approveBox(snapshot) : "";
  root.innerHTML = `${cards}${pendingHtml}${continueBtn}${approve}`;
}

function approveBox(snapshot) {
  const blocking = snapshot && snapshot.metrics ? (snapshot.metrics.blocking_open || 0) : 0;
  return `<div class="approval-box">
    <p>${blocking ? `仍有 <b>${blocking}</b> 个阻塞待澄清项。可以带风险批准，但未决项会原样写入 v1.0 基线。` : "所有质量门禁已通过，可以冻结为 v1.0 基线。"}</p>
    ${blocking ? `<label class="checkline"><input type="checkbox" id="accept-open"> 我已确认并接受这些未决风险</label>` : ""}
    <button class="btn accent small" data-act="approve">批准并冻结 v1.0</button>
  </div>`;
}

/* ---------------- 交接 ---------------- */

function renderHandoff() {
  const root = $("#handoff-panel");
  if (!root) return;
  const run = state.data && state.data.run;
  if (!run) {
    root.innerHTML = `<div class="handoff-box muted">选择运行后查看。</div>`;
    return;
  }
  if (run.status !== "approved") {
    root.innerHTML = `<div class="handoff-box muted">批准 v1.0 后生成 <span class="mono">handoff.json</span> 与可直接 POST 给编排器的 6 字段任务包。</div>`;
    return;
  }
  if (!state.handoff) {
    root.innerHTML = `<div class="handoff-box muted"><span class="spinner"></span> 正在读取交接包 …</div>`;
    return;
  }
  const h = state.handoff;
  const tasks = h.tasks || [];
  const summary = {
    requirements: (h.requirements || []).length,
    constraints: (h.constraints || []).length,
    tasks: tasks.length,
    blocking: (h.open_blocking || []).length,
    assumptions: (h.assumptions || []).length,
  };
  root.innerHTML = `<div class="handoff-box">
    <div class="row"><span>需求 / 约束</span><b>${summary.requirements} / ${summary.constraints}</b></div>
    <div class="row"><span>任务种子</span><b>${summary.tasks}</b></div>
    <div class="row"><span>阻塞未决</span><b style="color:${summary.blocking ? "var(--red)" : "var(--green)"}">${summary.blocking}</b></div>
    <div class="row"><span>默认假设</span><b>${summary.assumptions}</b></div>
    <div class="row"><span>快照版本</span><b>${esc(h.source_run ? h.source_run.snapshot_version : "")}</b></div>
    <div class="row"><span>来源指纹</span><b>${esc((h.source_run && h.source_run.original_sha256 || "").slice(0, 12))}</b></div>
  </div>
  <div style="display:flex;gap:6px;flex-wrap:wrap;margin-top:9px">
    <button class="btn small" data-act="handoff-view">查看 JSON</button>
    <button class="btn small accent" data-act="push">推送编排器</button>
    <a class="btn small" href="/api/runs/${run.run_id}/document?version=v1.0&download=1">下载文档</a>
  </div>`;
}

/* ---------------- 事件绑定 ---------------- */

function bindEvents() {
  document.addEventListener("click", async (event) => {
    const tabBtn = event.target.closest("[data-tab]");
    if (tabBtn) {
      setTab(tabBtn.dataset.tab);
      return;
    }
    const runBtn = event.target.closest("[data-run]");
    if (runBtn) {
      await selectRun(runBtn.dataset.run);
      return;
    }
    const versionBtn = event.target.closest("[data-version]");
    if (versionBtn) {
      await loadSnapshot(versionBtn.dataset.version);
      renderAll();
      return;
    }
    const segTarget = event.target.closest("[data-seg]");
    if (segTarget && !event.target.closest("[data-act]")) {
      activateSeg(segTarget.dataset.seg);
      return;
    }
    const itemTarget = event.target.closest("[data-item]");
    if (itemTarget) {
      setTab("snapshot");
      setTimeout(() => {
        const card = document.getElementById(`item-${itemTarget.dataset.item}`);
        if (card) card.scrollIntoView({ behavior: "smooth", block: "center" });
      }, 60);
      return;
    }
    const suggest = event.target.closest("[data-suggest]");
    if (suggest) {
      const oq = suggest.dataset.suggest;
      const area = document.getElementById(`ans-${oq}`);
      if (area) {
        area.value = suggest.dataset.value || "";
        state.answers[oq] = area.value;
        area.focus();
      }
      return;
    }
    const act = event.target.closest("[data-act]");
    if (act) {
      await handleAction(act.dataset.act, act);
    }
  });

  $("#run-select").addEventListener("change", (event) => selectRun(event.target.value));
  $("#btn-new").addEventListener("click", openNewRunModal);
  $("#btn-clear-events").addEventListener("click", () => { state.events = []; state.since = 0; renderEvents(); });

  document.addEventListener("input", (event) => {
    if (event.target.id === "snapshot-search") {
      state.search = event.target.value;
      filterItems();
    }
    if (event.target.matches("#clarify-panel textarea[data-oq]")) {
      state.answers[event.target.dataset.oq] = event.target.value;
    }
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape") closeModal();
  });
}

async function handleAction(action, element) {
  try {
    if (action === "new") return openNewRunModal();
    if (action === "load-demo-new") return openNewRunModal(true);
    if (action === "tab") return setTab("snapshot");
    if (action === "goto-clarify") {
      $("#clarify-panel").scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }
    if (action === "back-latest") {
      await loadSnapshot("latest");
      renderAll();
      return;
    }
    if (action === "continue") {
      const status = state.data.run.status;
      if (status === "paused") {
        const pending = (state.data.pending_clarifications || []).length;
        if (!pending && !confirm("还没有记录任何澄清。继续会用主持人建议的默认假设推进，确定继续？")) return;
      }
      await API.post(`/api/runs/${state.runId}/continue`, {});
      toast("已继续下一轮");
      await refreshState(false);
      schedulePoll(400);
      return;
    }
    if (action === "retry") {
      if (!confirm("将复用上一轮已保存的 4 位 Agent 发言，只重跑主持人综合，然后继续后续轮次。确定重试？")) return;
      await API.post(`/api/runs/${state.runId}/retry`, {});
      toast("已开始重试：只重跑主持人");
      await refreshState(false);
      schedulePoll(500);
      return;
    }
    if (action === "stop") {
      if (!confirm("停止后本轮未完成的内容不会发布，确定停止？")) return;
      await API.post(`/api/runs/${state.runId}/stop`, { reason: "人工在网页停止" });
      toast("已停止");
      await refreshState(true);
      renderAll();
      return;
    }
    if (action === "answer") {
      const oq = element.dataset.oq;
      const area = document.getElementById(`ans-${oq}`);
      const answer = (area ? area.value : state.answers[oq] || "").trim();
      if (!answer) { toast("请先填写澄清内容", "error"); return; }
      const release = loadingButton(element, "记录中");
      try {
        const res = await API.post(`/api/runs/${state.runId}/clarifications`, { oq_id: oq, answer, by: "web" });
        state.data = res.state;
        state.answers[oq] = "";
        toast(`已记录 ${oq}`);
        renderAll();
      } finally { release(); }
      return;
    }
    if (action === "approve") return openApproveModal();
    if (action === "handoff-view") {
      if (!state.handoff) await loadHandoff();
      if (!state.handoff) { toast("交接包尚未生成", "error"); return; }
      modal(`<button class="close" data-act="close-modal">×</button>
        <h3>下游交接包</h3>
        <p class="sub">handoff.json · 包含需求、约束、未决项、任务种子与来源引用</p>
        <pre style="max-height:56vh;overflow:auto;background:#20241f;color:#f8f2e5;padding:14px;border-radius:10px;font-size:11px;line-height:1.55">${esc(JSON.stringify(state.handoff, null, 2))}</pre>
        <div class="modal-actions"><button class="btn" data-act="close-modal">关闭</button></div>`);
      return;
    }
    if (action === "push") return openPushModal();
    if (action === "close-modal") return closeModal();
    if (action === "copy-raw") {
      const text = (state.snapshot.source.segments || []).map((s) => s.text).join("\n");
      await navigator.clipboard.writeText(text);
      toast("原文已复制");
      return;
    }
    if (action === "diff") {
      const from = $("#diff-from").value;
      const to = $("#diff-to").value;
      if (from === to) { toast("请选择两个不同版本", "error"); return; }
      const data = await API.get(`/api/runs/${state.runId}/diff?from=${encodeURIComponent(from)}&to=${encodeURIComponent(to)}`);
      state.diffData = data;
      $("#diff-result").innerHTML = renderDiff(data);
      return;
    }
    if (action === "error") {
      const run = state.data.run;
      modal(`<button class="close" data-act="close-modal">×</button><h3>运行错误</h3><p class="sub">${esc(run.run_id)}</p>
        <pre style="white-space:pre-wrap;background:var(--red-soft);padding:12px;border-radius:8px;font-size:12px">${esc(run.error || "（没有错误信息）")}</pre>
        <div class="modal-actions"><button class="btn" data-act="close-modal">关闭</button></div>`);
      return;
    }
  } catch (err) {
    toast(err.message || String(err), "error");
  }
}

/* ---------------- 原文定位 ---------------- */

function activateSeg(segId) {
  if (!segId) return;
  state.tab = "raw";
  $$("#tabs button").forEach((btn) => btn.classList.toggle("active", btn.dataset.tab === "raw"));
  renderTab();
  requestAnimationFrame(() => {
    const el = document.getElementById(`seg-${segId}`);
    if (!el) { toast("当前快照没有这个原文段", "error"); return; }
    el.classList.add("active");
    el.scrollIntoView({ behavior: "smooth", block: "center" });
    setTimeout(() => el.classList.remove("active"), 2600);
  });
}

/* ---------------- 新建运行 ---------------- */

async function openNewRunModal(prefillDemo = false) {
  modal(`<button class="close" data-act="close-modal">×</button>
    <h3>新建需求圆桌</h3>
    <p class="sub">贴入用户原话、会议记录或需求草稿。系统会切段编号，4 位 Agent 先独立解读，再由主持人综合。</p>
    <form id="new-run-form">
      <div class="field"><label>项目标题</label><input type="text" id="new-title" placeholder="例如：高校实验室设备预约管理系统"></div>
      <div class="field">
        <label>原始需求</label>
        <textarea id="new-input" placeholder="把用户原话或会议记录原样贴进来，越原汁原味越好 …"></textarea>
        <div class="hint">支持 Markdown；标题行会作为结构，不计入覆盖率。最少 20 个字符。</div>
      </div>
      <div class="inline-fields">
        <div class="field"><label>讨论轮数上限</label><select id="new-rounds">
          <option value="3">3 轮（快）</option>
          <option value="4" selected>4 轮（推荐：发散→质询→收敛→定稿）</option>
          <option value="5">5 轮（更充分）</option>
        </select></div>
        <div class="field"><label>澄清策略</label><select id="new-auto">
          <option value="0" selected>到澄清门暂停，等人回答</option>
          <option value="1">不暂停，允许主持人写默认假设</option>
        </select></div>
      </div>
      <div class="field"><button type="button" class="btn small" id="btn-demo-fill">载入实验室预约演示案例</button></div>
      <div class="modal-actions">
        <button type="button" class="btn" data-act="close-modal">取消</button>
        <button type="submit" class="btn accent" id="btn-create">创建并开始</button>
      </div>
    </form>`);
  $("#btn-demo-fill").addEventListener("click", async () => {
    try {
      const text = await fetch("/api/demo-case").then((r) => r.text());
      $("#new-input").value = text;
      if (!$("#new-title").value) $("#new-title").value = "高校实验室设备预约管理系统";
    } catch (err) { toast("加载案例失败", "error"); }
  });
  $("#new-run-form").addEventListener("submit", async (event) => {
    event.preventDefault();
    const text = $("#new-input").value.trim();
    const title = $("#new-title").value.trim();
    if (text.length < 20) { toast("原始需求太短，至少 20 个字符", "error"); return; }
    const button = $("#btn-create");
    const release = loadingButton(button, "创建中");
    try {
      const res = await API.post("/api/runs", {
        input_text: text,
        title,
        max_rounds: Number($("#new-rounds").value),
        auto_assume: $("#new-auto").value === "1",
      });
      closeModal();
      await loadRuns();
      await selectRun(res.run_id);
      toast("已创建，圆桌开始讨论");
    } catch (err) {
      toast(err.message, "error");
    } finally { release(); }
  });
  if (prefillDemo) {
    try {
      const text = await fetch("/api/demo-case").then((r) => r.text());
      $("#new-input").value = text;
      $("#new-title").value = "高校实验室设备预约管理系统";
    } catch (err) { /* 忽略 */ }
  }
}

/* ---------------- 批准 ---------------- */

function openApproveModal() {
  const snap = state.snapshot || {};
  const blocking = (snap.metrics && snap.metrics.blocking_open) || 0;
  const pending = (state.data.pending_clarifications || []).length;
  modal(`<button class="close" data-act="close-modal">×</button>
    <h3>批准并冻结 v1.0</h3>
    <p class="sub">批准后生成只读基线、需求文档与下游交接包；${pending ? `另有 ${pending} 条已记录澄清会先落库。` : ""}</p>
    ${blocking ? `<div class="approval-box"><p style="color:var(--red)">仍有 ${blocking} 个阻塞待澄清项。未决项会写入基线并标记为待用户确认。</p><label class="checkline"><input type="checkbox" id="approve-risk"> 我接受带未决项批准</label></div>` : ""}
    <div class="field" style="margin-top:12px"><label>批准人</label><input type="text" id="approve-by" value="web-user"></div>
    <div class="field"><label>批准备注（可选）</label><input type="text" id="approve-note" placeholder="例如：作为课程大作业 v1.0 基线"></div>
    <div class="modal-actions"><button class="btn" data-act="close-modal">取消</button><button class="btn accent" id="btn-approve">确认批准</button></div>`);
  $("#btn-approve").addEventListener("click", async (event) => {
    const accept = blocking ? !!($("#approve-risk") && $("#approve-risk").checked) : false;
    if (blocking && !accept) { toast("请先勾选接受未决风险", "error"); return; }
    const release = loadingButton(event.currentTarget, "批准中");
    try {
      const res = await API.post(`/api/runs/${state.runId}/approve`, {
        by: $("#approve-by").value.trim() || "web-user",
        note: $("#approve-note").value.trim(),
        accept_open: accept,
      });
      state.handoff = res.handoff || null;
      closeModal();
      toast("已冻结 v1.0");
      await refreshState(true);
      renderAll();
    } catch (err) {
      toast(err.message, "error");
    } finally { release(); }
  });
}

/* ---------------- 推送编排器 ---------------- */

function openPushModal() {
  modal(`<button class="close" data-act="close-modal">×</button>
    <h3>推送到后半部分编排器</h3>
    <p class="sub">把交接包转换为编排器兼容的 6 字段任务列表，POST 到 <span class="mono">/api/start</span>。该接口是同步拆解，可能需要 1-3 分钟。</p>
    <div class="field"><label>编排器地址</label><input type="text" id="push-url" value="http://127.0.0.1:8000"></div>
    <div class="round-summary" style="font-size:11.5px">任务名保留 REQ 编号，便于回查快照；依赖边由编排器重新分析，本包不提供。</div>
    <div id="push-result"></div>
    <div class="modal-actions"><button class="btn" data-act="close-modal">关闭</button><button class="btn accent" id="btn-push">开始推送</button></div>`);
  $("#btn-push").addEventListener("click", async (event) => {
    const url = $("#push-url").value.trim();
    if (!url) return;
    const release = loadingButton(event.currentTarget, "推送中（最长 3 分钟）");
    $("#push-result").innerHTML = `<p class="small muted">正在等待编排器 /api/start 返回 …</p>`;
    try {
      const res = await API.post(`/api/runs/${state.runId}/push`, { url, timeout: 300 });
      if (res.ok) {
        const progress = res.data && res.data.progress ? res.data.progress : {};
        $("#push-result").innerHTML = `<div class="round-summary" style="border-left-color:var(--green)">推送成功：编排器已接收任务清单，实例状态 ${esc(progress.status || "accepted")}，任务数 ${esc(progress.total ?? "")}。</div>`;
        toast("已推送到编排器");
      } else {
        $("#push-result").innerHTML = `<div class="round-summary" style="border-left-color:var(--red)">推送失败（HTTP ${esc(res.status || 0)}）：<br><span class="mono small">${esc((res.error || "").slice(0, 500))}</span></div>`;
      }
    } catch (err) {
      $("#push-result").innerHTML = `<div class="round-summary" style="border-left-color:var(--red)">推送失败：${esc(err.message)}</div>`;
    } finally { release(); }
  });
}
