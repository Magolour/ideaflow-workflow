from __future__ import annotations

import copy
import json
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass, replace
from datetime import datetime
from typing import Any

from .config import Settings, new_run_id, now_iso
from .intake import build_source, source_for_prompt, verify_sources
from .llm import ChatResult, LLMClient, LLMError, LocalClient, OpenAICompatClient
from .model import (
    TYPE_LABELS,
    apply_ops,
    diff_snapshots,
    finalize_snapshot,
    new_snapshot,
    normalize_severity,
    set_round_summary,
)
from .roles import (
    MODERATOR_SYSTEM,
    ROLE_PROFILES,
    discussant_system,
    discussant_user,
    moderator_user,
)
from .snapshot import (
    MODE_LABELS,
    build_handoff_requirement_brief,
    compact_snapshot,
    render_diff_markdown,
    render_markdown,
    snapshot_digest,
)
from .store import RunStore, StoreError


class RunError(RuntimeError):
    pass


@dataclass
class RoundContext:
    round_no: int
    mode: str
    is_final: bool
    source_text: str
    source: dict
    snapshot: dict
    snapshot_view: dict | None
    unresolved: list[dict]
    clarifications: list[dict]
    next_focus: list[str]


class Orchestrator:
    """一次需求圆桌运行的状态机与编排器。"""

    def __init__(self, store: RunStore, settings: Settings, run_id: str, client: LLMClient | None = None):
        self.store = store
        self.settings = settings
        self.run_id = run_id
        self.client = client or OpenAICompatClient(settings)
        self._run_lock = threading.RLock()

    # ------------------------------------------------------------------ 创建

    @classmethod
    def create(
        cls,
        store: RunStore,
        settings: Settings,
        input_text: str,
        title: str = "",
        client: LLMClient | None = None,
        max_rounds: int | None = None,
        auto_assume: bool = False,
    ) -> "Orchestrator":
        rounds = settings.clamp_rounds(max_rounds)
        settings = replace(settings, max_rounds=rounds, auto_assume=auto_assume)
        if settings.local_agents and client is None:
            client = LocalClient()
        source = build_source(input_text, title)
        source["created_at"] = now_iso()
        run_id = new_run_id()
        config = {
            "max_rounds": rounds,
            "auto_assume": auto_assume,
            "roles": list(settings.role_keys),
            "client": client.describe() if client else {"client": "openai-compatible"},
            "model": settings.model,
            "clarification_gate": settings.clarification_gate,
            "local_moderator": bool(settings.local_moderator),
            "local_agents": bool(settings.local_agents),
        }
        run = {
            "run_id": run_id,
            "title": title.strip() or source["title"],
            "status": "created",
            "round": 0,
            "max_rounds": rounds,
            "latest_version": "v0.0",
            "created_at": now_iso(),
            "updated_at": now_iso(),
            "event_seq": 0,
            "config": config,
            "agents": {
                key: {"status": "idle", "calls": 0, "tokens": 0, "last_error": None}
                for key in settings.role_keys
            },
            "budget": {"calls": 0, "tokens": 0, "max_calls": 40, "max_tokens": 500_000},
            "gate_passed": False,
            "clarifications": [],
            "last_findings": [],
            "last_focus": [],
            "last_summary": "",
            "metrics": {},
            "quality": {},
            "error": None,
            "approved_at": None,
            "approved_by": None,
        }
        initial = new_snapshot(source, run["title"], f"PRJ-{datetime.now():%Y%m%d%H%M}", rounds)
        initial = finalize_snapshot(initial, source, version="v0.0")
        store.create(run, source["raw_text"], source)
        store.save_snapshot(run_id, initial)
        store.event(run_id, "run_created", title=run["title"], max_rounds=rounds, model=settings.model)
        return cls(store, settings, run_id, client=client)

    @classmethod
    def load(cls, store: RunStore, settings: Settings, run_id: str, client: LLMClient | None = None) -> "Orchestrator":
        run = store.load(run_id)
        settings = replace(
            settings,
            max_rounds=int(run.get("max_rounds", settings.max_rounds)),
            auto_assume=bool(run.get("config", {}).get("auto_assume", False)),
            local_moderator=bool(run.get("config", {}).get("local_moderator", False)),
            local_agents=bool(run.get("config", {}).get("local_agents", False)),
        )
        if client is None:
            config = run.get("config", {})
            client_name = config.get("client", {}).get("client")
            if client_name == "mock":
                from .llm import MockClient

                client = MockClient()
            elif client_name == "local":
                client = LocalClient()
            elif client_name == "replay":
                from .llm import ReplayClient

                client = ReplayClient(config.get("client", {}).get("replay_path"))
        if settings.local_agents and client is None:
            client = LocalClient()
        return cls(store, settings, run_id, client=client)

    # ------------------------------------------------------------------ 基础

    def _load(self) -> dict:
        return self.store.load(self.run_id)

    def _snapshot(self) -> dict:
        snapshot = self.store.latest_snapshot(self.run_id)
        if snapshot is None:
            raise StoreError("运行缺少快照")
        return snapshot

    def _source(self) -> dict:
        return self.store.read_json(self.store.path(self.run_id, "source.json"))

    def _emit(self, event_type: str, **fields) -> dict:
        return self.store.event(self.run_id, event_type, **fields)

    def _set_status(self, status: str, **fields) -> dict:
        def mutate(run: dict) -> None:
            run["status"] = status
            for key, value in fields.items():
                run[key] = value
            if status in ("approved", "stopped", "failed"):
                run["finished_at"] = now_iso()

        return self.store.update(self.run_id, mutate)

    def _record_call(self, agent: str, result: dict | None, usage: dict | None, status: str, error: str | None = None) -> None:
        def mutate(run: dict) -> None:
            budget = run.setdefault("budget", {"calls": 0, "tokens": 0, "max_calls": 40, "max_tokens": 500_000})
            budget["calls"] = int(budget.get("calls", 0)) + 1
            tokens = int((usage or {}).get("total_tokens") or 0)
            budget["tokens"] = int(budget.get("tokens", 0)) + tokens
            entry = run.setdefault("agents", {}).setdefault(
                agent, {"status": "idle", "calls": 0, "tokens": 0, "last_error": None}
            )
            entry["calls"] = int(entry.get("calls", 0)) + 1
            entry["tokens"] = int(entry.get("tokens", 0)) + tokens
            entry["status"] = status
            entry["last_error"] = (error or "")[:500] or None
            entry["last_call_at"] = now_iso()

        self.store.update(self.run_id, mutate)

    def _check_budget(self) -> None:
        run = self._load()
        budget = run.get("budget", {})
        if int(budget.get("calls", 0)) >= int(budget.get("max_calls", 40)):
            raise RunError("本轮预算已用尽（调用次数上限），请人工接管或提高预算")

    def _pending_clarifications(self, run: dict) -> list[dict]:
        return [item for item in run.get("clarifications", []) if not item.get("incorporated_round")]

    def _mode_for(self, round_no: int, max_rounds: int) -> str:
        if round_no <= 1:
            return "diverge"
        if round_no >= max_rounds:
            return "finalize"
        if round_no == max_rounds - 1:
            return "converge"
        return "challenge"

    # ------------------------------------------------------------------ 主循环

    def start_async(self) -> None:
        thread = threading.Thread(target=self._safe_run, name=f"reqround-{self.run_id}", daemon=True)
        thread.start()

    def _safe_run(self) -> None:
        try:
            self.run_until_pause()
        except Exception as exc:  # 后台线程必须有兜底，否则服务看不到失败
            self._fail(str(exc))

    def run_until_pause(self) -> dict:
        with self._run_lock:
            run = self._load()
            if run["status"] == "created":
                self._set_status("running")
                self._emit("run_started", title=run["title"], max_rounds=run["max_rounds"],
                           mode="diverge", model=run["config"].get("model"))
            try:
                while True:
                    run = self._load()
                    if run["status"] in ("approved", "stopped", "failed", "awaiting_approval"):
                        return run
                    if int(run.get("round", 0)) >= int(run["max_rounds"]):
                        self._to_awaiting_approval("已达到轮数上限")
                        return self._load()
                    if self._should_pause(run):
                        self._pause("第 %d 轮后存在阻塞待澄清项，等待人工澄清" % int(run["round"]))
                        return self._load()
                    round_no = int(run["round"]) + 1
                    _snapshot, convergence = self._run_round(round_no)
                    self._emit(
                        "convergence_check",
                        round=round_no,
                        converged=convergence.get("converged"),
                        reasons=convergence.get("reasons", []),
                        votes=convergence.get("votes", []),
                        blocking_open=convergence.get("blocking_open"),
                        coverage_rate=convergence.get("coverage_rate"),
                    )
                    if convergence.get("converged"):
                        self._to_awaiting_approval(
                            "第 %d 轮收敛：%s" % (round_no, "；".join(convergence.get("reasons", [])) or "全部质量门禁通过")
                        )
                        return self._load()
                    run = self._load()
                    if int(run.get("round", 0)) >= int(run["max_rounds"]):
                        reason = "已完成全部 %d 轮讨论" % int(run["max_rounds"])
                        if not convergence.get("converged"):
                            reason += "；仍有未达标项：" + "；".join(convergence.get("reasons", []))[:300]
                        self._to_awaiting_approval(reason)
                        return self._load()
                # 正常不会走到这里
            except Exception as exc:
                self._fail(str(exc))
                return self._load()

    def _should_pause(self, run: dict) -> bool:
        if bool(run.get("config", {}).get("auto_assume")):
            return False
        if run.get("gate_passed"):
            return False
        gate = int(run.get("config", {}).get("clarification_gate", max(1, int(run["max_rounds"]) - 1)))
        if int(run.get("round", 0)) < gate or int(run.get("round", 0)) >= int(run["max_rounds"]):
            return False
        snapshot = self._snapshot()
        return int(snapshot.get("metrics", {}).get("blocking_open", 0)) > 0

    def _pause(self, reason: str) -> None:
        snapshot = self._snapshot()
        questions = self._open_questions(snapshot)
        self._set_status("paused", pause_reason=reason)
        self._emit("run_paused", reason=reason, round=self._load().get("round"), questions=questions)
        if questions:
            self._emit("clarification_requested", round=self._load().get("round"), questions=questions)

    def _to_awaiting_approval(self, reason: str) -> None:
        snapshot = self._snapshot()
        metrics = snapshot.get("metrics", {})
        self._set_status(
            "awaiting_approval",
            latest_version=snapshot.get("version"),
            approval_reason=reason,
        )
        self._emit(
            "run_awaiting_approval",
            version=snapshot.get("version"),
            reason=reason,
            blocking_open=metrics.get("blocking_open", 0),
            quality_passed=snapshot.get("quality", {}).get("passed", False),
        )

    def _fail(self, message: str) -> None:
        try:
            run = self._load()
            if run.get("status") in ("approved", "stopped"):
                return
            self._set_status("failed", error=message[:1000])
            self._emit("run_failed", error=message[:1000])
        except Exception:
            pass

    # ------------------------------------------------------------------ 单轮

    def _build_context(self, round_no: int, run: dict, snapshot: dict, source: dict) -> RoundContext:
        mode = self._mode_for(round_no, int(run["max_rounds"]))
        is_final = mode == "finalize"
        unresolved = [
            f for f in run.get("last_findings", [])
            if f.get("severity") == "blocking"
        ]
        clarifications = self._pending_clarifications(run)
        snapshot_view = None if round_no == 1 else compact_snapshot(snapshot)
        return RoundContext(
            round_no=round_no,
            mode=mode,
            is_final=is_final,
            source_text=source_for_prompt(source),
            source=source,
            snapshot=snapshot,
            snapshot_view=snapshot_view,
            unresolved=unresolved,
            clarifications=clarifications,
            next_focus=list(run.get("last_focus", [])),
        )

    def _run_round(self, round_no: int) -> tuple[dict, dict]:
        run = self._load()
        source = self._source()
        base_snapshot = self._snapshot()
        context = self._build_context(round_no, run, base_snapshot, source)
        started = time.time()
        self._emit(
            "round_started",
            round=round_no,
            mode=context.mode,
            mode_label=MODE_LABELS.get(context.mode, context.mode),
            snapshot_version=base_snapshot.get("version"),
            note="定稿轮" if context.is_final else "",
        )
        outputs = self._collect_outputs(context, self.store.transcript(self.run_id))
        return self._finish_round(round_no, context, base_snapshot, outputs, started)

    def _finish_round(
        self,
        round_no: int,
        context: RoundContext,
        base_snapshot: dict,
        outputs: list[dict],
        started: float,
    ) -> tuple[dict, dict]:
        """把已收集到的 Agent 发言综合成新版本；重试时也可复用已保存的发言。"""
        run = self._load()
        source = self._source()
        ok_agents = [o for o in outputs if o.get("status") == "ok"]
        if not ok_agents:
            raise RunError("本轮所有 Agent 都调用失败，无法综合")
        findings = [f for output in outputs for f in output.get("findings", [])]
        mod_started = time.time()
        self._emit("moderator_started", round=round_no, agents_ok=len(ok_agents), findings=len(findings))
        moderator = self._call_moderator(context, outputs, base_snapshot)
        moderator_converged = bool(moderator.get("converged"))
        ops = moderator.get("ops") or []
        if not isinstance(ops, list):
            ops = []
        ops = self._ensure_answer_ops(ops, base_snapshot, context.clarifications)
        version = self._next_round_version(round_no)
        snapshot, applied, rejected = apply_ops(
            base_snapshot, ops, source, round_no, version,
            transcript=self.store.transcript(self.run_id), by="moderator",
        )
        if moderator.get("project_summary"):
            snapshot["project"]["summary"] = str(moderator["project_summary"]).strip()[:500]
        snapshot["status"] = "candidate" if context.is_final else "draft"
        finalize_snapshot(snapshot, source, version=version)
        summary = self._build_round_summary(
            round_no, context, base_snapshot, snapshot, outputs, moderator, applied, rejected,
            int((time.time() - started) * 1000),
        )
        set_round_summary(snapshot, summary)
        diff = diff_snapshots(base_snapshot, snapshot)
        self.store.save_snapshot(self.run_id, snapshot)
        self.store.save_document(self.run_id, version, render_markdown(snapshot, source, run, diff))
        self.store.path(self.run_id, "documents", f"变更_{version}.md").write_text(
            render_diff_markdown(diff, snapshot["project"].get("title", "")), encoding="utf-8"
        )
        self._mark_clarifications(round_no)
        self._update_run_after_round(round_no, snapshot, summary, outputs)
        convergence = self._evaluate_convergence(snapshot, outputs, context.mode, moderator_converged)
        self.store.update(
            self.run_id,
            lambda r: r.update({"last_convergence": convergence}),
        )
        self._emit(
            "snapshot_published",
            round=round_no,
            version=version,
            digest=snapshot_digest(snapshot),
            diff=diff.get("counts", {}),
            summary=summary.get("summary", ""),
            converged=convergence.get("converged"),
            rejected_ops=len(rejected),
            duration_ms=int((time.time() - mod_started) * 1000),
        )
        return snapshot, convergence

    def retry_failed_round(self) -> dict:
        """失败恢复：复用上一轮已保存的 Agent 发言，只重跑主持人综合。

        这样单次 Agent 调用很贵时，不会因为主持人一次截断就全部重来。
        """
        with self._run_lock:
            run = self._load()
            if run.get("status") != "failed":
                raise RunError("当前运行不是失败状态，不需要重试")
            round_no = int(run.get("round", 0)) + 1
            records = [
                record for record in self.store.transcript(self.run_id)
                if int(record.get("round", 0)) == round_no
                and record.get("kind") == "discussant"
                and record.get("status") == "ok"
            ]
            if not records:
                raise RunError("没有找到可复用的 Agent 发言，请新建运行")
            outputs = []
            for record in records:
                response = record.get("response") or {}
                outputs.append(
                    {
                        "agent": record["agent"],
                        "status": "ok",
                        "response": response,
                        "findings": response.get("findings", []),
                        "proposed_items": response.get("proposed_items", []),
                        "attempts": record.get("attempts", 1),
                        "duration_ms": record.get("duration_ms", 0),
                        "usage": record.get("usage", {}),
                    }
                )
            order = {role: index for index, role in enumerate(self.settings.role_keys)}
            outputs.sort(key=lambda item: order.get(item.get("agent"), 99))
            source = self._source()
            snapshot = self._snapshot()
            if int(snapshot.get("round", 0)) >= round_no:
                previous = f"v0.{round_no - 1}" if round_no > 1 else "v0.0"
                try:
                    snapshot = self.store.load_snapshot(self.run_id, previous)
                except StoreError:
                    pass
            context = self._build_context(round_no, run, snapshot, source)
            self._set_status("running", error=None)
            self._emit(
                "retry_started",
                round=round_no,
                agents=[record["agent"] for record in records],
                reason="复用已保存的 Agent 发言，只重跑主持人综合",
            )
            return self._finish_round(round_no, context, snapshot, outputs, time.time())[0]

    # ------------------------------------------------------------------ Agent 调用

    def _collect_outputs(self, context: RoundContext, transcript: list[dict]) -> list[dict]:
        outputs: list[dict] = []
        roles = list(self.settings.role_keys)
        with ThreadPoolExecutor(max_workers=max(1, len(roles)), thread_name_prefix="reqround-agent") as pool:
            futures = {
                pool.submit(self._run_agent, role, context, index, transcript): role
                for index, role in enumerate(roles)
            }
            for future in as_completed(futures):
                role = futures[future]
                try:
                    outputs.append(future.result())
                except Exception as exc:
                    outputs.append(
                        {
                            "agent": role,
                            "status": "failed",
                            "error": str(exc),
                            "response": {},
                            "findings": [],
                            "proposed_items": [],
                            "attempts": 0,
                            "duration_ms": 0,
                        }
                    )
        order = {role: index for index, role in enumerate(roles)}
        outputs.sort(key=lambda item: order.get(item.get("agent"), 99))
        return outputs

    def _run_agent(self, role: str, context: RoundContext, index: int, transcript: list[dict]) -> dict:
        profile = ROLE_PROFILES[role]
        system = discussant_system(role, context.round_no, context.mode)
        user = discussant_user(
            role,
            context.round_no,
            context.mode,
            context.source_text,
            context.snapshot_view,
            context.unresolved,
            context.clarifications,
            context.next_focus,
        )
        started = time.time()
        self._emit(
            "agent_started",
            round=context.round_no,
            agent=role,
            name=profile["name"],
            color=profile["color"],
            mode=context.mode,
        )
        try:
            result = self._call_json(
                agent=role,
                system=system,
                user=user,
                temperature=min(0.8, self.settings.temperature_discuss + 0.04 * index),
                max_tokens=self.settings.max_tokens_discuss,
                purpose=f"{role}:r{context.round_no}:{context.mode}",
                validate=lambda data: self._validate_agent_output(data),
            )
        except LLMError as exc:
            error = f"{exc.code}: {exc}"
            self._record_call(role, None, None, "failed", error)
            duration = int((time.time() - started) * 1000)
            self._emit(
                "agent_failed",
                round=context.round_no,
                agent=role,
                name=profile["name"],
                error=error[:800],
                duration_ms=duration,
            )
            record = {
                "round": context.round_no,
                "agent": role,
                "kind": "discussant",
                "status": "failed",
                "started_at": now_iso(),
                "duration_ms": duration,
                "error": error[:800],
                "response": {},
                "attempts": getattr(exc, "attempts", 0),
                "context_manifest": self._manifest(context),
            }
            self.store.append_transcript(self.run_id, record)
            return {
                "agent": role,
                "status": "failed",
                "error": error,
                "response": {},
                "findings": [],
                "proposed_items": [],
                "attempts": 1,
                "duration_ms": duration,
            }

        data = result.data
        data = self._normalize_agent_output(data)
        findings = self._decorate_findings(role, context, data.get("findings", []), transcript)
        data["findings"] = [f for f in findings]
        proposed = []
        for idx, raw in enumerate(data.get("proposed_items", [])[: self.settings.max_items_per_agent], 1):
            if isinstance(raw, dict):
                raw = dict(raw)
                raw["proposal_id"] = f"P-R{context.round_no}-{role}-{idx:02d}"
                raw["proposed_by"] = role
                proposed.append(raw)
        data["proposed_items"] = proposed
        usage = result.usage or {}
        duration = int((time.time() - started) * 1000)
        self._record_call(role, result.data, usage, "ok")
        self._emit(
            "agent_done",
            round=context.round_no,
            agent=role,
            name=profile["name"],
            stance=str(data.get("stance") or "")[:160],
            findings=len(findings),
            items=len(proposed),
            vote=data.get("vote"),
            duration_ms=duration,
            usage=usage,
        )
        record = {
            "round": context.round_no,
            "agent": role,
            "kind": "discussant",
            "status": "ok",
            "started_at": now_iso(),
            "duration_ms": duration,
            "usage": usage,
            "attempts": 1,
            "response": data,
            "context_manifest": self._manifest(context),
        }
        self.store.append_transcript(self.run_id, record)
        return {
            "agent": role,
            "status": "ok",
            "response": data,
            "findings": findings,
            "proposed_items": proposed,
            "attempts": 1,
            "duration_ms": duration,
            "usage": usage,
        }

    def _call_json(self, *, agent, system, user, temperature, max_tokens, purpose, validate) -> ChatResult:
        messages = [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ]
        last_error: LLMError | None = None
        for attempt in range(1, self.settings.llm_max_attempts + 1):
            self._check_budget()
            try:
                result = self.client.complete_json(
                    messages, temperature=temperature, max_tokens=max_tokens, purpose=purpose
                )
                validate(result.data)
                return result
            except LLMError as exc:
                last_error = exc
                if attempt >= self.settings.llm_max_attempts:
                    break
                if exc.retryable or exc.code.startswith("json") or exc.code.startswith("invalid"):
                    repair = (
                        "\n\n【修复要求】你上一次的输出无法使用：" + str(exc)[:400]
                        + "\n请重新输出一个合法 JSON 对象，严格符合前面的结构要求；不要解释，不要 Markdown。"
                    )
                    messages = [
                        messages[0],
                        {"role": "user", "content": messages[1]["content"] + repair},
                    ]
                    continue
                break
            except Exception as exc:
                last_error = LLMError(f"调用异常：{exc}", code="unexpected", retryable=False)
                break
        if last_error is not None:
            last_error.attempts = self.settings.llm_max_attempts
            raise last_error
        raise LLMError("未知调用失败", code="unknown")

    @staticmethod
    def _validate_agent_output(data: dict) -> None:
        if not isinstance(data, dict):
            raise LLMError("Agent 输出不是 JSON 对象", code="invalid_shape", retryable=True)
        if "findings" not in data and "vote" not in data:
            raise LLMError("Agent 输出缺少 findings", code="invalid_shape", retryable=True)
        if "findings" in data and not isinstance(data["findings"], list):
            raise LLMError("findings 不是数组", code="invalid_shape", retryable=True)
        if "proposed_items" in data and not isinstance(data["proposed_items"], list):
            raise LLMError("proposed_items 不是数组", code="invalid_shape", retryable=True)

    def _normalize_agent_output(self, data: dict) -> dict:
        data = dict(data)
        data["findings"] = [f for f in (data.get("findings") or []) if isinstance(f, dict)][
            : self.settings.max_findings_per_agent
        ]
        data["proposed_items"] = [i for i in (data.get("proposed_items") or []) if isinstance(i, dict)][
            : self.settings.max_items_per_agent
        ]
        vote = str(data.get("vote") or "").strip()
        if vote in ("accept", "accept_with_comments", "reject"):
            data["vote"] = vote
        return data

    def _decorate_findings(self, role: str, context: RoundContext, findings: list[dict], transcript: list[dict]) -> list[dict]:
        decorated = []
        for index, raw in enumerate(findings, 1):
            sources, warnings = verify_sources(raw.get("sources"), context.source, transcript)
            severity = normalize_severity(raw.get("severity"))
            decorated.append(
                {
                    "finding_id": f"F-R{context.round_no}-{role}-{index:02d}",
                    "round": context.round_no,
                    "role": role,
                    "role_name": ROLE_PROFILES[role]["name"],
                    "kind": str(raw.get("kind") or "ambiguity")[:30],
                    "target_id": raw.get("target_id"),
                    "statement": str(raw.get("statement") or "")[:400],
                    "why_it_matters": str(raw.get("why_it_matters") or raw.get("why") or "")[:400],
                    "severity": severity,
                    "proposal": str(raw.get("proposal") or "")[:400],
                    "question": raw.get("question"),
                    "sources": sources,
                    "citation_ok": bool(sources) and all(s.get("valid") for s in sources),
                    "warnings": warnings,
                }
            )
        return decorated

    def _manifest(self, context: RoundContext) -> dict:
        return {
            "snapshot_version": context.snapshot.get("version"),
            "visible_segment_ids": [seg["seg_id"] for seg in context.source.get("segments", [])],
            "visible_item_ids": [item["id"] for item in context.snapshot.get("items", []) if item.get("status") == "active"],
            "visible_finding_ids": [f.get("finding_id") for f in context.unresolved],
            "visible_clarifications": [c.get("oq_id") for c in context.clarifications],
            "mode": context.mode,
        }

    # ------------------------------------------------------------------ 主持人

    def _call_moderator(self, context: RoundContext, outputs: list[dict], base_snapshot: dict) -> dict:
        if self.settings.local_moderator:
            from .localmod import build_local_moderation

            started = time.time()
            data = build_local_moderation(context, outputs, base_snapshot, self.settings)
            self._record_call("moderator", data, {}, "ok")
            self.store.append_transcript(
                self.run_id,
                {
                    "round": context.round_no,
                    "agent": "moderator",
                    "kind": "moderator",
                    "status": "ok",
                    "started_at": now_iso(),
                    "duration_ms": int((time.time() - started) * 1000),
                    "usage": {},
                    "response": data,
                    "context_manifest": {
                        "mode": "local-rule",
                        "snapshot_version": base_snapshot.get("version"),
                        "visible_agent_outputs": [o.get("agent") for o in outputs],
                    },
                },
            )
            self._emit(
                "moderator_local",
                round=context.round_no,
                ops=len(data.get("ops") or []),
                summary=str(data.get("summary") or "")[:200],
            )
            return data
        user = moderator_user(
            round_no=context.round_no,
            mode=context.mode,
            source_text=context.source_text,
            snapshot=compact_snapshot(base_snapshot, quote_limit=200),
            agent_outputs=outputs,
            clarifications=context.clarifications,
            previous_summary=self._load().get("last_summary", ""),
            quality_issues=base_snapshot.get("quality", {}).get("issues", []),
            coverage_uncovered=base_snapshot.get("coverage", {}).get("uncovered", []),
            is_final=context.is_final,
        )
        started = time.time()
        try:
            result = self._call_json(
                agent="moderator",
                system=MODERATOR_SYSTEM,
                user=user,
                temperature=self.settings.temperature_moderator,
                max_tokens=self.settings.max_tokens_moderator,
                purpose=f"moderator:r{context.round_no}:{context.mode}",
                validate=self._validate_moderator_output,
            )
        except LLMError as exc:
            self._record_call("moderator", None, None, "failed", f"{exc.code}: {exc}")
            self._emit("moderator_failed", round=context.round_no, error=str(exc)[:800])
            raise RunError(f"主持人综合失败：{exc}") from exc
        data = dict(result.data)
        data.setdefault("ops", [])
        data.setdefault("summary", "")
        data.setdefault("next_focus", [])
        data.setdefault("converged", False)
        data.setdefault("convergence_reason", "")
        self._record_call("moderator", result.data, result.usage or {}, "ok")
        self.store.append_transcript(
            self.run_id,
            {
                "round": context.round_no,
                "agent": "moderator",
                "kind": "moderator",
                "status": "ok",
                "started_at": now_iso(),
                "duration_ms": int((time.time() - started) * 1000),
                "usage": result.usage or {},
                "response": data,
                "context_manifest": {
                    "snapshot_version": base_snapshot.get("version"),
                    "visible_agent_outputs": [o.get("agent") for o in outputs],
                    "visible_clarifications": [c.get("oq_id") for c in context.clarifications],
                },
            },
        )
        return data

    @staticmethod
    def _validate_moderator_output(data: dict) -> None:
        if not isinstance(data, dict):
            raise LLMError("主持人输出不是对象", code="invalid_shape", retryable=True)
        if "ops" not in data:
            raise LLMError("主持人输出缺少 ops", code="invalid_shape", retryable=True)
        if not isinstance(data["ops"], list):
            raise LLMError("ops 不是数组", code="invalid_shape", retryable=True)

    def _ensure_answer_ops(self, ops: list[dict], snapshot: dict, clarifications: list[dict]) -> list[dict]:
        if not clarifications:
            return ops
        existing = {str(op.get("id")) for op in ops if isinstance(op, dict) and op.get("op") == "answer_question"}
        items = {item["id"]: item for item in snapshot.get("items", [])}
        extra = list(ops)
        for clar in clarifications:
            oq_id = clar.get("oq_id")
            item = items.get(oq_id)
            if not item or item.get("type") != "open_question":
                continue
            if item.get("answer") or oq_id in existing:
                continue
            extra.append(
                {
                    "op": "answer_question",
                    "id": oq_id,
                    "answer": clar.get("answer", ""),
                    "answer_source": "user",
                    "reason": f"人工澄清（{clar.get('by', 'user')}）",
                }
            )
        return extra

    # ------------------------------------------------------------------ 轮次收尾

    def _build_round_summary(
        self,
        round_no: int,
        context: RoundContext,
        before: dict,
        after: dict,
        outputs: list[dict],
        moderator: dict,
        applied: list[dict],
        rejected: list[dict],
        duration_ms: int,
    ) -> dict:
        counts = {"added": 0, "updated": 0, "superseded": 0, "answered": 0, "ignored": 0}
        mapping = {
            "add_item": "added",
            "update_item": "updated",
            "supersede_item": "superseded",
            "answer_question": "answered",
            "ignore_segment": "ignored",
        }
        for item in applied:
            key = mapping.get(item.get("op"))
            if key:
                counts[key] += 1
        agents = {}
        for output in outputs:
            response = output.get("response") or {}
            agents[output["agent"]] = {
                "status": output.get("status"),
                "findings": len(output.get("findings", [])),
                "items": len(output.get("proposed_items", [])),
                "vote": response.get("vote"),
                "error": (output.get("error") or "")[:300] or None,
                "duration_ms": output.get("duration_ms", 0),
            }
        severity = {"blocking": 0, "major": 0, "minor": 0}
        for output in outputs:
            for finding in output.get("findings", []):
                severity[finding.get("severity", "major")] = severity.get(finding.get("severity", "major"), 0) + 1
        return {
            "round": round_no,
            "mode": context.mode,
            "mode_label": MODE_LABELS.get(context.mode, context.mode),
            "version": after.get("version"),
            "summary": str(moderator.get("summary") or "")[:600],
            "next_focus": [str(x)[:200] for x in (moderator.get("next_focus") or [])][:4],
            "moderator_converged": bool(moderator.get("converged")),
            "convergence_reason": str(moderator.get("convergence_reason") or "")[:500],
            "agents": agents,
            "findings_severity": severity,
            "ops": counts,
            "rejected_ops": [
                {"op": r.get("op"), "reason": str(r.get("reason") or "")[:300]} for r in rejected
            ][:20],
            "blocking_open": after.get("metrics", {}).get("blocking_open", 0),
            "coverage_rate": after.get("metrics", {}).get("coverage_rate", 0),
            "quality_passed": after.get("quality", {}).get("passed", False),
            "clarifications": [c.get("oq_id") for c in context.clarifications],
            "duration_ms": duration_ms,
            "before_version": before.get("version"),
        }

    def _next_round_version(self, round_no: int) -> str:
        base = f"v0.{round_no}"
        existing = set(self.store.snapshot_versions(self.run_id))
        if base not in existing:
            return base
        suffix = 2
        while f"{base}.{suffix}" in existing:
            suffix += 1
        return f"{base}.{suffix}"

    def _mark_clarifications(self, round_no: int) -> None:
        def mutate(run: dict) -> None:
            for item in run.get("clarifications", []):
                if not item.get("incorporated_round"):
                    item["incorporated_round"] = round_no

        self.store.update(self.run_id, mutate)

    def _update_run_after_round(self, round_no: int, snapshot: dict, summary: dict, outputs: list[dict]) -> None:
        blocking_findings = [
            {
                "finding_id": finding.get("finding_id"),
                "round": finding.get("round"),
                "role": finding.get("role"),
                "severity": finding.get("severity"),
                "statement": finding.get("statement"),
                "question": finding.get("question"),
                "target_id": finding.get("target_id"),
            }
            for output in outputs
            for finding in output.get("findings", [])
            if finding.get("severity") == "blocking"
        ]

        def mutate(run: dict) -> None:
            run["round"] = round_no
            run["latest_version"] = snapshot.get("version")
            run["metrics"] = snapshot.get("metrics", {})
            run["quality"] = snapshot.get("quality", {})
            run["last_summary"] = summary.get("summary", "")
            run["last_focus"] = summary.get("next_focus", [])
            run["last_findings"] = blocking_findings
            run["last_round_summary"] = summary

        self.store.update(self.run_id, mutate)

    # ------------------------------------------------------------------ 收敛

    def _evaluate_convergence(self, snapshot: dict, outputs: list[dict], mode: str, moderator_converged: bool) -> dict:
        metrics = snapshot.get("metrics", {})
        gates = snapshot.get("quality", {}).get("gates", {})
        votes = [
            (o.get("agent"), (o.get("response") or {}).get("vote"))
            for o in outputs
            if (o.get("response") or {}).get("vote")
        ]
        rejects = [agent for agent, vote in votes if vote == "reject"]
        notes = [agent for agent, vote in votes if vote == "accept_with_comments"]
        reasons = []
        if int(metrics.get("blocking_open", 0)) > 0:
            reasons.append(f"仍有 {metrics.get('blocking_open')} 个阻塞待澄清项")
        if rejects:
            reasons.append("有 Agent 投反对票：" + "、".join(rejects))
        if not gates.get("coverage"):
            reasons.append("原文覆盖率未达标")
        if not gates.get("acceptance"):
            reasons.append("仍有明确要求缺少验收要点")
        if mode == "finalize" and not votes:
            reasons.append("定稿轮没有收到签署意见")
        if mode != "finalize" and not moderator_converged:
            reasons.append("主持人判断尚未收敛")
        converged = not reasons and (mode == "finalize" or moderator_converged)
        return {
            "converged": converged,
            "reasons": reasons,
            "votes": votes,
            "accept_with_comments": notes,
            "rejects": rejects,
            "gates": gates,
            "blocking_open": metrics.get("blocking_open", 0),
            "coverage_rate": metrics.get("coverage_rate", 0),
            "mode": mode,
        }

    # ------------------------------------------------------------------ 人工操作

    def answer_question(self, oq_id: str, answer: str, by: str = "user") -> dict:
        with self._run_lock:
            run = self._load()
            if run.get("status") == "approved":
                raise RunError("运行已批准，不能修改澄清答案；请新建修订轮次")
            snapshot = self._snapshot()
            item = next((i for i in snapshot.get("items", []) if i.get("id") == oq_id and i.get("status") == "active"), None)
            if item is None or item.get("type") != "open_question":
                raise StoreError(f"待澄清项不存在：{oq_id}")
            answer = str(answer or "").strip()
            if not answer:
                raise ValueError("回答不能为空")
            record = {
                "clarification_id": f"CLR-{len(run.get('clarifications', [])) + 1:03d}",
                "oq_id": oq_id,
                "question": item.get("statement"),
                "answer": answer[:1000],
                "by": by or "user",
                "at": now_iso(),
                "round_at": run.get("round", 0),
                "incorporated_round": None,
            }
            def mutate(latest: dict) -> None:
                latest.setdefault("clarifications", []).append(record)

            self.store.update(self.run_id, mutate)
            self._emit(
                "clarification_received",
                oq_id=oq_id,
                answer=answer[:300],
                by=by,
                clarification_id=record["clarification_id"],
            )
            return record

    def continue_run(self) -> dict:
        with self._run_lock:
            run = self._load()
            if run.get("status") == "paused":
                self.store.update(
                    self.run_id,
                    lambda r: r.update({"gate_passed": True, "status": "running", "pause_reason": None}),
                )
                self._emit("run_continued", round=run.get("round", 0), pending_answers=len(self._pending_clarifications(run)))
                return self.run_until_pause()
            if run.get("status") == "created":
                return self.run_until_pause()
            if run.get("status") == "awaiting_approval":
                self._to_awaiting_approval("等待人工批准")
                return self._load()
            if run.get("status") == "failed":
                raise RunError("运行已失败；请先查看错误，必要时新建运行")
            return run

    def stop(self, reason: str = "人工停止") -> dict:
        with self._run_lock:
            self._set_status("stopped", stop_reason=reason)
            self._emit("run_stopped", reason=reason)
            return self._load()

    # ------------------------------------------------------------------ 批准与交接

    def _apply_pending_answers(self) -> tuple[dict, dict | None, int]:
        run = self._load()
        pending = self._pending_clarifications(run)
        if not pending:
            return self._snapshot(), None, 0
        snapshot = self._snapshot()
        source = self._source()
        ops = []
        items = {item["id"]: item for item in snapshot.get("items", [])}
        for clar in pending:
            item = items.get(clar.get("oq_id"))
            if item and item.get("type") == "open_question" and not item.get("answer") and not item.get("assumption"):
                ops.append(
                    {
                        "op": "answer_question",
                        "id": clar["oq_id"],
                        "answer": clar["answer"],
                        "answer_source": "user",
                        "reason": f"批准前落库人工澄清（{clar.get('by')}）",
                    }
                )
        if not ops:
            self._mark_clarifications(int(snapshot.get("round", 0)))
            return snapshot, None, 0
        version = self._next_round_version(int(snapshot.get("round", 0)) + 1) if False else self._next_patch_version(snapshot["version"])
        new_snapshot, applied, _rejected = apply_ops(
            snapshot, ops, source, int(snapshot.get("round", 0)), version,
            transcript=self.store.transcript(self.run_id), by="human",
        )
        finalize_snapshot(new_snapshot, source, version=version)
        diff = diff_snapshots(snapshot, new_snapshot)
        self.store.save_snapshot(self.run_id, new_snapshot)
        self.store.save_document(self.run_id, version, render_markdown(new_snapshot, source))
        self.store.path(self.run_id, "documents", f"变更_{version}.md").write_text(
            render_diff_markdown(diff, new_snapshot["project"].get("title", "")), encoding="utf-8"
        )
        self.store.update(self.run_id, lambda r: r.update({"latest_version": version}))
        self._mark_clarifications(int(new_snapshot.get("round", 0)))
        self._emit("answers_applied", version=version, answered=len(applied), diff=diff.get("counts", {}))
        return new_snapshot, diff, len(applied)

    def _next_patch_version(self, base: str) -> str:
        existing = set(self.store.snapshot_versions(self.run_id))
        if base not in existing:
            return base
        suffix = 2
        while f"{base}.{suffix}" in existing:
            suffix += 1
        return f"{base}.{suffix}"

    def approve(self, by: str = "human", note: str = "", accept_open: bool = False) -> dict:
        with self._run_lock:
            run = self._load()
            if run.get("status") == "approved":
                return self.store.latest_snapshot(self.run_id)
            if run.get("status") not in ("awaiting_approval", "paused"):
                raise RunError(f"当前状态不能批准：{run.get('status')}")
            snapshot, _diff, _answered = self._apply_pending_answers()
            blocking = int(snapshot.get("metrics", {}).get("blocking_open", 0))
            if blocking and not accept_open:
                raise RunError(
                    f"仍有 {blocking} 个阻塞待澄清项。请先澄清，或在批准时显式接受未决项（accept_open=true）"
                )
            approved = copy.deepcopy(snapshot)
            approved["version"] = "v1.0"
            approved["parent_version"] = snapshot.get("version")
            approved["status"] = "approved" if blocking == 0 else "approved_with_open_questions"
            approved["approved_at"] = now_iso()
            approved["approval"] = {"by": by, "note": note, "accept_open": accept_open, "blocking_open": blocking}
            approved["updated_at"] = now_iso()
            from .config import new_snapshot_id

            approved["snapshot_id"] = new_snapshot_id()
            finalize_snapshot(approved, self._source(), version="v1.0")
            self.store.save_snapshot(self.run_id, approved)
            source = self._source()
            handoff = self._build_handoff(approved, source)
            self.store.save_sidecar(self.run_id, "handoff.json", handoff)
            self.store.save_document(
                self.run_id, "v1.0", render_markdown(approved, source, self._load())
            )
            self.store.path(self.run_id, "documents", "需求快照_v1.0.md").write_text(
                render_markdown(approved, source, self._load()), encoding="utf-8"
            )
            self.store.update(
                self.run_id,
                lambda r: r.update(
                    {
                        "status": "approved",
                        "latest_version": "v1.0",
                        "approved_at": approved["approved_at"],
                        "approved_by": by,
                        "approval_note": note,
                        "metrics": approved.get("metrics", {}),
                        "quality": approved.get("quality", {}),
                    }
                ),
            )
            self._emit(
                "run_approved",
                version="v1.0",
                by=by,
                note=note,
                accept_open=accept_open,
                blocking_open=blocking,
                digest=snapshot_digest(approved),
            )
            return approved

    def _build_handoff(self, snapshot: dict, source: dict) -> dict:
        from .handoff import build_handoff

        return build_handoff(snapshot, source, self._load())

    # ------------------------------------------------------------------ 查询

    def state(self) -> dict:
        run = self._load()
        snapshot = self._snapshot()
        return {
            "run": run,
            "latest": snapshot_digest(snapshot),
            "snapshot_id": snapshot.get("snapshot_id"),
            "versions": self.store.snapshot_versions(self.run_id),
            "open_questions": self._open_questions(snapshot),
            "clarifications": run.get("clarifications", []),
            "pending_clarifications": self._pending_clarifications(run),
        }

    @staticmethod
    def _open_questions(snapshot: dict) -> list[dict]:
        rows = []
        for item in snapshot.get("items", []):
            if item.get("type") != "open_question" or item.get("status") != "active":
                continue
            if item.get("answer"):
                continue
            rows.append(
                {
                    "id": item["id"],
                    "title": item.get("title"),
                    "question": item.get("statement"),
                    "why": item.get("why"),
                    "blocking": item.get("blocking"),
                    "options": item.get("options", []),
                    "suggested_assumption": item.get("suggested_assumption"),
                    "assumption": item.get("assumption"),
                    "related": item.get("related", []),
                }
            )
        rows.sort(key=lambda x: (not x.get("blocking"), x["id"]))
        return rows

    def document(self, version: str = "latest") -> str:
        return self.store.read_document(self.run_id, version)

    def snapshot(self, version: str = "latest") -> dict:
        return self.store.load_snapshot(self.run_id, version)
