from __future__ import annotations

import argparse
import json
import mimetypes
import os
import sys
import threading
import traceback
from dataclasses import replace
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlsplit

from .config import Settings, now_iso
from .handoff import build_handoff, push_to_orchestrator, to_orchestrator_payload
from .llm import LocalClient, MockClient, ReplayClient
from .model import diff_snapshots
from .orchestrator import Orchestrator, RunError
from .snapshot import render_diff_markdown, snapshot_digest
from .store import RunStore, StoreError


class App:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.store = RunStore(settings.runs_dir)
        self.engines: dict[str, Orchestrator] = {}
        self._lock = threading.RLock()
        self.started_at = now_iso()

    def engine(self, run_id: str) -> Orchestrator:
        with self._lock:
            if run_id in self.engines:
                return self.engines[run_id]
            if not self.store.exists(run_id):
                raise StoreError(f"运行不存在：{run_id}")
            run = self.store.load(run_id)
            client_name = run.get("config", {}).get("client", {}).get("client")
            client = None
            if client_name == "mock":
                client = MockClient()
            elif client_name == "local":
                client = LocalClient()
            elif client_name == "replay":
                client = ReplayClient(run.get("config", {}).get("client", {}).get("replay_path"))
            engine = Orchestrator.load(self.store, self.settings, run_id, client=client)
            self.engines[run_id] = engine
            return engine

    def create_run(self, body: dict) -> dict:
        text = str(body.get("input_text") or body.get("requirement") or body.get("input") or "").strip()
        if not text:
            raise ValueError("缺少 input_text（原始需求文本）")
        if len(text) > 200_000:
            raise ValueError("需求原文过长（上限 20 万字符）")
        title = str(body.get("title") or "").strip()
        max_rounds = body.get("max_rounds")
        auto_assume = bool(body.get("auto_assume", False))
        mock = bool(body.get("mock", False))
        local = bool(body.get("local", False))
        replay_path = str(body.get("replay_path") or "").strip()
        client = MockClient() if mock else (LocalClient() if local else None)
        if replay_path:
            client = ReplayClient(replay_path)
        settings = replace(
            self.settings,
            local_agents=local,
            local_moderator=local or bool(body.get("local_moderator", False)),
        )
        engine = Orchestrator.create(
            self.store,
            settings,
            text,
            title=title,
            client=client,
            max_rounds=int(max_rounds) if max_rounds is not None else None,
            auto_assume=auto_assume,
        )
        with self._lock:
            self.engines[engine.run_id] = engine
        run = self.store.load(engine.run_id)
        if bool(body.get("start", True)):
            engine.start_async()
        return {"run_id": engine.run_id, "state": engine.state(), "run": run}

    def list_runs(self) -> list[dict]:
        rows = []
        for run in self.store.list():
            rows.append(
                {
                    "run_id": run.get("run_id"),
                    "title": run.get("title"),
                    "status": run.get("status"),
                    "round": run.get("round"),
                    "max_rounds": run.get("max_rounds"),
                    "latest_version": run.get("latest_version"),
                    "created_at": run.get("created_at"),
                    "updated_at": run.get("updated_at"),
                    "metrics": run.get("metrics", {}),
                    "quality": run.get("quality", {}),
                    "model": run.get("config", {}).get("model"),
                    "mock": run.get("config", {}).get("client", {}).get("client") == "mock",
                }
            )
        return rows

    def events(self, run_id: str, since: int, limit: int) -> dict:
        events = self.store.read_events(run_id, since, limit)
        next_since = int(events[-1]["seq"]) if events else since
        return {
            "events": events,
            "next_since": next_since,
            "has_more": len(events) >= limit,
        }

    def diff(self, run_id: str, from_version: str, to_version: str) -> dict:
        left = self.store.load_snapshot(run_id, from_version)
        right = self.store.load_snapshot(run_id, to_version)
        data = diff_snapshots(left, right)
        data["markdown"] = render_diff_markdown(data, right.get("project", {}).get("title", ""))
        return data

    def handoff(self, run_id: str, payload: bool = False) -> dict:
        path = self.store.path(run_id, "handoff.json")
        if not path.exists():
            raise StoreError("交接文件尚未生成：请先批准快照 v1.0")
        data = self.store.read_json(path)
        return to_orchestrator_payload(data) if payload else data

    def rebuild_handoff(self, run_id: str) -> dict:
        snapshot = self.store.latest_snapshot(run_id)
        source = self.store.read_json(self.store.path(run_id, "source.json"))
        data = build_handoff(snapshot, source, self.store.load(run_id))
        self.store.save_sidecar(run_id, "handoff.json", data)
        self.store.save_sidecar(run_id, "handoff_orchestrator.json", to_orchestrator_payload(data))
        return data


class Handler(BaseHTTPRequestHandler):
    server_version = "ReqRound/1.0"
    protocol_version = "HTTP/1.1"

    @property
    def app(self) -> App:
        return self.server.app  # type: ignore[attr-defined]

    # ---------- 基础 ----------

    def log_message(self, fmt, *args):
        if os.getenv("REQROUND_QUIET"):
            return
        sys.stderr.write("[%s] %s\n" % (self.log_date_time_string(), fmt % args))

    def _send(self, status: int, body: bytes, content_type: str, extra: dict | None = None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.send_header("Access-Control-Allow-Methods", "GET,POST,OPTIONS")
        self.send_header("Cache-Control", "no-store")
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(body)

    def _json(self, status: int, data):
        self._send(status, json.dumps(data, ensure_ascii=False, indent=2).encode("utf-8"),
                   "application/json; charset=utf-8")

    def _error(self, status: int, message: str):
        self._json(status, {"error": message, "status": status})

    def _read_body(self) -> dict:
        length = int(self.headers.get("Content-Length") or 0)
        if length > 1_500_000:
            raise ValueError("请求体过大")
        raw = self.rfile.read(length) if length else b"{}"
        if not raw.strip():
            return {}
        try:
            data = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise ValueError(f"请求体不是合法 UTF-8 JSON：{exc}") from exc
        if not isinstance(data, dict):
            raise ValueError("请求体必须是 JSON 对象")
        return data

    # ---------- 路由 ----------

    def do_OPTIONS(self):
        self._send(204, b"", "text/plain")

    def do_GET(self):
        parsed = urlsplit(self.path)
        path = unquote(parsed.path)
        query = parse_qs(parsed.query)
        try:
            if path == "/api/health":
                return self._json(200, {
                    "status": "ok",
                    "service": "reqround",
                    "started_at": self.app.started_at,
                    "model": self.app.settings.model,
                    "runs": len(self.app.store.list()),
                })
            if path == "/api/runs":
                return self._json(200, {"runs": self.app.list_runs()})
            if path == "/api/demo-case":
                case_path = Path(__file__).resolve().parent.parent / "cases" / "lab_booking.md"
                if not case_path.exists():
                    return self._error(404, "演示案例不存在")
                return self._send(200, case_path.read_bytes(), "text/markdown; charset=utf-8")
            if path.startswith("/api/runs/"):
                parts = path.strip("/").split("/")
                # api / runs / <id> / <action>
                if len(parts) < 3:
                    return self._error(404, "未知接口")
                run_id = parts[2]
                action = parts[3] if len(parts) > 3 else ""
                if not action:
                    return self._json(200, self.app.engine(run_id).state())
                if action == "events":
                    since = int(query.get("since", ["0"])[0])
                    limit = int(query.get("limit", ["200"])[0])
                    if since < 0 or limit <= 0:
                        raise ValueError("since 必须 >= 0，limit 必须 > 0")
                    return self._json(200, self.app.events(run_id, since, min(limit, 1000)))
                if action == "snapshot":
                    version = query.get("version", ["latest"])[0]
                    return self._json(200, self.app.store.load_snapshot(run_id, version))
                if action == "document":
                    version = query.get("version", ["latest"])[0]
                    text = self.app.engine(run_id).document(version)
                    download = query.get("download", ["0"])[0] in ("1", "true")
                    headers = {}
                    if download:
                        name = f"需求快照_{version}.md" if version != "latest" else "需求快照_最新.md"
                        headers["Content-Disposition"] = f"attachment; filename*=UTF-8''{urllib_quote(name)}"
                    return self._send(200, text.encode("utf-8"), "text/markdown; charset=utf-8", headers)
                if action == "diff":
                    left = query.get("from", [""])[0]
                    right = query.get("to", ["latest"])[0]
                    if not left:
                        raise ValueError("缺少 from 版本")
                    return self._json(200, self.app.diff(run_id, left, right))
                if action == "transcript":
                    return self._json(200, {"records": self.app.store.transcript(run_id)})
                if action == "handoff":
                    payload = query.get("format", ["full"])[0] == "orchestrator"
                    return self._json(200, self.app.handoff(run_id, payload=payload))
                if action == "versions":
                    return self._json(200, {"versions": self.app.store.snapshot_versions(run_id)})
                return self._error(404, "未知接口")
            if path in ("/", "/index.html"):
                return self._serve_static("index.html")
            if path.startswith("/web/"):
                return self._serve_static(path[len("/web/"):])
            if path == "/favicon.ico":
                return self._send(204, b"", "image/x-icon")
            return self._error(404, "未找到")
        except (StoreError, RunError, ValueError) as exc:
            return self._error(400, str(exc))
        except Exception as exc:
            traceback.print_exc()
            return self._error(500, f"服务异常：{exc}")

    def do_POST(self):
        parsed = urlsplit(self.path)
        path = unquote(parsed.path)
        try:
            body = self._read_body()
            if path == "/api/runs":
                result = self.app.create_run(body)
                return self._json(200, result)
            if path.startswith("/api/runs/"):
                parts = path.strip("/").split("/")
                if len(parts) < 4:
                    return self._error(404, "未知接口")
                run_id = parts[2]
                action = parts[3]
                engine = self.app.engine(run_id)
                if action == "clarifications":
                    oq_id = str(body.get("oq_id") or "").strip()
                    answer = str(body.get("answer") or "").strip()
                    if not oq_id or not answer:
                        raise ValueError("需要 oq_id 与 answer")
                    record = engine.answer_question(oq_id, answer, by=str(body.get("by") or "user"))
                    result = {"clarification": record, "state": engine.state()}
                    if body.get("continue"):
                        start_continue(engine)
                        result["accepted"] = True
                    return self._json(200, result)
                if action == "continue":
                    start_continue(engine)
                    return self._json(200, {"accepted": True, "state": engine.state()})
                if action == "approve":
                    snapshot = engine.approve(
                        by=str(body.get("by") or "user"),
                        note=str(body.get("note") or ""),
                        accept_open=bool(body.get("accept_open", False)),
                    )
                    return self._json(200, {
                        "state": engine.state(),
                        "snapshot": snapshot_digest(snapshot),
                        "handoff": self.app.handoff(run_id, payload=False),
                    })
                if action == "retry":
                    run = self.app.store.load(run_id)
                    if run.get("status") != "failed":
                        raise RunError("当前运行不是失败状态，不需要重试")

                    def retry_target():
                        try:
                            engine.retry_failed_round()
                            engine.run_until_pause()
                        except Exception as exc:
                            engine._fail(str(exc))

                    threading.Thread(target=retry_target, name=f"reqround-retry-{run_id}", daemon=True).start()
                    return self._json(200, {"accepted": True, "state": engine.state()})
                if action == "stop":
                    return self._json(200, {"state": engine.stop(str(body.get("reason") or "人工停止"))})
                if action == "push":
                    url = str(body.get("url") or "http://127.0.0.1:8000").strip()
                    handoff = self.app.handoff(run_id, payload=False)
                    result = push_to_orchestrator(url, handoff, timeout=float(body.get("timeout") or 300))
                    return self._json(200 if result.get("ok") else 502, result)
                if action == "handoff":
                    return self._json(200, self.app.rebuild_handoff(run_id))
                return self._error(404, "未知接口")
            return self._error(404, "未找到")
        except (StoreError, RunError, ValueError) as exc:
            return self._error(400, str(exc))
        except Exception as exc:
            traceback.print_exc()
            return self._error(500, f"服务异常：{exc}")

    def _serve_static(self, relative: str):
        base = Path(self.app.settings.web_dir).resolve()
        target = (base / relative).resolve()
        if base not in target.parents and target != base:
            return self._error(403, "禁止访问")
        if not target.exists() or not target.is_file():
            return self._error(404, "文件不存在")
        content_type = mimetypes.guess_type(str(target))[0] or "application/octet-stream"
        if content_type.startswith("text/") or content_type in ("application/javascript", "application/json"):
            content_type += "; charset=utf-8"
        self._send(200, target.read_bytes(), content_type)


def urllib_quote(text: str) -> str:
    from urllib.parse import quote

    return quote(text, safe="")


def start_continue(engine: Orchestrator) -> None:
    """继续讨论是长任务：立刻返回 202 语义，让前端继续轮询事件。"""

    def target() -> None:
        try:
            engine.continue_run()
        except Exception as exc:
            engine._fail(str(exc))

    threading.Thread(target=target, name=f"reqround-continue-{engine.run_id}", daemon=True).start()


class Server(ThreadingHTTPServer):
    daemon_threads = True
    allow_reuse_address = True

    def __init__(self, address, handler, app: App):
        super().__init__(address, handler)
        self.app = app


def serve(host: str = "127.0.0.1", port: int = 8770, runs_dir: str | None = None) -> None:
    settings = Settings.from_env()
    if runs_dir:
        settings.runs_dir = Path(runs_dir)
    app = App(settings)
    httpd = Server((host, port), Handler, app)
    print(f"ReqRound 服务已启动：http://{host}:{port}")
    print(f"运行目录：{settings.runs_dir}")
    print(f"模型：{settings.model}（{'已配置 Key' if settings.api_key else '未配置 Key，仅可 mock'}）")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n正在停止 …")
    finally:
        httpd.server_close()


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="ReqRound HTTP 服务")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8770)
    parser.add_argument("--runs", default=None, help="运行目录")
    args = parser.parse_args(argv)
    serve(args.host, args.port, args.runs)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
