from __future__ import annotations

import json
import os
import re
import threading
import uuid
from pathlib import Path
from typing import Any, Iterable

from .config import now_iso

RUN_ID_RE = re.compile(r"^R-[A-Za-z0-9-]+$")
VERSION_RE = re.compile(r"^v\d+(?:\.\d+)*$")


class StoreError(RuntimeError):
    pass


class RunStore:
    """一次运行一个目录；所有写入使用临时文件 + 原子替换。"""

    def __init__(self, runs_dir: Path):
        self.root = Path(runs_dir)
        self.root.mkdir(parents=True, exist_ok=True)
        self._locks: dict[str, threading.RLock] = {}
        self._global_lock = threading.RLock()

    # ---------- 基础 ----------

    def _lock(self, run_id: str) -> threading.RLock:
        with self._global_lock:
            return self._locks.setdefault(run_id, threading.RLock())

    def run_dir(self, run_id: str) -> Path:
        if not RUN_ID_RE.match(run_id or ""):
            raise StoreError(f"非法 run_id：{run_id!r}")
        return self.root / run_id

    def path(self, run_id: str, *parts: str) -> Path:
        return self.run_dir(run_id).joinpath(*parts)

    def exists(self, run_id: str) -> bool:
        return (self.run_dir(run_id) / "run.json").exists()

    @staticmethod
    def _atomic_json(path: Path, obj: Any) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.with_name(f".{path.name}.{uuid.uuid4().hex[:8]}.tmp")
        text = json.dumps(obj, ensure_ascii=False, indent=2)
        tmp.write_text(text, encoding="utf-8")
        os.replace(tmp, path)

    def write_json(self, path: Path, obj: Any) -> None:
        self._atomic_json(Path(path), obj)

    def read_json(self, path: Path, default: Any = None) -> Any:
        try:
            return json.loads(Path(path).read_text(encoding="utf-8"))
        except FileNotFoundError:
            return default
        except json.JSONDecodeError as exc:
            raise StoreError(f"JSON 损坏：{path}：{exc}") from exc

    @staticmethod
    def _append_jsonl(path: Path, obj: Any) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(obj, ensure_ascii=False) + "\n")
            handle.flush()

    @staticmethod
    def read_jsonl(path: Path) -> list[dict]:
        if not Path(path).exists():
            return []
        rows = []
        for line in Path(path).read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError:
                continue
        return rows

    # ---------- run ----------

    def create(self, run: dict, input_text: str, source: dict) -> Path:
        run_id = run["run_id"]
        directory = self.run_dir(run_id)
        directory.mkdir(parents=True, exist_ok=False)
        (directory / "snapshots").mkdir()
        (directory / "documents").mkdir()
        (directory / "input.md").write_text(input_text, encoding="utf-8")
        self.write_json(directory / "source.json", source)
        self.write_json(directory / "run.json", run)
        return directory

    def load(self, run_id: str) -> dict:
        data = self.read_json(self.run_dir(run_id) / "run.json")
        if not data:
            raise StoreError(f"运行不存在：{run_id}")
        return data

    def save(self, run: dict) -> dict:
        run_id = run["run_id"]
        with self._lock(run_id):
            run["updated_at"] = now_iso()
            self._atomic_json(self.run_dir(run_id) / "run.json", run)
        return run

    def update(self, run_id: str, mutator) -> dict:
        """在 per-run 锁内读-改-写，供并行 Agent 记数、改状态。"""
        with self._lock(run_id):
            run = self.load(run_id)
            result = mutator(run)
            run["updated_at"] = now_iso()
            self._atomic_json(self.run_dir(run_id) / "run.json", run)
            return result if result is not None else run

    def list(self) -> list[dict]:
        runs = []
        for child in sorted(self.root.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True):
            if not child.is_dir():
                continue
            try:
                data = self.read_json(child / "run.json")
            except StoreError:
                continue
            if data:
                runs.append(data)
        return runs

    # ---------- 事件 ----------

    def event(self, run_id: str, event_type: str, **fields) -> dict:
        with self._lock(run_id):
            run = self.load(run_id)
            seq = int(run.get("event_seq", 0)) + 1
            event = {
                "seq": seq,
                "ts": now_iso(),
                "run_id": run_id,
                "type": event_type,
                **fields,
            }
            self._append_jsonl(self.run_dir(run_id) / "events.jsonl", event)
            run["event_seq"] = seq
            run["updated_at"] = event["ts"]
            self._atomic_json(self.run_dir(run_id) / "run.json", run)
            return event

    def read_events(self, run_id: str, since: int = 0, limit: int = 500) -> list[dict]:
        events = self.read_jsonl(self.run_dir(run_id) / "events.jsonl")
        selected = [e for e in events if int(e.get("seq", 0)) > since]
        return selected[: max(1, min(limit, 1000))]

    # ---------- 快照 ----------

    def save_snapshot(self, run_id: str, snapshot: dict) -> Path:
        version = snapshot["version"]
        if not VERSION_RE.match(version):
            raise StoreError(f"非法版本号：{version}")
        path = self.path(run_id, "snapshots", f"{version}.json")
        self.write_json(path, snapshot)
        # latest 是副本，失败时仍可从版本文件恢复
        self.write_json(self.path(run_id, "snapshots", "latest.json"), snapshot)
        return path

    def snapshot_versions(self, run_id: str) -> list[str]:
        directory = self.path(run_id, "snapshots")
        if not directory.exists():
            return []
        versions = []
        for item in directory.glob("v*.json"):
            if VERSION_RE.match(item.stem):
                versions.append(item.stem)
        return sorted(versions, key=_version_key)

    def load_snapshot(self, run_id: str, version: str) -> dict:
        if version in ("latest", "", None):
            data = self.read_json(self.path(run_id, "snapshots", "latest.json"))
        else:
            if not VERSION_RE.match(version):
                raise StoreError(f"非法版本号：{version}")
            data = self.read_json(self.path(run_id, "snapshots", f"{version}.json"))
        if not data:
            raise StoreError(f"快照不存在：{run_id} {version}")
        return data

    def latest_snapshot(self, run_id: str) -> dict | None:
        return self.read_json(self.path(run_id, "snapshots", "latest.json"))

    # ---------- 文档与附件 ----------

    def save_document(self, run_id: str, version: str, markdown: str) -> Path:
        path = self.path(run_id, "documents", f"需求快照_{version}.md")
        path.write_text(markdown, encoding="utf-8")
        (self.path(run_id, "documents", "需求快照_最新.md")).write_text(markdown, encoding="utf-8")
        return path

    def read_document(self, run_id: str, version: str = "latest") -> str:
        name = f"需求快照_{version}.md" if version not in ("latest", "") else "需求快照_最新.md"
        path = self.path(run_id, "documents", name)
        if not path.exists():
            raise StoreError(f"文档不存在：{name}")
        return path.read_text(encoding="utf-8")

    def transcript(self, run_id: str) -> list[dict]:
        return self.read_jsonl(self.path(run_id, "transcript.jsonl"))

    def append_transcript(self, run_id: str, record: dict) -> None:
        with self._lock(run_id):
            self._append_jsonl(self.path(run_id, "transcript.jsonl"), record)

    def save_sidecar(self, run_id: str, name: str, obj: Any) -> Path:
        path = self.path(run_id, name)
        self.write_json(path, obj)
        return path


def _version_key(version: str) -> tuple[int, ...]:
    parts = version.lstrip("v").split(".")
    return tuple(int(p) if p.isdigit() else 0 for p in parts)


def merge_events(events: Iterable[dict]) -> list[dict]:
    return sorted(events, key=lambda e: int(e.get("seq", 0)))
