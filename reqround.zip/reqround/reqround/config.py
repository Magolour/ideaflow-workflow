from __future__ import annotations

import os
import secrets
from dataclasses import dataclass, field
from datetime import datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DEFAULT_RUNS_DIR = ROOT / "runs"
WEB_DIR = ROOT / "web"
CASES_DIR = ROOT / "cases"

DEFAULT_BASE_URL = "https://ws-381dxklyh659xv9g.cn-beijing.maas.aliyuncs.com/compatible-mode/v1"
DEFAULT_MODEL = "deepseek-v4.1-flash-1017"


def load_env(path: Path | None = None) -> None:
    """读取项目根目录 .env；已存在的环境变量优先。"""
    env_file = Path(path) if path else ROOT / ".env"
    if not env_file.exists():
        return
    for raw in env_file.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, _, value = line.partition("=")
        key = key.strip()
        value = value.strip().strip('"').strip("'")
        if key and value:
            os.environ.setdefault(key, value)


def now_iso() -> str:
    return datetime.now().astimezone().replace(microsecond=0).isoformat()


def new_run_id() -> str:
    return f"R-{datetime.now():%Y%m%d-%H%M%S}-{secrets.token_hex(2)}"


def new_snapshot_id() -> str:
    return f"SNP-{datetime.now():%Y%m%d%H%M%S}-{secrets.token_hex(2)}"


@dataclass
class Settings:
    """一次运行的全部可变参数；从 .env 读取，也可被 CLI/API 覆盖。"""

    api_key: str = ""
    base_url: str = DEFAULT_BASE_URL
    model: str = DEFAULT_MODEL
    timeout: float = 300.0
    max_rounds: int = 4
    max_rounds_cap: int = 6
    temperature_discuss: float = 0.45
    temperature_moderator: float = 0.15
    max_tokens_discuss: int = 3000
    max_tokens_moderator: int = 9000
    max_findings_per_agent: int = 5
    max_items_per_agent: int = 5
    runs_dir: Path = DEFAULT_RUNS_DIR
    web_dir: Path = WEB_DIR
    auto_assume: bool = False
    offline: bool = False
    local_moderator: bool = False
    local_agents: bool = False
    llm_max_attempts: int = 3
    coverage_gate: float = 0.90
    citation_gate: float = 0.90
    role_keys: list[str] = field(
        default_factory=lambda: ["analyst", "architect", "qa", "user"]
    )

    @classmethod
    def from_env(cls, **overrides) -> "Settings":
        load_env()
        values = dict(
            api_key=os.getenv("AI_API_KEY", "") or os.getenv("DASHSCOPE_API_KEY", ""),
            base_url=(os.getenv("AI_BASE_URL") or DEFAULT_BASE_URL).rstrip("/"),
            model=os.getenv("AI_MODEL") or DEFAULT_MODEL,
            timeout=float(os.getenv("AI_TIMEOUT", "120")),
        )
        for key, value in overrides.items():
            if value is not None:
                values[key] = value
        return cls(**values)

    def clamp_rounds(self, rounds: int | None) -> int:
        value = self.max_rounds if rounds is None else int(rounds)
        return max(2, min(self.max_rounds_cap, value))

    @property
    def clarification_gate(self) -> int:
        """默认在第 max_rounds-1 轮后暂停，向人收集澄清；最后一轮定稿。"""
        return max(1, self.max_rounds - 1)
