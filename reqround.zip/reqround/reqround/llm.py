from __future__ import annotations

import json
import re
import threading
import time
import urllib.error
import urllib.request
from dataclasses import dataclass, field
from typing import Any, Callable

from .config import Settings


class LLMError(RuntimeError):
    def __init__(self, message: str, *, code: str = "llm_error", retryable: bool = False, details: Any = None):
        super().__init__(message)
        self.code = code
        self.retryable = retryable
        self.details = details


@dataclass
class ChatResult:
    data: dict
    raw: str
    usage: dict = field(default_factory=dict)
    latency_ms: int = 0
    model: str = ""

    def summary(self) -> dict:
        return {"usage": self.usage, "latency_ms": self.latency_ms, "model": self.model}


def extract_json_object(text: str) -> dict:
    text = (text or "").strip()
    if not text:
        raise LLMError("模型返回空内容", code="empty_output", retryable=True)
    text = text.lstrip("\ufeff")
    fence = re.search(r"```(?:json)?\s*(.*?)```", text, re.S | re.I)
    if fence:
        text = fence.group(1).strip()
    start = text.find("{")
    if start < 0:
        raise LLMError("模型输出中没有 JSON 对象", code="json_missing", retryable=True, details=text[:300])
    depth = 0
    in_string = False
    escape = False
    for index in range(start, len(text)):
        char = text[index]
        if in_string:
            if escape:
                escape = False
            elif char == "\\":
                escape = True
            elif char == '"':
                in_string = False
            continue
        if char == '"':
            in_string = True
        elif char == "{":
            depth += 1
        elif char == "}":
            depth -= 1
            if depth == 0:
                candidate = text[start:index + 1]
                try:
                    data = json.loads(candidate)
                except json.JSONDecodeError as exc:
                    raise LLMError(f"JSON 解析失败：{exc}", code="json_invalid", retryable=True, details=candidate[:500]) from exc
                if not isinstance(data, dict):
                    raise LLMError("JSON 顶层不是对象", code="json_not_object", retryable=True)
                return data
    raise LLMError("JSON 大括号不匹配（可能被截断）", code="json_truncated", retryable=True, details=text[:300])


class LLMClient:
    name = "base"

    def complete_json(
        self,
        messages: list[dict],
        *,
        temperature: float = 0.2,
        max_tokens: int = 3000,
        purpose: str = "",
    ) -> ChatResult:
        raise NotImplementedError

    def describe(self) -> dict:
        return {"client": self.name}


class OpenAICompatClient(LLMClient):
    name = "openai-compatible"

    def __init__(self, settings: Settings):
        self.settings = settings
        self._lock = threading.RLock()
        self.calls = 0
        self.total_tokens = 0

    def describe(self) -> dict:
        return {
            "client": self.name,
            "base_url": self.settings.base_url,
            "model": self.settings.model,
            "configured": bool(self.settings.api_key),
        }

    def complete_json(
        self,
        messages: list[dict],
        *,
        temperature: float = 0.2,
        max_tokens: int = 3000,
        purpose: str = "",
    ) -> ChatResult:
        if not self.settings.api_key:
            raise LLMError("未配置 AI_API_KEY", code="no_api_key", retryable=False)
        payload = {
            "model": self.settings.model,
            "messages": messages,
            "temperature": temperature,
            "max_tokens": max_tokens,
            "response_format": {"type": "json_object"},
        }
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        last_error: Exception | None = None
        for attempt in range(1, 4):
            started = time.time()
            request = urllib.request.Request(
                self.settings.base_url.rstrip("/") + "/chat/completions",
                data=body,
                method="POST",
                headers={
                    "Content-Type": "application/json; charset=utf-8",
                    "Authorization": f"Bearer {self.settings.api_key}",
                },
            )
            try:
                with urllib.request.urlopen(request, timeout=self.settings.timeout) as response:
                    raw_body = response.read().decode("utf-8", "replace")
                data = json.loads(raw_body)
                choice = (data.get("choices") or [{}])[0]
                finish_reason = choice.get("finish_reason")
                content = (choice.get("message") or {}).get("content") or ""
                if finish_reason == "length":
                    raise LLMError(
                        "模型输出被截断（finish_reason=length）",
                        code="truncated",
                        retryable=True,
                        details=content[:300],
                    )
                parsed = extract_json_object(content)
                usage = data.get("usage") or {}
                with self._lock:
                    self.calls += 1
                    self.total_tokens += int(usage.get("total_tokens") or 0)
                return ChatResult(
                    data=parsed,
                    raw=content,
                    usage=usage,
                    latency_ms=int((time.time() - started) * 1000),
                    model=str(data.get("model") or self.settings.model),
                )
            except urllib.error.HTTPError as exc:
                detail = exc.read().decode("utf-8", "replace")[:800]
                retryable = exc.code == 429 or exc.code >= 500
                last_error = LLMError(
                    f"模型接口 HTTP {exc.code}：{detail[:300]}",
                    code=f"http_{exc.code}",
                    retryable=retryable,
                    details=detail,
                )
                if not retryable:
                    raise last_error from exc
            except LLMError as exc:
                last_error = exc
                if not exc.retryable:
                    raise
            except (urllib.error.URLError, TimeoutError, OSError) as exc:
                last_error = LLMError(
                    f"模型接口不可达：{exc}", code="network", retryable=True, details=str(exc)
                )
            if attempt < 3:
                time.sleep(min(6.0, 1.5 * attempt))
        assert last_error is not None
        raise last_error


class ScriptedClient(LLMClient):
    """测试/离线演示用：按顺序回放预置响应，或调用 responder。"""

    name = "scripted"

    def __init__(self, script: list[Any] | None = None, responder: Callable[[dict], Any] | None = None):
        self.script = list(script or [])
        self.responder = responder
        self.calls: list[dict] = []
        self._lock = threading.RLock()

    def describe(self) -> dict:
        return {"client": self.name, "scripted": len(self.script)}

    def complete_json(self, messages, *, temperature=0.2, max_tokens=3000, purpose=""):
        with self._lock:
            call = {
                "purpose": purpose,
                "messages": messages,
                "temperature": temperature,
                "max_tokens": max_tokens,
            }
            self.calls.append(call)
            if self.responder is not None:
                value = self.responder(call)
            else:
                if not self.script:
                    raise LLMError("ScriptedClient 脚本耗尽", code="script_exhausted", retryable=False)
                value = self.script.pop(0)
        if isinstance(value, Exception):
            raise value
        if isinstance(value, dict) and value.get("__raise__"):
            raise LLMError(str(value.get("__raise__")), code="scripted_failure", retryable=bool(value.get("retryable")))
        if isinstance(value, str):
            value = extract_json_object(value)
        if not isinstance(value, dict):
            raise LLMError("脚本响应不是对象", code="scripted_invalid")
        return ChatResult(data=value, raw=json.dumps(value, ensure_ascii=False), usage={"total_tokens": 0}, latency_ms=1)


class ReplayClient(LLMClient):
    """录制回放客户端：按 role:round:mode 返回真实运行中保存的 Agent 发言。

    未录制的轮次自动退回 LocalClient（空发言/投票），便于在模型额度受限时
    仍然演示完整的四轮流程与版本演化。
    """

    name = "replay"

    def __init__(self, path: str):
        import json
        from pathlib import Path

        self.path = str(path)
        data = json.loads(Path(path).read_text(encoding="utf-8"))
        self.entries = data.get("entries", data)
        self.fallback = LocalClient()

    def describe(self) -> dict:
        return {"client": self.name, "replay_path": self.path, "entries": len(self.entries)}

    def complete_json(self, messages, *, temperature=0.2, max_tokens=3000, purpose=""):
        parts = purpose.split(":")
        role = parts[0] if parts else ""
        round_no = parts[1].lstrip("r") if len(parts) > 1 else ""
        mode = parts[2] if len(parts) > 2 else ""
        key = f"{role}:{round_no}:{mode}"
        entry = self.entries.get(key)
        if entry is None:
            entry = self.entries.get(f"{role}:{round_no}")
        if entry is None:
            return self.fallback.complete_json(
                messages, temperature=temperature, max_tokens=max_tokens, purpose=purpose
            )
        if isinstance(entry, str):
            entry = extract_json_object(entry)
        return ChatResult(data=entry, raw=json.dumps(entry, ensure_ascii=False), usage={"total_tokens": 0}, latency_ms=1)


class LocalClient(LLMClient):
    """离线降级 Agent：不编造内容，只给投票/空发言，由本地规则综合器完成整理。"""

    name = "local"

    def describe(self) -> dict:
        return {"client": self.name}

    def complete_json(self, messages, *, temperature=0.2, max_tokens=3000, purpose=""):
        mode = purpose.split(":")[-1] if purpose else ""
        if mode == "finalize":
            return ChatResult(
                data={
                    "stance": "在离线规则模式下，确认当前快照的编号、引用与未决项记录完整，同意定稿。",
                    "findings": [],
                    "proposed_items": [],
                    "notes": "local vote",
                    "vote": "accept",
                },
                raw="",
                usage={"total_tokens": 0},
                latency_ms=1,
            )
        return ChatResult(
            data={
                "stance": "离线规则模式：本轮由主持人的覆盖检查与提案合并完成整理。",
                "findings": [],
                "proposed_items": [],
                "notes": "local agent",
            },
            raw="",
            usage={"total_tokens": 0},
            latency_ms=1,
        )


class MockClient(LLMClient):
    """无网络启发式客户端：仅用于端到端流程测试，不追求语义质量。"""

    name = "mock"

    def __init__(self):
        self.calls = 0
        self._lock = threading.RLock()

    def describe(self) -> dict:
        return {"client": self.name}

    def complete_json(self, messages, *, temperature=0.2, max_tokens=3000, purpose=""):
        with self._lock:
            self.calls += 1
        user = "\n".join(m.get("content", "") for m in messages if m.get("role") == "user")
        system = "\n".join(m.get("content", "") for m in messages if m.get("role") == "system")
        if "主持人兼规格员" in system:
            return ChatResult(data=self._moderator(user), raw="", usage={}, latency_ms=1)
        mission = "req"
        for key, label in (("需求分析师", "analyst"), ("架构评审", "architect"), ("验收测试", "qa"), ("用户代言人", "user")):
            if key in system:
                mission = label
                break
        return ChatResult(data=self._agent(user, mission), raw="", usage={}, latency_ms=1)

    @staticmethod
    def _segments(user: str) -> list[tuple[str, str]]:
        rows = []
        for line in user.splitlines():
            match = re.match(r"\[(S-\d{3})\]\s*(.+)", line.strip())
            if match:
                rows.append((match.group(1), match.group(2).strip()))
        return rows

    def _agent(self, user: str, role: str) -> dict:
        segments = self._segments(user)
        findings, items = [], []
        for seg_id, text in segments[:5]:
            if any(word in text for word in ("要", "支持", "能够", "可以")):
                items.append(
                    {
                        "type": "requirement",
                        "title": text[:18],
                        "statement": "系统应" + text.rstrip("。；;") + "。",
                        "priority": "must",
                        "origin": "explicit",
                        "acceptance": ["按原文描述可演示通过"],
                        "sources": [{"kind": "input_span", "seg_id": seg_id, "quote": text}],
                    }
                )
            elif any(word in text for word in ("必须", "不得", "限制", "预算", "工期")):
                items.append(
                    {
                        "type": "constraint",
                        "title": text[:18],
                        "statement": text,
                        "priority": "must",
                        "origin": "explicit",
                        "category": "business",
                        "sources": [{"kind": "input_span", "seg_id": seg_id, "quote": text}],
                    }
                )
        for seg_id, text in segments:
            if any(token in text for token in ("？", "?", "如何", "是否")):
                items.append(
                    {
                        "type": "open_question",
                        "title": text[:18],
                        "statement": text,
                        "priority": "must",
                        "origin": "explicit",
                        "blocking": True,
                        "why": "原文未给出明确口径",
                        "options": ["方案 A", "方案 B"],
                        "assumption": "按最常见做法处理，待用户确认",
                        "sources": [{"kind": "input_span", "seg_id": seg_id, "quote": text}],
                    }
                )
                break
        if role == "architect" and segments:
            seg_id, text = segments[0]
            findings.append(
                {
                    "kind": "risk",
                    "target_id": None,
                    "statement": "并发预约可能产生时段冲突",
                    "why_it_matters": "直接影响数据一致性与验收",
                    "severity": "major",
                    "proposal": "明确冲突检测与锁策略",
                    "question": None,
                    "sources": [{"kind": "input_span", "seg_id": seg_id, "quote": text}],
                }
            )
        return {"stance": f"{role} mock 轮次完成", "findings": findings, "proposed_items": items, "notes": ""}

    def _moderator(self, user: str) -> dict:
        segments = self._segments(user)
        ops = []
        for seg_id, text in segments:
            ops.append(
                {
                    "op": "add_item",
                    "reason": "mock 覆盖原文",
                    "item": {
                        "type": "requirement",
                        "title": text[:18],
                        "statement": "系统应" + text.rstrip("。；;") + "。",
                        "priority": "must",
                        "origin": "explicit",
                        "acceptance": ["按原文描述可演示通过"],
                        "sources": [{"kind": "input_span", "seg_id": seg_id, "quote": text}],
                    },
                }
            )
        return {
            "summary": "mock 综合完成",
            "project_summary": "mock 项目",
            "ops": ops,
            "next_focus": [],
            "converged": False,
            "convergence_reason": "mock 不判断收敛",
        }
