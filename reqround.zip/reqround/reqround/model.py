from __future__ import annotations

import copy
import hashlib
import re
from typing import Any

from .config import new_snapshot_id, now_iso
from .intake import citation_short, verify_sources

SCHEMA = "reqround.snapshot.v1"

TYPE_PREFIX = {
    "requirement": "REQ",
    "constraint": "CON",
    "open_question": "OQ",
    "out_of_scope": "OOS",
    "decision": "DEC",
}
PREFIX_TYPE = {value: key for key, value in TYPE_PREFIX.items()}
TYPE_LABELS = {
    "requirement": "明确要求",
    "constraint": "约束",
    "open_question": "待澄清项",
    "out_of_scope": "范围外",
    "decision": "关键决策",
}
TYPE_ALIASES = {
    "req": "requirement",
    "requirement": "requirement",
    "requirements": "requirement",
    "functional": "requirement",
    "功能要求": "requirement",
    "明确要求": "requirement",
    "要求": "requirement",
    "con": "constraint",
    "constraint": "constraint",
    "constraints": "constraint",
    "nfr": "constraint",
    "约束": "constraint",
    "限制": "constraint",
    "非功能": "constraint",
    "非功能要求": "constraint",
    "oq": "open_question",
    "open_question": "open_question",
    "open-question": "open_question",
    "question": "open_question",
    "待澄清": "open_question",
    "待澄清项": "open_question",
    "澄清项": "open_question",
    "疑问": "open_question",
    "oos": "out_of_scope",
    "out_of_scope": "out_of_scope",
    "out-of-scope": "out_of_scope",
    "不做": "out_of_scope",
    "范围外": "out_of_scope",
    "dec": "decision",
    "decision": "decision",
    "决策": "decision",
    "裁决": "decision",
}
PRIORITIES = {"must", "should", "could", "wont"}
PRIORITY_ALIASES = {
    "must": "must", "必须": "must", "p0": "must", "高": "must", "high": "must",
    "should": "should", "应该": "should", "p1": "should", "中": "should", "medium": "should",
    "could": "could", "可以": "could", "p2": "could", "低": "could", "low": "could",
    "wont": "wont", "不做": "wont", "暂不": "wont", "p3": "wont",
}
CATEGORIES = {
    "technical", "business", "legal", "quality", "schedule", "cost", "security", "other",
}
CATEGORY_ALIASES = {
    "技术": "technical", "technical": "technical", "tech": "technical",
    "业务": "business", "business": "business",
    "法律": "legal", "合规": "legal", "legal": "legal", "compliance": "legal",
    "质量": "quality", "quality": "quality",
    "进度": "schedule", "工期": "schedule", "schedule": "schedule", "time": "schedule",
    "成本": "cost", "预算": "cost", "cost": "cost", "budget": "cost",
    "安全": "security", "security": "security",
    "其他": "other", "other": "other",
}
SEVERITIES = {"blocking", "major", "minor"}
ORIGINS = {"explicit", "derived", "assumed"}
ACTIVE = "active"


def fingerprint(text: str) -> str:
    normalized = re.sub(r"[\s\u3000]+", "", str(text or ""))
    normalized = normalized.replace("，", ",").replace("。", ".").replace("；", ";")
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()[:16]


def clamp_text(value: Any, limit: int = 600) -> str:
    text = str(value or "").strip()
    text = re.sub(r"\s+", " ", text)
    return text[:limit]


def normalize_type(value: Any) -> str | None:
    return TYPE_ALIASES.get(str(value or "").strip().lower())


def normalize_priority(value: Any, default: str = "should") -> str:
    text = str(value or "").strip().lower()
    if text in PRIORITIES:
        return text
    return PRIORITY_ALIASES.get(text, default)


def normalize_category(value: Any) -> str:
    text = str(value or "").strip().lower()
    return CATEGORY_ALIASES.get(text, "other")


def normalize_severity(value: Any) -> str:
    text = str(value or "").strip().lower()
    return text if text in SEVERITIES else "major"


def normalize_origin(value: Any, has_input: bool = True) -> str:
    text = str(value or "").strip().lower()
    if text in ORIGINS:
        return text
    return "explicit" if has_input else "derived"


def new_snapshot(source: dict, title: str, project_id: str, max_rounds: int) -> dict:
    return {
        "schema": SCHEMA,
        "snapshot_id": new_snapshot_id(),
        "project": {
            "project_id": project_id,
            "title": title.strip() or source["title"],
            "domain": "MIS",
            "summary": "",
        },
        "version": "v0.0",
        "parent_version": None,
        "status": "draft",
        "round": 0,
        "max_rounds": max_rounds,
        "created_at": now_iso(),
        "updated_at": now_iso(),
        "source": {
            "source_id": source["source_id"],
            "title": source["title"],
            "sha256": source["sha256"],
            "sha256_short": source["sha256_short"],
            "length": source["length"],
            "segment_count": source["segment_count"],
            "segments": source["segments"],
        },
        "items": [],
        "counters": {},
        "ignored_segments": [],
        "coverage": {},
        "metrics": {},
        "quality": {"passed": False, "issues": []},
        "round_summaries": [],
        "clarifications": [],
        "warnings": [],
    }


def _next_id(snapshot: dict, item_type: str) -> str:
    prefix = TYPE_PREFIX[item_type]
    counters = snapshot.setdefault("counters", {})
    number = int(counters.get(prefix, 0)) + 1
    used = {item.get("id") for item in snapshot.get("items", [])}
    while f"{prefix}-{number:03d}" in used:
        number += 1
    counters[prefix] = number
    return f"{prefix}-{number:03d}"


def _validate_related(ids: list[Any], snapshot: dict, self_id: str | None = None) -> tuple[list[str], list[str]]:
    known = {item.get("id") for item in snapshot.get("items", [])}
    kept, warnings = [], []
    for value in ids or []:
        item_id = str(value or "").strip()
        if not item_id:
            continue
        if item_id == self_id:
            warnings.append("关联关系不能指向自身")
            continue
        if item_id not in known:
            warnings.append(f"关联条目不存在：{item_id}")
            continue
        if item_id not in kept:
            kept.append(item_id)
    return kept, warnings


def new_item(
    snapshot: dict,
    raw: dict,
    source: dict,
    transcript: list[dict] | None,
    round_no: int,
    by: str = "moderator",
) -> tuple[dict | None, list[str]]:
    """把 LLM 产出的原始条目规范化为快照条目；不分配 id（由调用方决定）。"""
    warnings: list[str] = []
    if not isinstance(raw, dict):
        return None, ["条目不是对象"]
    item_type = normalize_type(raw.get("type"))
    if item_type is None:
        return None, [f"未知条目类型：{raw.get('type')!r}"]
    statement = clamp_text(raw.get("statement") or raw.get("description") or raw.get("question"), 600)
    if not statement:
        return None, ["条目缺少 statement"]
    title = clamp_text(raw.get("title") or statement, 60)
    sources, source_warnings = verify_sources(raw.get("sources"), source, transcript)
    warnings.extend(source_warnings)
    input_sources = [s for s in sources if s.get("kind") == "input_span" and s.get("valid")]
    discussion_sources = [s for s in sources if s.get("kind") == "discussion" and s.get("valid")]
    has_input = bool(input_sources)

    item = {
        "id": "",
        "type": item_type,
        "title": title,
        "statement": statement,
        "rationale": clamp_text(raw.get("rationale") or raw.get("why") or "", 400),
        "priority": normalize_priority(raw.get("priority"), "must" if item_type == "constraint" else "should"),
        "status": ACTIVE,
        "origin": normalize_origin(raw.get("origin"), has_input),
        "sources": sources,
        "related": [],
        "acceptance": [clamp_text(x, 160) for x in (raw.get("acceptance") or []) if clamp_text(x, 160)],
        "category": normalize_category(raw.get("category")) if item_type == "constraint" else None,
        "blocking": bool(raw.get("blocking")) if item_type == "open_question" else False,
        "why": clamp_text(raw.get("why") or "", 400) if item_type == "open_question" else None,
        "options": [clamp_text(x, 120) for x in (raw.get("options") or []) if clamp_text(x, 120)]
        if item_type == "open_question"
        else [],
        # 建议默认值只是讨论中的建议，不等于已经采纳；采纳走 answer_question，写入 assumption
        "suggested_assumption": clamp_text(raw.get("assumption") or "", 300)
        if item_type == "open_question"
        else None,
        "assumption": None,
        "answer": None,
        "answer_source": None,
        "answered_at": None,
        "revision": 1,
        "fingerprint": fingerprint(statement),
        "created_round": round_no,
        "updated_round": round_no,
        "history": [],
        "citation_ok": bool(sources) and all(s.get("valid") for s in sources),
        "superseded_by": None,
    }
    if item_type == "out_of_scope":
        item["priority"] = "wont"
    if item_type == "decision":
        item["priority"] = "must"
        item["rationale"] = item["rationale"] or statement
    if item_type == "open_question" and not item["why"]:
        item["why"] = item["rationale"] or "该问题会影响需求边界或验收口径，需要确认。"
    if not item["sources"]:
        warnings.append(f"{item_type} 缺少来源引用")
    if not input_sources and item["origin"] == "explicit":
        item["origin"] = "derived" if discussion_sources else item["origin"]
    return item, warnings


def attach_id(snapshot: dict, item: dict, version: str, round_no: int, by: str = "moderator", reason: str = "") -> dict:
    item = copy.deepcopy(item)
    item["id"] = _next_id(snapshot, item["type"])
    item["history"].append(
        {
            "version": version,
            "round": round_no,
            "action": "added",
            "by": by,
            "reason": reason or "本轮新增",
            "at": now_iso(),
            "fields": sorted(item.keys()),
        }
    )
    snapshot.setdefault("items", []).append(item)
    return item


ALLOWED_PATCH_FIELDS = {
    "title", "statement", "rationale", "priority", "origin", "acceptance", "category",
    "blocking", "why", "options", "suggested_assumption", "related", "sources",
}


def _apply_update(snapshot: dict, item: dict, patch: dict, source: dict, transcript, round_no, version, by, reason):
    warnings: list[str] = []
    changed: list[str] = []
    for field in list(patch.keys()):
        if field not in ALLOWED_PATCH_FIELDS:
            warnings.append(f"字段不允许修改：{field}")
            continue
        value = patch[field]
        if field in ("title", "statement"):
            value = clamp_text(value, 600 if field == "statement" else 60)
        elif field == "rationale":
            value = clamp_text(value, 400)
        elif field == "priority":
            value = normalize_priority(value, item["priority"])
        elif field == "origin":
            value = normalize_origin(value, bool(item.get("sources")))
        elif field == "acceptance":
            value = [clamp_text(x, 160) for x in (value or []) if clamp_text(x, 160)]
        elif field == "category":
            value = normalize_category(value)
        elif field == "blocking":
            value = bool(value)
        elif field == "why":
            value = clamp_text(value, 400)
        elif field == "options":
            value = [clamp_text(x, 120) for x in (value or []) if clamp_text(x, 120)]
        elif field == "suggested_assumption":
            value = clamp_text(value, 300)
        elif field == "related":
            value, rel_warn = _validate_related(value, snapshot, item["id"])
            warnings.extend(rel_warn)
        elif field == "sources":
            value, src_warn = verify_sources(value, source, transcript)
            warnings.extend(src_warn)
        if item.get(field) != value:
            item[field] = value
            changed.append(field)
    if changed:
        item["revision"] = int(item.get("revision", 1)) + 1
        item["updated_round"] = round_no
        item["fingerprint"] = fingerprint(item.get("statement", ""))
        item["citation_ok"] = bool(item.get("sources")) and all(s.get("valid") for s in item.get("sources", []))
        item["history"].append(
            {
                "version": version,
                "round": round_no,
                "action": "modified",
                "by": by,
                "reason": reason or "综合修订",
                "at": now_iso(),
                "fields": changed,
            }
        )
    return changed, warnings


def apply_ops(
    snapshot: dict,
    ops: list[dict],
    source: dict,
    round_no: int,
    version: str,
    transcript: list[dict] | None = None,
    by: str = "moderator",
) -> tuple[dict, list[dict], list[dict]]:
    """确定性应用主持人操作。返回 (新快照, 已应用, 被拒绝)。"""
    new_snapshot = copy.deepcopy(snapshot)
    new_snapshot["parent_version"] = snapshot.get("version")
    new_snapshot["version"] = version
    new_snapshot["round"] = round_no
    new_snapshot["updated_at"] = now_iso()
    applied: list[dict] = []
    rejected: list[dict] = []
    items_by_id = {item["id"]: item for item in new_snapshot.get("items", [])}

    for index, raw_op in enumerate(ops or []):
        if not isinstance(raw_op, dict):
            rejected.append({"index": index, "op": raw_op, "reason": "操作不是对象"})
            continue
        op = str(raw_op.get("op") or "").strip()
        try:
            if op == "add_item":
                item, warnings = new_item(
                    new_snapshot, raw_op.get("item") or {}, source, transcript, round_no, by
                )
                if item is None:
                    rejected.append({"index": index, "op": op, "reason": "；".join(warnings) or "条目无效"})
                    continue
                same = next(
                    (
                        existing for existing in new_snapshot["items"]
                        if existing.get("status") == ACTIVE
                        and existing.get("type") == item["type"]
                        and existing.get("title") == item["title"]
                    ),
                    None,
                )
                if same:
                    rejected.append(
                        {"index": index, "op": op, "reason": f"同名同类型条目已存在：{same['id']}", "warnings": warnings}
                    )
                    continue
                created = attach_id(
                    new_snapshot, item, version, round_no, by,
                    reason=str(raw_op.get("reason") or "本轮新增"),
                )
                items_by_id[created["id"]] = created
                applied.append({"index": index, "op": op, "id": created["id"], "warnings": warnings})

            elif op == "update_item":
                item_id = str(raw_op.get("id") or "").strip()
                item = items_by_id.get(item_id)
                if item is None:
                    rejected.append({"index": index, "op": op, "reason": f"条目不存在：{item_id}"})
                    continue
                if item.get("status") != ACTIVE:
                    rejected.append({"index": index, "op": op, "reason": f"条目已失效，不能再改：{item_id}"})
                    continue
                patch = raw_op.get("patch") or {}
                if not isinstance(patch, dict) or not patch:
                    rejected.append({"index": index, "op": op, "reason": "patch 为空"})
                    continue
                changed, warnings = _apply_update(
                    new_snapshot, item, patch, source, transcript, round_no, version, by,
                    str(raw_op.get("reason") or ""),
                )
                if not changed:
                    rejected.append({"index": index, "op": op, "reason": "没有字段发生变化", "warnings": warnings})
                else:
                    applied.append(
                        {"index": index, "op": op, "id": item_id, "fields": changed, "warnings": warnings}
                    )

            elif op == "supersede_item":
                item_id = str(raw_op.get("id") or "").strip()
                item = items_by_id.get(item_id)
                if item is None:
                    rejected.append({"index": index, "op": op, "reason": f"条目不存在：{item_id}"})
                    continue
                if item.get("status") != ACTIVE:
                    rejected.append({"index": index, "op": op, "reason": f"条目已失效：{item_id}"})
                    continue
                target = str(raw_op.get("superseded_by") or "").strip() or None
                if target and target not in items_by_id:
                    rejected.append({"index": index, "op": op, "reason": f"替代条目不存在：{target}"})
                    continue
                item["status"] = "superseded"
                item["superseded_by"] = target
                item["revision"] = int(item.get("revision", 1)) + 1
                item["updated_round"] = round_no
                item["history"].append(
                    {
                        "version": version, "round": round_no, "action": "superseded", "by": by,
                        "reason": clamp_text(raw_op.get("reason") or "合并/去重", 300),
                        "at": now_iso(), "superseded_by": target,
                    }
                )
                applied.append({"index": index, "op": op, "id": item_id, "superseded_by": target})

            elif op == "answer_question":
                item_id = str(raw_op.get("id") or "").strip()
                item = items_by_id.get(item_id)
                if item is None or item.get("type") != "open_question":
                    rejected.append({"index": index, "op": op, "reason": f"待澄清项不存在：{item_id}"})
                    continue
                answer = clamp_text(raw_op.get("answer") or raw_op.get("assumption") or "", 500)
                if not answer:
                    rejected.append({"index": index, "op": op, "reason": "回答为空"})
                    continue
                item["answer"] = answer
                item["answer_source"] = str(raw_op.get("answer_source") or "assumption")
                item["assumption"] = clamp_text(raw_op.get("assumption") or answer, 300)
                item["answered_at"] = now_iso()
                item["revision"] = int(item.get("revision", 1)) + 1
                item["updated_round"] = round_no
                item["history"].append(
                    {
                        "version": version, "round": round_no, "action": "answered", "by": by,
                        "reason": clamp_text(raw_op.get("reason") or "澄清/默认假设", 300),
                        "at": now_iso(), "answer_source": item["answer_source"],
                    }
                )
                applied.append({"index": index, "op": op, "id": item_id})

            elif op == "ignore_segment":
                seg_id = str(raw_op.get("seg_id") or "").strip()
                known = {seg["seg_id"] for seg in source["segments"]}
                if seg_id not in known:
                    rejected.append({"index": index, "op": op, "reason": f"段不存在：{seg_id}"})
                    continue
                entry = {"seg_id": seg_id, "reason": clamp_text(raw_op.get("reason") or "", 200)}
                entries = new_snapshot.setdefault("ignored_segments", [])
                if all(e.get("seg_id") != seg_id for e in entries):
                    entries.append(entry)
                applied.append({"index": index, "op": op, "seg_id": seg_id})

            elif op == "set_project_summary":
                summary = clamp_text(raw_op.get("summary") or "", 500)
                if not summary:
                    rejected.append({"index": index, "op": op, "reason": "summary 为空"})
                    continue
                new_snapshot["project"]["summary"] = summary
                applied.append({"index": index, "op": op})

            elif op == "link":
                item_id = str(raw_op.get("id") or "").strip()
                item = items_by_id.get(item_id)
                if item is None:
                    rejected.append({"index": index, "op": op, "reason": f"条目不存在：{item_id}"})
                    continue
                related, warnings = _validate_related(raw_op.get("add_related") or [], new_snapshot, item_id)
                added = [rel for rel in related if rel not in item["related"]]
                item["related"].extend(added)
                if added:
                    item["revision"] = int(item.get("revision", 1)) + 1
                    item["updated_round"] = round_no
                    item["history"].append(
                        {
                            "version": version, "round": round_no, "action": "linked", "by": by,
                            "reason": clamp_text(raw_op.get("reason") or "", 300), "at": now_iso(),
                            "fields": ["related"], "added": added,
                        }
                    )
                    applied.append({"index": index, "op": op, "id": item_id, "added": added, "warnings": warnings})
                else:
                    rejected.append({"index": index, "op": op, "reason": "没有新增关联", "warnings": warnings})

            else:
                rejected.append({"index": index, "op": op, "reason": f"未知操作：{op!r}"})
        except Exception as exc:  # 单条操作失败不应毁掉整轮
            rejected.append({"index": index, "op": op, "reason": f"应用异常：{exc}"})

    # 清理悬挂关联
    active_ids = {item["id"] for item in new_snapshot["items"] if item.get("status") == ACTIVE}
    for item in new_snapshot["items"]:
        item["related"] = [rel for rel in item.get("related", []) if rel in active_ids and rel != item["id"]]
    return new_snapshot, applied, rejected


def compute_coverage(snapshot: dict, source: dict) -> dict:
    referenced: dict[str, list[str]] = {}
    for item in snapshot.get("items", []):
        if item.get("status") != ACTIVE:
            continue
        for src in item.get("sources", []):
            if src.get("kind") == "input_span" and src.get("valid") and src.get("seg_id"):
                referenced.setdefault(src["seg_id"], []).append(item["id"])
    ignored = {entry.get("seg_id"): entry.get("reason", "") for entry in snapshot.get("ignored_segments", [])}
    content = [seg for seg in source["segments"] if seg.get("kind") != "heading"]
    content_ids = {seg["seg_id"] for seg in content}
    uncovered = [
        seg["seg_id"]
        for seg in content
        if seg["seg_id"] not in referenced and seg["seg_id"] not in ignored
    ]
    total = len(content)
    covered = max(0, min(total, total - len(uncovered)))
    return {
        "total": total,
        "covered": covered,
        "rate": round(covered / total, 3) if total else 0.0,
        "uncovered": uncovered,
        "ignored": [seg_id for seg_id in ignored if seg_id in content_ids],
        "mapping": referenced,
    }


def finalize_snapshot(snapshot: dict, source: dict, version: str | None = None) -> dict:
    if version:
        snapshot["version"] = version
    snapshot["updated_at"] = now_iso()
    coverage = compute_coverage(snapshot, source)
    snapshot["coverage"] = coverage
    active = [item for item in snapshot.get("items", []) if item.get("status") == ACTIVE]
    counts = {key: 0 for key in TYPE_LABELS}
    for item in active:
        counts[item["type"]] = counts.get(item["type"], 0) + 1
    sources_all = [src for item in active for src in item.get("sources", [])]
    valid_sources = [src for src in sources_all if src.get("valid")]
    reqs = [item for item in active if item["type"] == "requirement"]
    req_with_acceptance = [item for item in reqs if item.get("acceptance")]
    req_with_source = [item for item in reqs if any(s.get("kind") == "input_span" and s.get("valid") for s in item.get("sources", []))]
    oqs = [item for item in active if item["type"] == "open_question"]
    blocking_open = [item for item in oqs if item.get("blocking") and not item.get("answer") and not item.get("assumption")]
    assumptions = [item for item in oqs if item.get("assumption") and not item.get("answer")]
    answered = [item for item in oqs if item.get("answer")]
    suggested_only = [item for item in oqs if item.get("suggested_assumption") and not item.get("assumption") and not item.get("answer")]
    issues: list[str] = []
    for item in active:
        if not item.get("sources"):
            issues.append(f"{item['id']} 缺少来源引用")
        elif not item.get("citation_ok"):
            issues.append(f"{item['id']} 存在未通过校验的引用")
        if item["type"] == "requirement" and not item.get("acceptance"):
            issues.append(f"{item['id']} 缺少可判定的验收要点")
        if item["type"] == "constraint" and not item.get("rationale") and not item.get("sources"):
            issues.append(f"{item['id']} 约束缺少依据")
        if item["type"] == "open_question":
            if not item.get("why"):
                issues.append(f"{item['id']} 待澄清项缺少 why")
            if not item.get("options"):
                issues.append(f"{item['id']} 待澄清项缺少可选项")
            if item.get("blocking") and not item.get("assumption") and not item.get("answer"):
                issues.append(f"{item['id']} 是阻塞项，但既无回答也无默认假设")
    title_counts: dict[tuple[str, str], int] = {}
    for item in active:
        key = (item["type"], item["title"])
        title_counts[key] = title_counts.get(key, 0) + 1
    duplicates = [f"{key[0]}：{key[1]}" for key, count in title_counts.items() if count > 1]
    if duplicates:
        issues.extend(f"重复条目：{d}" for d in duplicates)
    if coverage["uncovered"]:
        issues.append("未覆盖原文段落：" + "、".join(coverage["uncovered"]))

    citation_rate = round(len(valid_sources) / len(sources_all), 3) if sources_all else 0.0
    acceptance_rate = round(len(req_with_acceptance) / len(reqs), 3) if reqs else 1.0
    source_rate = round(len(req_with_source) / len(reqs), 3) if reqs else 1.0
    metrics = {
        "requirements": counts.get("requirement", 0),
        "constraints": counts.get("constraint", 0),
        "open_questions": counts.get("open_question", 0),
        "out_of_scope": counts.get("out_of_scope", 0),
        "decisions": counts.get("decision", 0),
        "active_items": len(active),
        "superseded_items": len([i for i in snapshot.get("items", []) if i.get("status") == "superseded"]),
        "blocking_open": len(blocking_open),
        "answered": len(answered),
        "assumed": len(assumptions),
        "suggested_only": len(suggested_only),
        "coverage_rate": coverage["rate"],
        "citation_rate": citation_rate,
        "acceptance_rate": acceptance_rate,
        "requirement_source_rate": source_rate,
        "duplicate_titles": len(duplicates),
        "total_revisions": sum(int(i.get("revision", 1)) - 1 for i in active),
        "round": snapshot.get("round", 0),
    }
    snapshot["metrics"] = metrics
    gates = {
        "schema_valid": True,
        "coverage": coverage["rate"] >= 0.90,
        "citation": citation_rate >= 0.90,
        "acceptance": acceptance_rate >= 1.0,
        "requirement_sourced": source_rate >= 0.90,
        "no_duplicates": not duplicates,
        "blocking_resolved": len(blocking_open) == 0,
    }
    snapshot["quality"] = {
        "passed": all(gates.values()),
        "gates": gates,
        "issues": issues,
    }
    snapshot["warnings"] = issues
    return snapshot


def set_round_summary(snapshot: dict, summary: dict) -> None:
    summaries = snapshot.setdefault("round_summaries", [])
    summaries = [s for s in summaries if int(s.get("round", -1)) != int(summary["round"])]
    summaries.append(summary)
    summaries.sort(key=lambda s: int(s.get("round", 0)))
    snapshot["round_summaries"] = summaries


def diff_snapshots(old: dict, new: dict) -> dict:
    old_items = {item["id"]: item for item in old.get("items", [])}
    new_items = {item["id"]: item for item in new.get("items", [])}
    changes: list[dict] = []
    for item_id, item in new_items.items():
        if item_id not in old_items:
            changes.append(
                {"kind": "added", "id": item_id, "type": item["type"], "title": item["title"], "summary": "新增"}
            )
            continue
        before = old_items[item_id]
        fields = []
        for field in ("title", "statement", "priority", "acceptance", "category", "blocking", "why", "options", "origin", "status"):
            if before.get(field) != item.get(field):
                fields.append(field)
        if item.get("answer") and not before.get("answer"):
            changes.append(
                {"kind": "answered", "id": item_id, "type": item["type"], "title": item["title"],
                 "summary": f"已回答：{item['answer'][:50]}"}
            )
        elif fields:
            changes.append(
                {"kind": "modified", "id": item_id, "type": item["type"], "title": item["title"],
                 "fields": fields, "summary": "修订：" + "、".join(fields)}
            )
        if item.get("assumption") and not item.get("answer") and not before.get("assumption"):
            changes.append(
                {"kind": "assumed", "id": item_id, "type": item["type"], "title": item["title"],
                 "summary": f"采纳默认假设：{item['assumption'][:50]}"}
            )
    for item_id, item in old_items.items():
        if item_id not in new_items and item.get("status") == ACTIVE:
            changes.append(
                {"kind": "removed", "id": item_id, "type": item["type"], "title": item["title"], "summary": "移除"}
            )
        elif item_id in new_items and item.get("status") == ACTIVE and new_items[item_id].get("status") != ACTIVE:
            changes.append(
                {"kind": "superseded", "id": item_id, "type": item["type"], "title": item["title"],
                 "summary": f"合并/替代为 {new_items[item_id].get('superseded_by') or '（无）'}"}
            )
    counts: dict[str, int] = {}
    for change in changes:
        counts[change["kind"]] = counts.get(change["kind"], 0) + 1
    return {
        "from": old.get("version"),
        "to": new.get("version"),
        "counts": counts,
        "changes": changes,
        "metrics": {
            "blocking_open": new.get("metrics", {}).get("blocking_open"),
            "coverage_rate": new.get("metrics", {}).get("coverage_rate"),
        },
    }
