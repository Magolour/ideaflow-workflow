from __future__ import annotations

from datetime import datetime
from typing import Any

from .model import TYPE_LABELS, fingerprint

PRIORITY_LABELS = {"must": "Must", "should": "Should", "could": "Could", "wont": "Won't"}
STATUS_LABELS = {
    "draft": "草稿",
    "candidate": "候选待批准",
    "approved": "已批准",
    "approved_with_open_questions": "已批准（含未决项）",
    "superseded": "已被替代",
    "rejected": "已拒绝",
}
MODE_LABELS = {
    "diverge": "独立发散",
    "challenge": "交叉质询",
    "converge": "聚焦收敛",
    "finalize": "定稿签署",
}
CATEGORY_LABELS = {
    "technical": "技术",
    "business": "业务",
    "legal": "合规",
    "quality": "质量",
    "schedule": "工期",
    "cost": "成本",
    "security": "安全",
    "other": "其他",
}
ORIGIN_LABELS = {"explicit": "原文明确", "derived": "讨论推导", "assumed": "默认假设"}


def active_items(snapshot: dict) -> list[dict]:
    return [item for item in snapshot.get("items", []) if item.get("status") == "active"]


def by_type(snapshot: dict, item_type: str) -> list[dict]:
    return [item for item in active_items(snapshot) if item.get("type") == item_type]


def short_quote(source: dict, limit: int = 90) -> str:
    quote = str(source.get("quote") or "").replace("\n", " ").strip()
    if len(quote) > limit:
        quote = quote[:limit] + "…"
    return quote


def compact_snapshot(snapshot: dict, *, quote_limit: int = 200) -> dict:
    """给 LLM 看的紧凑视图，避免整份快照与原文一起撑爆上下文。"""

    def source_view(item: dict) -> list[dict]:
        rows = []
        for src in item.get("sources", []):
            if src.get("kind") == "discussion":
                rows.append(
                    {
                        "kind": "discussion",
                        "round": src.get("round"),
                        "agent": src.get("agent"),
                        "quote": short_quote(src, quote_limit),
                        "valid": src.get("valid"),
                    }
                )
            else:
                rows.append(
                    {
                        "kind": "input_span",
                        "seg_id": src.get("seg_id"),
                        "quote": short_quote(src, quote_limit),
                    }
                )
        return rows

    view: dict[str, Any] = {
        "version": snapshot.get("version"),
        "round": snapshot.get("round"),
        "project": {
            "title": snapshot.get("project", {}).get("title"),
            "summary": snapshot.get("project", {}).get("summary"),
        },
        "metrics": {
            "blocking_open": snapshot.get("metrics", {}).get("blocking_open"),
            "coverage_rate": snapshot.get("metrics", {}).get("coverage_rate"),
        },
    }
    groups = {
        "requirements": [],
        "constraints": [],
        "open_questions": [],
        "out_of_scope": [],
        "decisions": [],
    }
    for item in active_items(snapshot):
        item_type = item["type"]
        if item_type == "requirement":
            groups["requirements"].append(
                {
                    "id": item["id"],
                    "title": item["title"],
                    "statement": item["statement"],
                    "priority": item["priority"],
                    "origin": item["origin"],
                    "acceptance": item.get("acceptance", []),
                    "sources": source_view(item),
                    "related": item.get("related", []),
                }
            )
        elif item_type == "constraint":
            groups["constraints"].append(
                {
                    "id": item["id"],
                    "title": item["title"],
                    "statement": item["statement"],
                    "category": item.get("category"),
                    "origin": item["origin"],
                    "rationale": item.get("rationale"),
                    "sources": source_view(item),
                }
            )
        elif item_type == "open_question":
            groups["open_questions"].append(
                {
                    "id": item["id"],
                    "title": item["title"],
                    "statement": item["statement"],
                    "why": item.get("why"),
                    "blocking": item.get("blocking"),
                    "options": item.get("options", []),
                    "suggested_assumption": item.get("suggested_assumption"),
                    "assumption": item.get("assumption"),
                    "answer": item.get("answer"),
                    "answer_source": item.get("answer_source"),
                    "related": item.get("related", []),
                    "sources": source_view(item),
                }
            )
        elif item_type == "out_of_scope":
            groups["out_of_scope"].append(
                {"id": item["id"], "title": item["title"], "statement": item["statement"], "sources": source_view(item)}
            )
        elif item_type == "decision":
            groups["decisions"].append(
                {
                    "id": item["id"],
                    "title": item["title"],
                    "statement": item["statement"],
                    "rationale": item.get("rationale"),
                    "related": item.get("related", []),
                }
            )
    view.update(groups)
    view["superseded"] = [
        {"id": i["id"], "title": i["title"], "superseded_by": i.get("superseded_by")}
        for i in snapshot.get("items", [])
        if i.get("status") == "superseded"
    ]
    return view


def _cell(value: Any) -> str:
    text = str(value if value is not None else "").replace("|", "\\|").replace("\n", " ")
    return text.strip()


def _source_text(src: dict) -> str:
    if src.get("kind") == "discussion":
        return f"第{src.get('round')}轮·{src.get('agent')}：“{short_quote(src, 60)}”"
    seg = src.get("seg_id") or "?"
    return f"{seg}：“{short_quote(src, 60)}”"


def _source_list(item: dict) -> str:
    rows = [_source_text(src) for src in item.get("sources", []) if src.get("valid")]
    invalid = [src for src in item.get("sources", []) if not src.get("valid")]
    if invalid:
        rows.append(f"（另有 {len(invalid)} 条引用未通过校验）")
    return "；".join(rows) if rows else "（无有效引用）"


def render_markdown(
    snapshot: dict,
    source: dict,
    run: dict | None = None,
    diff: dict | None = None,
) -> str:
    project = snapshot.get("project", {})
    title = project.get("title") or source.get("title") or "未命名项目"
    version = snapshot.get("version", "v0.0")
    status = STATUS_LABELS.get(snapshot.get("status", "draft"), snapshot.get("status"))
    requirements = by_type(snapshot, "requirement")
    constraints = by_type(snapshot, "constraint")
    questions = by_type(snapshot, "open_question")
    out_of_scope = by_type(snapshot, "out_of_scope")
    decisions = by_type(snapshot, "decision")
    metrics = snapshot.get("metrics", {})
    quality = snapshot.get("quality", {})
    lines: list[str] = []
    add = lines.append

    add(f"# 《{title}》需求快照 {version}")
    add("")
    add(f"> **版本**：{version}　|　**状态**：{status}　|　**轮次**：{snapshot.get('round', 0)} / {snapshot.get('max_rounds', '?')}")
    add(f"> **项目编号**：{project.get('project_id', '')}　|　**快照编号**：{snapshot.get('snapshot_id', '')}")
    add(f"> **生成时间**：{snapshot.get('updated_at', '')}　|　**原文指纹**：`{source.get('sha256_short', '')}`（{source.get('segment_count', 0)} 段）")
    add(f"> **本版父版本**：{snapshot.get('parent_version') or '—'}　|　**编号规则**：REQ 功能要求 / CON 约束 / OQ 待澄清 / OOS 范围外 / DEC 决策")
    add("")

    summary = project.get("summary") or "（尚未形成项目摘要）"
    add("## 1. 项目概述")
    add("")
    add(summary)
    add("")
    add("本快照把用户原始输入拆成带编号的条目，并区分**明确要求、约束、待澄清项**。每条条目都保留原文引用；"
        "修改以新版本落盘，旧版本只读，可通过 diff 追溯每一条为什么改、被谁改。")
    add("")

    add("## 2. 明确要求（REQ）")
    add("")
    if requirements:
        add("| 编号 | 要求 | 优先级 | 验收要点 | 来源 |")
        add("| --- | --- | --- | --- | --- |")
        for item in requirements:
            acceptance = "；".join(item.get("acceptance", [])) or "—"
            add(
                f"| {_cell(item['id'])} | {_cell(item['title'])}：{_cell(item['statement'])} | "
                f"{PRIORITY_LABELS.get(item['priority'], item['priority'])} | {_cell(acceptance)} | {_cell(_source_list(item))} |"
            )
        add("")
        for item in requirements:
            add(f"### {item['id']} {item['title']}")
            add("")
            add(f"- **陈述**：{item['statement']}")
            add(f"- **优先级**：{PRIORITY_LABELS.get(item['priority'], item['priority'])}　|　**来源类型**：{ORIGIN_LABELS.get(item['origin'], item['origin'])}　|　**修订**：rev.{item.get('revision', 1)}")
            if item.get("acceptance"):
                add("- **验收要点**：")
                for index, criterion in enumerate(item["acceptance"], 1):
                    add(f"  {index}. {criterion}")
            add(f"- **来源引用**：{_source_list(item)}")
            if item.get("related"):
                add(f"- **关联**：{'、'.join(item['related'])}")
            add("")
    else:
        add("（本版尚无明确要求。）")
        add("")

    add("## 3. 约束（CON）")
    add("")
    if constraints:
        add("| 编号 | 约束 | 类别 | 来源类型 | 依据 |")
        add("| --- | --- | --- | --- | --- |")
        for item in constraints:
            add(
                f"| {_cell(item['id'])} | {_cell(item['statement'])} | "
                f"{CATEGORY_LABELS.get(item.get('category'), item.get('category') or '其他')} | "
                f"{ORIGIN_LABELS.get(item['origin'], item['origin'])} | {_cell(_source_list(item))} |"
            )
        add("")
        for item in constraints:
            add(f"### {item['id']} {item['title']}")
            add("")
            add(f"- **约束**：{item['statement']}")
            add(f"- **类别**：{CATEGORY_LABELS.get(item.get('category'), item.get('category') or '其他')}　|　**来源类型**：{ORIGIN_LABELS.get(item['origin'], item['origin'])}　|　**优先级**：{PRIORITY_LABELS.get(item['priority'], item['priority'])}")
            if item.get("rationale"):
                add(f"- **依据**：{item['rationale']}")
            add(f"- **来源引用**：{_source_list(item)}")
            add("")
    else:
        add("（本版尚无约束。）")
        add("")

    add("## 4. 待澄清项（OQ）")
    add("")
    if questions:
        add("| 编号 | 问题 | 阻塞 | 状态 | 回答/默认假设 | 关联 |")
        add("| --- | --- | --- | --- | --- | --- |")
        for item in questions:
            state = "已回答" if item.get("answer") else ("默认假设" if item.get("assumption") else "待澄清")
            answer = item.get("answer") or item.get("assumption") or "—"
            add(
                f"| {_cell(item['id'])} | {_cell(item['statement'])} | {'是' if item.get('blocking') else '否'} | "
                f"{state} | {_cell(answer)} | {_cell('、'.join(item.get('related', [])) or '—')} |"
            )
        add("")
        for item in questions:
            add(f"### {item['id']} {item['title']}")
            add("")
            add(f"- **问题**：{item['statement']}")
            add(f"- **为什么重要**：{item.get('why') or '—'}")
            add(f"- **是否阻塞**：{'是' if item.get('blocking') else '否'}　|　**状态**：{'已回答' if item.get('answer') else ('默认假设' if item.get('assumption') else '待澄清')}")
            if item.get("options"):
                add(f"- **可选项**：{'；'.join(item['options'])}")
            if item.get("suggested_assumption") and not item.get("assumption") and not item.get("answer"):
                add(f"- **建议默认值（尚未采纳）**：{item['suggested_assumption']}")
            if item.get("answer"):
                add(f"- **回答**：{item['answer']}（来源：{item.get('answer_source') or '—'}）")
            elif item.get("assumption"):
                add(f"- **已采纳默认假设**：{item['assumption']}（未经用户确认）")
            add(f"- **来源引用**：{_source_list(item)}")
            if item.get("related"):
                add(f"- **关联**：{'、'.join(item['related'])}")
            add("")
    else:
        add("（本版没有待澄清项。）")
        add("")

    add("## 5. 范围外（OOS）")
    add("")
    if out_of_scope:
        for item in out_of_scope:
            add(f"- **{item['id']} {item['title']}**：{item['statement']}（来源：{_source_list(item)}）")
    else:
        add("（未显式声明范围外事项。）")
    add("")

    add("## 6. 关键决策（DEC）")
    add("")
    if decisions:
        for item in decisions:
            add(f"- **{item['id']} {item['title']}**：{item['statement']}")
            if item.get("rationale"):
                add(f"  - 理由：{item['rationale']}")
            if item.get("related"):
                add(f"  - 关联：{'、'.join(item['related'])}")
    else:
        add("（本版没有需要单独立项的决策。）")
    add("")

    add("## 7. 需求追踪矩阵")
    add("")
    mapping = snapshot.get("coverage", {}).get("mapping", {})
    ignored = {entry.get("seg_id"): entry.get("reason", "") for entry in snapshot.get("ignored_segments", [])}
    add("| 原文段 | 原文摘要 | 被哪些条目引用 | 状态 |")
    add("| --- | --- | --- | --- |")
    for seg in source["segments"]:
        refs = mapping.get(seg["seg_id"], [])
        if seg.get("kind") == "heading":
            state = "结构标题"
        elif refs:
            state = "已覆盖"
        elif seg["seg_id"] in ignored:
            state = "已说明忽略"
        else:
            state = "未覆盖"
        add(f"| {seg['seg_id']} | {_cell(seg['text'][:70])} | {_cell('、'.join(refs) or '—')} | {state} |")
    add("")

    add("## 8. 质量门禁与指标")
    add("")
    add("| 指标 | 数值 | 门禁 | 结果 |")
    add("| --- | --- | --- | --- |")
    gate_rows = [
        ("原文覆盖率", metrics.get("coverage_rate"), "≥ 0.90", quality.get("gates", {}).get("coverage")),
        ("引用有效率", metrics.get("citation_rate"), "≥ 0.90", quality.get("gates", {}).get("citation")),
        ("验收要点完整率", metrics.get("acceptance_rate"), "= 1.00", quality.get("gates", {}).get("acceptance")),
        ("要求有原文来源率", metrics.get("requirement_source_rate"), "≥ 0.90", quality.get("gates", {}).get("requirement_sourced")),
        ("阻塞待澄清项", metrics.get("blocking_open"), "= 0", quality.get("gates", {}).get("blocking_resolved")),
        ("重复条目", metrics.get("duplicate_titles"), "= 0", quality.get("gates", {}).get("no_duplicates")),
    ]
    for name, value, threshold, passed in gate_rows:
        add(f"| {name} | {value} | {threshold} | {'通过' if passed else '未通过'} |")
    add("")
    if quality.get("issues"):
        add("**待修复问题**：")
        add("")
        for issue in quality["issues"]:
            add(f"- {issue}")
        add("")

    add("## 9. 讨论轮次摘要")
    add("")
    summaries = snapshot.get("round_summaries", [])
    if summaries:
        add("| 轮次 | 模式 | 本版 | 发言/失败 | 新增 | 修订 | 合并 | 回答 | 阻塞待澄清 | 结论 |")
        add("| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |")
        for row in summaries:
            agents = row.get("agents", {})
            agent_text = f"{len([a for a in agents.values() if a.get('status') == 'ok'])} 成功"
            failed = [key for key, value in agents.items() if value.get("status") != "ok"]
            if failed:
                agent_text += f" / {len(failed)} 失败"
            ops = row.get("ops", {})
            add(
                f"| {row.get('round')} | {MODE_LABELS.get(row.get('mode'), row.get('mode'))} | {row.get('version')} | {agent_text} | "
                f"{ops.get('added', 0)} | {ops.get('updated', 0)} | {ops.get('superseded', 0)} | {ops.get('answered', 0)} | "
                f"{row.get('blocking_open', 0)} | {_cell(row.get('summary', ''))} |"
            )
        add("")
        for row in summaries:
            add(f"- **第 {row.get('round')} 轮**（{MODE_LABELS.get(row.get('mode'), row.get('mode'))}）：{row.get('summary', '')}")
            if row.get("next_focus"):
                add(f"  - 下一轮聚焦：{'；'.join(row['next_focus'])}")
            if row.get("convergence_reason"):
                add(f"  - 收敛判断：{row['convergence_reason']}")
        add("")
    else:
        add("（尚无轮次记录。）")
        add("")

    if diff:
        add("## 10. 本版变更")
        add("")
        add(f"相对 {diff.get('from')}：新增 {diff.get('counts', {}).get('added', 0)}，"
            f"修订 {diff.get('counts', {}).get('modified', 0)}，回答 {diff.get('counts', {}).get('answered', 0)}，"
            f"合并 {diff.get('counts', {}).get('superseded', 0)}。")
        add("")
        if diff.get("changes"):
            add("| 类型 | 编号 | 标题 | 说明 |")
            add("| --- | --- | --- | --- |")
            for change in diff["changes"]:
                add(
                    f"| {change.get('kind')} | {_cell(change.get('id'))} | {_cell(change.get('title'))} | {_cell(change.get('summary'))} |"
                )
            add("")

    add("## 附录 A：原始需求（分段存档）")
    add("")
    add(f"> 原文长度 {source.get('length', 0)} 字符，SHA-256 前 12 位 `{source.get('sha256_short', '')}`。以下分段与正文引用编号一一对应。")
    add("")
    for seg in source["segments"]:
        add(f"- `{seg['seg_id']}`（字符 {seg['start']}–{seg['end']}）：{seg['text']}")
    add("")

    add("## 附录 B：版本与口径说明")
    add("")
    add("- **版本号**：`v0.N` 表示第 N 轮讨论后的快照；`v1.0` 表示人工批准后的基线。旧版本文件只读保留。")
    add("- **编号稳定性**：条目编号一经分配永不复用；合并/删除用状态与 `superseded_by` 留痕，不抹掉历史。")
    add("- **来源引用**：`S-xxx` 指向原始需求分段；讨论引用标注轮次与发言角色。引用已由程序逐条校验是否逐字出现在原文/记录中。")
    add("- **待澄清项**：`blocking=true` 表示不解决会影响开发或验收；`assumption` 是无人回答时的默认假设，不等同于用户确认。")
    add("")
    add(f"---\n*由 ReqRound 需求圆桌生成 · {datetime.now().strftime('%Y-%m-%d %H:%M')}*")
    return "\n".join(lines) + "\n"


def render_diff_markdown(diff: dict, title: str = "") -> str:
    lines = [f"# 需求快照变更：{diff.get('from')} → {diff.get('to')}", ""]
    if title:
        lines.append(f"> {title}")
        lines.append("")
    counts = diff.get("counts", {})
    lines.append(
        f"共 {sum(counts.values())} 处变化：新增 {counts.get('added', 0)}，修订 {counts.get('modified', 0)}，"
        f"回答 {counts.get('answered', 0)}，合并/替代 {counts.get('superseded', 0)}，移除 {counts.get('removed', 0)}。"
    )
    lines.append("")
    lines.append("| 类型 | 编号 | 标题 | 说明 |")
    lines.append("| --- | --- | --- | --- |")
    for change in diff.get("changes", []):
        summary = change.get("summary", "")
        if change.get("fields"):
            summary += "（" + "、".join(change["fields"]) + "）"
        lines.append(f"| {change.get('kind')} | {change.get('id')} | {change.get('title')} | {summary} |")
    lines.append("")
    return "\n".join(lines)


def snapshot_digest(snapshot: dict) -> dict:
    metrics = snapshot.get("metrics", {})
    return {
        "version": snapshot.get("version"),
        "status": snapshot.get("status"),
        "round": snapshot.get("round"),
        "requirements": metrics.get("requirements", 0),
        "constraints": metrics.get("constraints", 0),
        "open_questions": metrics.get("open_questions", 0),
        "blocking_open": metrics.get("blocking_open", 0),
        "coverage_rate": metrics.get("coverage_rate", 0),
        "quality_passed": snapshot.get("quality", {}).get("passed", False),
    }


def build_handoff_requirement_brief(snapshot: dict) -> str:
    project = snapshot.get("project", {})
    lines = [
        f"项目：{project.get('title', '')}",
        f"目标：{project.get('summary', '')}",
        "",
        "以下需求快照已通过多 Agent 讨论与版本冻结，请据此拆解任务。每条要求前保留编号，便于追溯。",
        "",
    ]
    for item in by_type(snapshot, "requirement"):
        lines.append(f"[{item['id']}] {item['statement']}（优先级 {item['priority']}）")
        for criterion in item.get("acceptance", []):
            lines.append(f"  - 验收：{criterion}")
    constraints = by_type(snapshot, "constraint")
    if constraints:
        lines.append("")
        lines.append("约束：")
        for item in constraints:
            lines.append(f"[{item['id']}] {item['statement']}")
    open_questions = by_type(snapshot, "open_question")
    unresolved = [q for q in open_questions if q.get("blocking") and not q.get("answer") and not q.get("assumption")]
    if unresolved:
        lines.append("")
        lines.append("尚未解决的阻塞问题（拆解时需保留为风险）：")
        for item in unresolved:
            lines.append(f"[{item['id']}] {item['statement']}")
    return "\n".join(lines).strip()


def item_fingerprint(item: dict) -> str:
    return item.get("fingerprint") or fingerprint(item.get("statement", ""))


def title_of(snapshot: dict) -> str:
    return snapshot.get("project", {}).get("title") or "未命名项目"


__all__ = [
    "TYPE_LABELS",
    "active_items",
    "by_type",
    "compact_snapshot",
    "render_markdown",
    "render_diff_markdown",
    "snapshot_digest",
    "build_handoff_requirement_brief",
    "title_of",
]
