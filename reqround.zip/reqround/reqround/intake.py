from __future__ import annotations

import hashlib
import re
from typing import Any

SENTENCE_RE = re.compile(r"[^。！？!?；;\n]+[。！？!?；;]?")
WS_RE = re.compile(r"\s+")


def normalize_text(text: str) -> str:
    return text.replace("\r\n", "\n").replace("\r", "\n").strip()


def _clean_segment(full: str, match_start: int) -> dict | None:
    """去掉 Markdown 标题井号与列表序号，保留其在原文中的精确偏移。"""
    stripped = full.strip()
    if not stripped:
        return None
    leading = len(full) - len(full.lstrip())
    text = stripped
    kind = "content"
    level = None
    heading = re.match(r"^(#{1,6})\s+(.*)$", text)
    if heading:
        level = len(heading.group(1))
        text = heading.group(2).strip()
        kind = "heading"
    else:
        bullet = re.match(r"^(?:[-*+]|\d+[.、)])\s+(.*)$", text)
        if bullet:
            text = bullet.group(1).strip()
    if not text or re.fullmatch(r"[-*_—\s]{3,}", text):
        return None
    offset = full.find(text, leading)
    if offset < 0:
        offset = leading
    return {
        "text": text,
        "start": match_start + offset,
        "end": match_start + offset + len(text),
        "kind": kind,
        "heading_level": level,
    }


def segment_text(raw: str) -> list[dict]:
    """按句号/分号/换行切段，保留原文精确偏移，供前端高亮与引用校验。"""
    segments: list[dict] = []
    for match in SENTENCE_RE.finditer(raw):
        match_start = match.start()
        cleaned = _clean_segment(match.group(0), match_start)
        if cleaned is None:
            continue
        segments.append(
            {
                "seg_id": f"S-{len(segments) + 1:03d}",
                "text": cleaned["text"],
                "start": cleaned["start"],
                "end": cleaned["end"],
                "char_count": len(cleaned["text"]),
                "kind": cleaned["kind"],
                "heading_level": cleaned["heading_level"],
            }
        )
    return segments


def build_source(text: str, title: str = "") -> dict:
    raw = normalize_text(text)
    if not raw:
        raise ValueError("需求原文为空")
    segments = segment_text(raw)
    if not segments:
        raise ValueError("无法从需求原文切出有效句子")
    digest = hashlib.sha256(raw.encode("utf-8")).hexdigest()
    first_heading = next((seg["text"] for seg in segments if seg.get("kind") == "heading"), "")
    return {
        "source_id": "SRC-001",
        "title": title.strip() or first_heading or "原始需求",
        "raw_text": raw,
        "sha256": digest,
        "sha256_short": digest[:12],
        "length": len(raw),
        "segment_count": len(segments),
        "segments": segments,
        "created_at": None,
    }


def source_for_prompt(source: dict, with_ids: bool = True) -> str:
    lines = []
    for seg in source["segments"]:
        prefix = f"[{seg['seg_id']}] " if with_ids else ""
        mark = "（结构标题，不是需求）" if seg.get("kind") == "heading" else ""
        lines.append(prefix + mark + seg["text"])
    return "\n".join(lines)


def content_segments(source: dict) -> list[dict]:
    return [seg for seg in source.get("segments", []) if seg.get("kind") != "heading"]


def _norm_for_match(text: str) -> str:
    text = WS_RE.sub("", text or "")
    for token in ("……", "…", "...", "⋯"):
        text = text.replace(token, "")
    return text


def locate_quote(raw: str, quote: str) -> tuple[int, int] | None:
    """在原文中定位引用；支持省略号分段引用。返回原文偏移。"""
    quote = (quote or "").strip()
    if not quote:
        return None
    exact = raw.find(quote)
    if exact >= 0:
        return exact, exact + len(quote)
    parts = [p.strip() for p in re.split(r"……|…|\.\.\.|⋯", quote) if p.strip()]
    if len(parts) > 1:
        cursor = 0
        first_start = -1
        last_end = -1
        for part in parts:
            found = raw.find(part, cursor)
            if found < 0:
                return None
            if first_start < 0:
                first_start = found
            last_end = found + len(part)
            cursor = last_end
        return first_start, last_end
    compact = _norm_for_match(quote)
    if not compact:
        return None
    # 去掉空白后再匹配：逐字符扫描原文，忽略空白
    positions = [i for i, ch in enumerate(raw) if not ch.isspace()]
    chars = "".join(raw[i] for i in positions)
    found = chars.find(compact)
    if found < 0:
        return None
    start = positions[found]
    end = positions[found + len(compact) - 1] + 1
    return start, end


def verify_input_source(src: dict, source: dict) -> dict:
    """校验一条 input_span 引用，并补齐/修正偏移。"""
    out = dict(src or {})
    out.setdefault("kind", "input_span")
    seg_id = str(out.get("seg_id") or "").strip()
    quote = str(out.get("quote") or "").strip()
    segments = {seg["seg_id"]: seg for seg in source["segments"]}
    seg = segments.get(seg_id)
    if seg is None:
        out.update({"valid": False, "error": "seg_id 不存在", "seg_id": seg_id})
        return out
    located = locate_quote(seg["text"], quote) if quote else None
    if located is not None:
        out.update(
            {
                "valid": True,
                "quote": seg["text"][located[0]:located[1]],
                "start": seg["start"] + located[0],
                "end": seg["start"] + located[1],
                "match": "segment",
            }
        )
        return out
    # 跨段引用或引用整段：允许在全文定位，并换算所属段
    if quote:
        full = locate_quote(source["raw_text"], quote)
        if full is not None:
            first = next(
                (s for s in source["segments"] if s["start"] <= full[0] < s["end"]),
                seg,
            )
            out.update(
                {
                    "valid": True,
                    "seg_id": seg["seg_id"] if seg["start"] <= full[0] < seg["end"] else first["seg_id"],
                    "quote": source["raw_text"][full[0]:full[1]],
                    "start": full[0],
                    "end": full[1],
                    "match": "document",
                }
            )
            return out
    out.update({"valid": False, "error": "引言未在对应原文段落中找到", "seg_id": seg_id})
    return out


def verify_discussion_source(src: dict, transcript: list[dict]) -> dict:
    out = dict(src or {})
    out.setdefault("kind", "discussion")
    agent = str(out.get("agent") or "").strip()
    quote = _norm_for_match(str(out.get("quote") or ""))
    round_no = out.get("round")
    if not agent or not quote:
        out.update({"valid": False, "error": "讨论引用缺少 agent 或 quote"})
        return out
    for record in transcript:
        if record.get("agent") != agent:
            continue
        if round_no is not None and int(record.get("round", -1)) != int(round_no):
            continue
        text = _norm_for_match(_record_text(record))
        if quote in text:
            out.update({"valid": True, "match": "transcript"})
            return out
    out.update({"valid": False, "error": "讨论引用未在记录中找到"})
    return out


def _record_text(record: dict) -> str:
    response = record.get("response")
    if isinstance(response, dict):
        chunks = []
        for key in ("stance", "notes", "summary", "convergence_reason"):
            if response.get(key):
                chunks.append(str(response[key]))
        for finding in response.get("findings") or []:
            chunks.extend(str(finding.get(k, "")) for k in ("statement", "why_it_matters", "proposal", "question"))
        for item in response.get("proposed_items") or []:
            chunks.extend(str(item.get(k, "")) for k in ("title", "statement", "why", "rationale"))
        return " ".join(chunks)
    return str(record.get("raw") or "")


def verify_sources(
    sources: list[Any] | None,
    source: dict,
    transcript: list[dict] | None = None,
) -> tuple[list[dict], list[str]]:
    valid_sources: list[dict] = []
    warnings: list[str] = []
    for item in sources or []:
        if isinstance(item, str):
            item = {"kind": "input_span", "seg_id": item, "quote": ""}
        if not isinstance(item, dict):
            continue
        kind = str(item.get("kind") or "input_span")
        if kind == "discussion":
            verified = verify_discussion_source(item, transcript or [])
        else:
            verified = verify_input_source(item, source)
        if verified.get("valid"):
            valid_sources.append(verified)
        else:
            warnings.append(f"引用无效：{verified.get('error')}（{verified.get('seg_id') or verified.get('agent') or ''}）")
            verified["valid"] = False
            valid_sources.append(verified)
    return valid_sources, warnings


def citation_short(source_item: dict, limit: int = 60) -> str:
    quote = str(source_item.get("quote") or "").replace("\n", " ")
    if len(quote) > limit:
        quote = quote[:limit] + "…"
    return quote
