"""本地规则综合器：模型不可用时的确定性降级路径。

它不是"假数据"：Agent 仍然可以产生真实发言（或由 LocalClient 空跑），
本模块负责把提案去重、把原文里尚未覆盖的句子按规则归为要求/约束/澄清项，
并给出可审计的 ops。质量低于 LLM 综合，但流程、版本、引用校验完全一致。
"""

from __future__ import annotations

import copy
import re
from difflib import SequenceMatcher
from typing import Any

from .model import apply_ops, finalize_snapshot, normalize_priority, normalize_type
from .intake import verify_sources


def _norm(text: str) -> str:
    return re.sub(r"[\s\u3000，。；：、！？!?,.!;:\"'“”‘’（）()《》<>·—\-]+", "", str(text or "")).lower()


TOPIC_WORDS = (
    "冲突", "审批", "机时", "计费", "收费", "爽约", "修改", "取消", "导入", "报表",
    "看板", "导师", "老设备", "贵重", "签到", "预约", "权限", "口径", "通知", "批量",
)


def _similar_statement(a: str, b: str) -> bool:
    left, right = _norm(a), _norm(b)
    if not left or not right:
        return False
    if left == right:
        return True
    if len(left) >= 10 and (left in right or right in left):
        return True
    return SequenceMatcher(None, left, right).ratio() >= 0.62


def _similar(a: str, b: str) -> bool:
    left, right = _norm(a), _norm(b)
    if not left or not right:
        return False
    if left == right:
        return True
    if len(left) >= 8 and (left in right or right in left):
        return True
    shared = sum(1 for word in TOPIC_WORDS if word in left and word in right)
    if shared >= 2 and SequenceMatcher(None, left, right).ratio() >= 0.28:
        return True
    # 强主题词：爽约/计费/收费/导师等，只要双方都命中同一主题，视为同一议题
    for word in ("爽约", "计费", "收费", "导师", "批量", "贵重"):
        if word in left and word in right:
            return True
    if ("计费" in left and "收费" in right) or ("收费" in left and "计费" in right):
        return True
    return SequenceMatcher(None, left, right).ratio() >= 0.72


def _classify(text: str) -> str:
    stripped = text.strip()
    # 明显的会后闲聊/背景补充先排除，避免"没列入预算"被当成预算约束
    if stripped.startswith(("这个", "王老师", "李老师")) or "没列入预算" in stripped:
        return "background"
    # 问句优先：'能不能'里也含'能'，不能先按约束/要求判；
    # 但'是否'出现在陈述句中（如"再决定是否推广"）不应被当成问句。
    if stripped.endswith(("？", "?")) or re.match(r"^(是否|如何|能不能|要不要|谁|多少|哪些|怎么)", stripped):
        return "open_question"
    if re.search(r"\d+\s*周", text) or any(
        key in text for key in (
            "必须", "不得", "不允许", "不支持", "至少", "预算", "工期", "保留", "部署",
            "对接", "校内网", "访问", "审计", "合规", "只提供", "不提供", "晚上", "周末",
            "在线", "不能另建",
        )
    ):
        return "constraint"
    if "没有网络接口" in text:
        return "open_question"
    if any(
        key in text for key in (
            "目前", "现在", "学校设备处", "希望", "现有", "王老师", "李老师", "我们追问",
            "背景", "目标", "期末集中", "一天要批", "格式不统一", "有的没有", "觉得可以",
            "设备处提到", "以后可能",
        )
    ):
        return "background"
    if any(key in text for key in ("要", "应", "支持", "可以", "能", "允许", "提供", "导出", "统计", "审批", "签到", "预约", "录入", "维护", "填写", "通知", "释放", "导入")):
        return "requirement"
    return "open_question"


def _category(text: str) -> str:
    if any(key in text for key in ("预算", "成本", "费用")):
        return "cost"
    if any(key in text for key in ("工期", "周", "上线", "进度")):
        return "schedule"
    if any(key in text for key in ("部署", "对接", "网络", "浏览器", "接口", "CAS")):
        return "technical"
    if any(key in text for key in ("保留", "审计", "合规", "法律")):
        return "legal"
    if any(key in text for key in ("权限", "安全", "认证")):
        return "security"
    return "business"


def _blocking(text: str) -> bool:
    return any(key in text for key in ("冲突", "审批", "计费", "收费", "爽约", "权限", "保留", "批量", "统计", "口径", "优先", "导师", "判定"))


def _source(seg: dict) -> dict:
    return {"kind": "input_span", "seg_id": seg["seg_id"], "quote": seg["text"], "valid": True}


def _proposal_title(prop: dict) -> str:
    return str(prop.get("title") or prop.get("statement") or "")[:60]


TITLE_RULES = [
    ("批量导入", "台账批量导入"),
    ("设备台账", "设备台账维护"),
    ("空闲时段", "空闲时段查询与预约"),
    ("冲突", "预约冲突校验"),
    ("看板", "设备使用看板"),
    ("报表", "月度机时报表"),
    ("审批", "分级审批与通知"),
    ("签到", "签到签退与机时"),
    ("机时", "机时计算"),
    ("取消", "取消预约与释放时段"),
    ("CAS", "统一身份认证约束"),
    ("预算", "预算与工期约束"),
    ("保留", "数据保留与审计"),
    ("晚上", "非工作时间可用性"),
    ("小程序", "移动端范围"),
    ("老设备", "无网络设备登记"),
    ("贵重", "贵重设备判定"),
    ("大型设备", "贵重设备判定"),
    ("爽约", "爽约处理"),
    ("导师", "导师维度统计"),
    ("批量", "批量审批"),
    ("计费", "计费范围"),
    ("收费", "计费范围"),
    ("微信", "移动端范围"),
]


def _fallback_title(text: str) -> str:
    text = re.sub(r"^(系统应|用户应|系统要|申请人应)[：:，,\s]*", "", text.strip())
    text = text.strip("。；;，, ")
    first = re.split(r"[，,；;。]", text, maxsplit=1)[0]
    title = first if len(first) <= 22 else first[:21] + "…"
    return title or text[:22]


def _short_title(text: str) -> str:
    for keyword, title in TITLE_RULES:
        if keyword in text:
            return title
    return _fallback_title(text)


def _acceptance_for(text: str) -> list[str]:
    if "台账" in text and ("维护" in text or "增删改查" in text or "导入" in text):
        return ["新增或修改设备后可按编号查询到记录", "台账字段完整，批量导入可核对成功与失败条数"]
    if "冲突" in text:
        return ["同一设备同一时段第二次提交被拒绝", "拒绝时给出该设备最近的可选时段"]
    if "审批" in text:
        return ["普通设备走实验室管理员一级审批", "单价 10 万元以上设备走设备处二级审批", "审批结果通知申请人"]
    if "看板" in text:
        return ["看板可按设备、实验室、日期筛选", "使用率与机时统计口径可复现"]
    if "报表" in text:
        return ["可按月份导出机时报表", "导出字段与页面筛选条件一致"]
    if "签到" in text:
        return ["签到与签退时间可按预约查询", "未签退记录被标记为异常并可由管理员核对"]
    if "机时" in text:
        return ["机时按签到签退差值计算并可按月统计"]
    if "取消" in text:
        return ["取消后对应时段立即释放，其他用户可再次预约"]
    if "通知" in text:
        return ["审批通过后申请人收到通知，通知内容含设备与时段"]
    if "保留" in text or "审计" in text:
        return ["预约数据保留满 3 年，删除操作写入审计日志"]
    return ["对应功能可演示通过", "异常/边界情况有明确提示"]


def build_local_moderation(context, outputs, base_snapshot: dict, settings) -> dict:
    ops: list[dict] = []
    warnings: list[str] = []
    active = [item for item in base_snapshot.get("items", []) if item.get("status") == "active"]
    seen: dict[str, list[dict]] = {"requirement": [], "constraint": [], "open_question": [], "out_of_scope": [], "decision": []}
    for item in active:
        seen.setdefault(item["type"], []).append(
            {
                "id": item.get("id"),
                "title": _proposal_title(item),
                "statement": item.get("statement", ""),
                "sources": list(item.get("sources") or []),
            }
        )

    def find_similar(item_type: str, title: str, statement: str = "") -> dict | None:
        for existing in seen.get(item_type, []):
            if not _similar(existing["title"], title):
                continue
            if not statement or _similar_statement(existing["statement"], statement):
                return existing
        return None

    def add(item_type: str, title: str, statement: str, *, sources, acceptance=None, priority="should",
            origin="derived", category=None, blocking=False, why=None, options=None, assumption=None):
        def merge_sources(target: dict) -> bool:
            merged = list(target.get("sources") or [])
            known = {(s.get("seg_id"), s.get("quote")) for s in merged}
            changed = False
            for src in sources or []:
                key = (src.get("seg_id"), src.get("quote"))
                if key not in known:
                    merged.append(src)
                    changed = True
            if changed and target.get("id"):
                ops.append(
                    {
                        "op": "update_item",
                        "id": target["id"],
                        "patch": {"sources": merged},
                        "reason": "本地规则：把同主题原文段并入已有条目",
                    }
                )
            target["sources"] = merged
            return changed

        existing = find_similar(item_type, title, statement)
        if existing:
            if item_type in ("open_question", "constraint"):
                merge_sources(existing)
                return False
            if item_type == "requirement" and not _similar_statement(existing["statement"], statement):
                title = _fallback_title(statement)
            else:
                return False
        # 标题撞车（但内容不同）时：澄清项/约束并入已有条目，要求另起一个可区分的标题
        twin = existing or next(
            (rec for rec in seen.get(item_type, []) if _similar(rec["title"], title)),
            None,
        )
        if twin:
            if item_type in ("open_question", "constraint"):
                merge_sources(twin)
                return False
            title = _fallback_title(statement)
        candidate = title
        suffix = 2
        while any(_norm(rec["title"]) == _norm(candidate) for rec in seen.get(item_type, [])) and suffix < 30:
            candidate = f"{title}（{suffix}）"
            suffix += 1
        title = candidate
        item = {
            "type": item_type,
            "title": title[:60] or statement[:60],
            "statement": statement[:600],
            "priority": priority,
            "origin": origin,
            "sources": sources,
        }
        if acceptance:
            item["acceptance"] = acceptance
        if category:
            item["category"] = category
        if item_type == "open_question":
            item.update(
                {
                    "blocking": bool(blocking),
                    "why": why or "原文没有给出可直接验收的明确口径。",
                    "options": options or ["按原文最小实现", "暂不纳入首版"],
                    "suggested_assumption": assumption or "首版按原文最小实现，待用户确认后再扩展。",
                }
            )
        ops.append({"op": "add_item", "item": item, "reason": "本地规则综合"})
        seen.setdefault(item_type, []).append(
            {"id": None, "title": title, "statement": statement, "sources": list(sources or [])}
        )
        return True

    # 1) 先吸收 Agent 的真实提案（去重、补验收/来源）
    for output in outputs:
        for raw in output.get("proposed_items", []) or []:
            if not isinstance(raw, dict):
                continue
            item_type = normalize_type(raw.get("type"))
            if item_type not in seen:
                continue
            title = _proposal_title(raw)
            statement = str(raw.get("statement") or raw.get("question") or "").strip()
            if not title or not statement:
                continue
            similar = find_similar(item_type, title, statement)
            if similar:
                # 已有同义条目：对已有条目补验收/建议默认值，不重复新增
                target = next(
                    (i for i in active if i["type"] == item_type and _similar(i["title"], similar["title"])),
                    None,
                )
                patch = {}
                if target and not target.get("acceptance") and raw.get("acceptance"):
                    patch["acceptance"] = raw["acceptance"]
                if target and item_type == "open_question" and not target.get("suggested_assumption") and raw.get("assumption"):
                    patch["suggested_assumption"] = raw["assumption"]
                if target and patch:
                    ops.append(
                        {"op": "update_item", "id": target["id"], "patch": patch, "reason": "本地规则：补齐 Agent 提案中的字段"}
                    )
                continue
            sources = raw.get("sources") or []
            valid_sources, source_warnings = verify_sources(sources, context.source, None)
            if not any(s.get("valid") for s in valid_sources):
                warnings.extend(source_warnings)
                continue
            acceptance = raw.get("acceptance") or (_acceptance_for(statement) if item_type == "requirement" else None)
            add(
                item_type, title, statement,
                sources=valid_sources,
                acceptance=acceptance,
                priority=normalize_priority(raw.get("priority"), "must" if item_type == "constraint" else "should"),
                origin=str(raw.get("origin") or "derived"),
                category=raw.get("category") or (_category(statement) if item_type == "constraint" else None),
                blocking=bool(raw.get("blocking")),
                why=raw.get("why"),
                options=raw.get("options"),
                assumption=raw.get("assumption"),
            )

    # 2) 把原文里还没覆盖的句子按规则补齐，避免"讨论半天漏了原文"
    preview, _, _ = apply_ops(
        base_snapshot, ops, context.source, context.round_no, "v0.local-preview",
        transcript=[], by="local-moderator",
    )
    finalize_snapshot(preview, context.source)
    uncovered = preview.get("coverage", {}).get("uncovered", [])
    segments = {seg["seg_id"]: seg for seg in context.source["segments"]}
    counts = {"requirement": 0, "constraint": 0, "open_question": 0}
    for item in preview.get("items", []):
        if item.get("status") == "active" and item.get("created_round") == context.round_no:
            counts[item["type"]] = counts.get(item["type"], 0) + 1
    limits = {"requirement": 14, "constraint": 10, "open_question": 12}
    for seg_id in uncovered:
        seg = segments.get(seg_id)
        if not seg:
            continue
        text = seg["text"]
        kind = _classify(text)
        if kind == "background":
            ops.append({"op": "ignore_segment", "seg_id": seg_id, "reason": "背景/现状说明，不构成可验收要求"})
            continue
        if counts.get(kind, 0) >= limits.get(kind, 10):
            continue
        title = _short_title(text)
        if kind == "constraint":
            added = add(
                "constraint", title, text, sources=[_source(seg)],
                priority="must", origin="explicit", category=_category(text),
            )
        elif kind == "open_question":
            added = add(
                "open_question", title, text if text.endswith(("？", "?")) else text + "（请确认具体口径）",
                sources=[_source(seg)], priority="must", origin="explicit",
                blocking=_blocking(text), why="原文此处没有给出可直接验收的明确口径。",
            )
        else:
            added = add(
                "requirement", title, text, sources=[_source(seg)],
                acceptance=_acceptance_for(text),
                priority="must", origin="explicit",
            )
        if added:
            counts[kind] = counts.get(kind, 0) + 1

    # 2.2) 再扫一遍：即使已被某个 OQ 引用，明确的功能句仍应有一条 REQ
    preview, _, _ = apply_ops(
        base_snapshot, ops, context.source, context.round_no, "v0.local-preview-req",
        transcript=[], by="local-moderator",
    )
    finalize_snapshot(preview, context.source)
    req_refs = {
        src.get("seg_id")
        for item in preview.get("items", [])
        if item.get("type") == "requirement" and item.get("status") == "active"
        for src in item.get("sources", [])
        if src.get("kind") == "input_span" and src.get("seg_id")
    }
    for seg in context.source.get("segments", []):
        if seg.get("kind") == "heading" or seg["seg_id"] in req_refs:
            continue
        if counts.get("requirement", 0) >= limits["requirement"]:
            break
        if _classify(seg["text"]) != "requirement":
            continue
        title = _short_title(seg["text"])
        if add(
            "requirement", title, seg["text"], sources=[_source(seg)],
            acceptance=_acceptance_for(seg["text"]),
            priority="must", origin="explicit",
        ):
            counts["requirement"] = counts.get("requirement", 0) + 1

    # 2.5) 第二轮起做增量整理：合并同主题待澄清项、补齐验收要点，让版本演进可见
    preview, _, _ = apply_ops(
        base_snapshot, ops, context.source, context.round_no, "v0.local-preview-2",
        transcript=[], by="local-moderator",
    )
    finalize_snapshot(preview, context.source)
    if context.round_no >= 2 and not context.is_final:
        active_now = [item for item in preview.get("items", []) if item.get("status") == "active"]
        for req in [item for item in active_now if item["type"] == "requirement"]:
            if len(req.get("acceptance") or []) < 2:
                ops.append(
                    {
                        "op": "update_item",
                        "id": req["id"],
                        "patch": {
                            "acceptance": list(req.get("acceptance") or [])
                            + ["异常/边界情况有明确提示，可复现验证"]
                        },
                        "reason": "收敛轮：补齐可判定验收要点",
                    }
                )
        open_questions = [item for item in active_now if item["type"] == "open_question"]
        merged = set()
        for index, later in enumerate(open_questions):
            if later["id"] in merged:
                continue
            for earlier in open_questions[:index]:
                if earlier["id"] in merged:
                    continue
                if _similar(earlier["title"], later["title"]):
                    ops.append(
                        {
                            "op": "supersede_item",
                            "id": later["id"],
                            "superseded_by": earlier["id"],
                            "reason": "收敛轮：同主题待澄清项合并",
                        }
                    )
                    merged.add(later["id"])
                    break

    # 3) 定稿轮：把仍然阻塞、无人回答的问题落成默认假设
    preview, _, _ = apply_ops(
        base_snapshot, ops, context.source, context.round_no, "v0.local-preview-3",
        transcript=[], by="local-moderator",
    )
    finalize_snapshot(preview, context.source)
    if context.is_final:
        for item in preview.get("items", []):
            if (
                item.get("type") == "open_question"
                and item.get("status") == "active"
                and item.get("blocking")
                and not item.get("answer")
                and not item.get("assumption")
            ):
                assumption = item.get("suggested_assumption") or "首版按最小可行口径处理，待用户确认。"
                ops.append(
                    {
                        "op": "answer_question",
                        "id": item["id"],
                        "answer": assumption,
                        "answer_source": "assumption",
                        "assumption": assumption,
                        "reason": "定稿轮无人回答，采用建议默认值",
                    }
                )

    # 4) 估算最终指标
    preview, _, rejected = apply_ops(
        base_snapshot, ops, context.source, context.round_no, "v0.local-preview-4",
        transcript=[], by="local-moderator",
    )
    finalize_snapshot(preview, context.source)
    metrics = preview.get("metrics", {})
    blocking = int(metrics.get("blocking_open", 0))
    summary = (
        f"本地规则综合：新增/修订后共 {metrics.get('requirements', 0)} 条要求、"
        f"{metrics.get('constraints', 0)} 条约束、{metrics.get('open_questions', 0)} 个澄清项，"
        f"覆盖率 {metrics.get('coverage_rate', 0):.0%}，阻塞 {blocking}。"
    )
    if warnings:
        summary += f"（{len(warnings)} 条引用未通过校验被丢弃）"
    blocking_items = [
        item for item in preview.get("items", [])
        if item.get("type") == "open_question" and item.get("status") == "active" and item.get("blocking")
        and not item.get("answer") and not item.get("assumption")
    ]
    project_summary = base_snapshot.get("project", {}).get("summary") or _project_summary(context.source)
    converged = bool(context.is_final and blocking == 0)
    return {
        "summary": summary,
        "project_summary": project_summary,
        "ops": ops,
        "next_focus": [item["id"] for item in blocking_items[:3]] or ["补齐验收要点", "确认范围外事项"],
        "converged": converged,
        "convergence_reason": (
            "本地规则：阻塞项已全部回答/假设" if converged else f"本地规则：仍有 {blocking} 个阻塞项"
        ),
        "mode": "local-rule",
        "rejected_preview": rejected,
    }


def _project_summary(source: dict) -> str:
    lines = [
        seg["text"] for seg in source.get("segments", [])
        if seg.get("kind") != "heading" and len(seg.get("text", "")) >= 8
    ][:2]
    return "".join(lines)[:240] or "由原始需求整理的系统。"
