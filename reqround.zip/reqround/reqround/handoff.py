from __future__ import annotations

import json
import urllib.error
import urllib.request
from typing import Any

from .config import now_iso
from .snapshot import by_type, build_handoff_requirement_brief

PRIORITY_MAP = {"must": "high", "should": "medium", "could": "low", "wont": "low"}


def _source_rows(item: dict) -> list[dict]:
    rows = []
    for src in item.get("sources", []):
        if not src.get("valid"):
            continue
        if src.get("kind") == "discussion":
            rows.append(
                {
                    "kind": "discussion",
                    "round": src.get("round"),
                    "agent": src.get("agent"),
                    "quote": src.get("quote"),
                }
            )
        else:
            rows.append(
                {
                    "kind": "input_span",
                    "seg_id": src.get("seg_id"),
                    "quote": src.get("quote"),
                    "start": src.get("start"),
                    "end": src.get("end"),
                }
            )
    return rows


def _task_rows(snapshot: dict) -> list[dict]:
    requirements = sorted(
        by_type(snapshot, "requirement"),
        key=lambda i: ({"must": 0, "should": 1, "could": 2, "wont": 3}.get(i.get("priority"), 2), i["id"]),
    )
    constraints = by_type(snapshot, "constraint")
    tasks: list[dict] = []
    for index, item in enumerate(requirements, 1):
        tasks.append(
            {
                "task_id": f"T{index}",
                "name": f"{item['title']}（{item['id']}）",
                "description": item["statement"],
                "deliverable": f"{item['title']}功能实现",
                "acceptance_items": list(item.get("acceptance") or ["按需求快照中的陈述完成并可演示"]),
                "suggested_role": "ai",
                "priority": PRIORITY_MAP.get(item.get("priority"), "medium"),
                "source_req_ids": [item["id"]],
                "source_snapshot": snapshot.get("version"),
                "source_citations": _source_rows(item),
            }
        )
    next_index = len(tasks) + 1
    if constraints:
        tasks.append(
            {
                "task_id": f"T{next_index}",
                "name": "非功能约束与集成核验（CON）",
                "description": "验证需求快照中的技术、合规、质量、工期等约束确实被满足。",
                "deliverable": "约束核验记录",
                "acceptance_items": [f"{c['id']}：{c['statement']}" for c in constraints[:8]],
                "suggested_role": "human",
                "priority": "high",
                "source_req_ids": [c["id"] for c in constraints],
                "source_snapshot": snapshot.get("version"),
                "source_citations": [],
            }
        )
        next_index += 1
    acceptance = [f"{req['id']}：{req['statement']}" for req in requirements if req.get("priority") == "must"]
    tasks.append(
        {
            "task_id": f"T{next_index}",
            "name": "需求验收与范围签收（REQ）",
            "description": "按快照 v1.0 的验收要点逐条验收，并确认未决项的处理方式。",
            "deliverable": "需求验收记录",
            "acceptance_items": acceptance[:8] or ["Must 级需求全部通过验收"],
            "suggested_role": "human",
            "priority": "high",
            "source_req_ids": [req["id"] for req in requirements],
            "source_snapshot": snapshot.get("version"),
            "source_citations": [],
        }
    )
    return tasks


def build_handoff(snapshot: dict, source: dict, run: dict | None = None) -> dict:
    project = snapshot.get("project", {})
    requirements = by_type(snapshot, "requirement")
    constraints = by_type(snapshot, "constraint")
    questions = by_type(snapshot, "open_question")
    tasks = _task_rows(snapshot)
    open_blocking = [q for q in questions if q.get("blocking") and not q.get("answer") and not q.get("assumption")]
    assumptions = [
        {"id": q["id"], "question": q["statement"], "assumption": q.get("assumption")}
        for q in questions
        if q.get("assumption") and not q.get("answer")
    ]
    return {
        "schema": "reqround.handoff.v1",
        "generated_at": now_iso(),
        "source_run": {
            "run_id": (run or {}).get("run_id"),
            "snapshot_id": snapshot.get("snapshot_id"),
            "snapshot_version": snapshot.get("version"),
            "original_sha256": source.get("sha256"),
            "original_length": source.get("length"),
        },
        "project": {
            "project_id": project.get("project_id"),
            "title": project.get("title"),
            "summary": project.get("summary"),
            "domain": project.get("domain"),
        },
        "requirement_brief": build_handoff_requirement_brief(snapshot),
        "requirements": [
            {
                "id": item["id"],
                "title": item["title"],
                "statement": item["statement"],
                "priority": item.get("priority"),
                "acceptance": item.get("acceptance", []),
                "sources": _source_rows(item),
                "revision": item.get("revision", 1),
            }
            for item in requirements
        ],
        "constraints": [
            {
                "id": item["id"],
                "title": item["title"],
                "statement": item["statement"],
                "category": item.get("category"),
                "priority": item.get("priority"),
                "sources": _source_rows(item),
            }
            for item in constraints
        ],
        "open_questions": [
            {
                "id": item["id"],
                "question": item["statement"],
                "why": item.get("why"),
                "blocking": item.get("blocking"),
                "status": "answered" if item.get("answer") else ("assumed" if item.get("assumption") else "open"),
                "answer": item.get("answer"),
                "suggested_assumption": item.get("suggested_assumption"),
                "assumption": item.get("assumption"),
                "related": item.get("related", []),
            }
            for item in questions
        ],
        "open_blocking": [q["id"] for q in open_blocking],
        "assumptions": assumptions,
        "tasks": tasks,
        "metrics": snapshot.get("metrics", {}),
        "quality": snapshot.get("quality", {}),
        "note": (
            "下游可直接使用 requirement_brief 调 PM 拆解；也可用 tasks 直接 POST 到编排器。"
            "tasks 中的 source_req_ids 是本契约的追溯外键；若下游丢弃额外字段，可用任务名中的 REQ 编号回查快照。"
        ),
    }


def to_orchestrator_payload(handoff: dict) -> dict:
    """生成与 IdeaFlow 编排器 normalize_tasks 完全兼容的 6 字段任务包。"""
    tasks = []
    for task in handoff.get("tasks", []):
        tasks.append(
            {
                "task_id": task["task_id"],
                "name": task["name"],
                "deliverable": task["deliverable"],
                "acceptance_items": list(task.get("acceptance_items") or []),
                "suggested_role": task.get("suggested_role", "ai"),
                "priority": task.get("priority", "medium"),
            }
        )
    return {
        "schema_version": "1.1",
        "spec_id": handoff.get("source_run", {}).get("snapshot_id") or "SPEC-REQROUND",
        "spec_version": handoff.get("source_run", {}).get("snapshot_version") or "v1.0",
        "list_version": "v1.0",
        "review_status": "approved",
        "generated_by": "reqround",
        "created_at": handoff.get("generated_at"),
        "tasks": tasks,
    }


def push_to_orchestrator(
    url: str,
    handoff: dict,
    *,
    payload: dict | None = None,
    timeout: float = 300.0,
) -> dict:
    target = url.rstrip("/") + "/api/start"
    body = json.dumps(payload or to_orchestrator_payload(handoff), ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(
        target,
        data=body,
        method="POST",
        headers={"Content-Type": "application/json; charset=utf-8"},
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            return {"ok": True, "status": response.status, "data": json.loads(response.read().decode("utf-8"))}
    except urllib.error.HTTPError as exc:
        detail = exc.read().decode("utf-8", "replace")
        return {"ok": False, "status": exc.code, "error": detail[:1000]}
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        return {"ok": False, "status": 0, "error": str(exc)}


def handoff_summary(handoff: dict) -> dict:
    return {
        "schema": handoff.get("schema"),
        "snapshot_version": handoff.get("source_run", {}).get("snapshot_version"),
        "requirements": len(handoff.get("requirements", [])),
        "constraints": len(handoff.get("constraints", [])),
        "tasks": len(handoff.get("tasks", [])),
        "open_blocking": handoff.get("open_blocking", []),
        "assumptions": len(handoff.get("assumptions", [])),
    }


def save_handoff(path, handoff: dict, payload: dict | None = None) -> None:
    path.write_text(json.dumps(handoff, ensure_ascii=False, indent=2), encoding="utf-8")
    if payload is not None:
        path.with_name("handoff_orchestrator.json").write_text(
            json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
        )


__all__ = [
    "build_handoff",
    "to_orchestrator_payload",
    "push_to_orchestrator",
    "handoff_summary",
    "save_handoff",
]
