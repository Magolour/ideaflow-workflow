#!/usr/bin/env python3
"""把需求快照 JSON 渲染成可交付的 Word 需求文档。

用法：
    py -3 tools/export_docx.py --run R-20261120-143847-e3e7 \
        --out "docs/需求快照_高校实验室设备预约管理系统_v1.0.docx"
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

ROOT = Path(__file__).resolve().parent.parent

PRIORITY = {"must": "Must", "should": "Should", "could": "Could", "wont": "Won't"}
TYPE_LABEL = {
    "requirement": "明确要求",
    "constraint": "约束",
    "open_question": "待澄清项",
    "out_of_scope": "范围外",
    "decision": "关键决策",
}
CATEGORY = {
    "technical": "技术", "business": "业务", "legal": "合规", "quality": "质量",
    "schedule": "工期", "cost": "成本", "security": "安全", "other": "其他",
}
ORIGIN = {"explicit": "原文明确", "derived": "讨论推导", "assumed": "默认假设"}
MODE = {"diverge": "独立发散", "challenge": "交叉质询", "converge": "聚焦收敛", "finalize": "定稿签署"}

INK = RGBColor(0x20, 0x24, 0x1F)
ACCENT = RGBColor(0xAB, 0x4F, 0x2C)
MUTED = RGBColor(0x73, 0x7A, 0x70)


def set_east_asia(run, font: str = "微软雅黑") -> None:
    run.font.name = font
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), font)


def set_style_font(doc, name: str, size: float, bold: bool = False, color=INK, font: str = "微软雅黑") -> None:
    style = doc.styles[name]
    style.font.name = font
    style.font.size = Pt(size)
    style.font.bold = bold
    style.font.color.rgb = color
    style._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), font)


def shade(cell, color: str = "F2EDE2") -> None:
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = OxmlElement("w:shd")
    shd.set(qn("w:fill"), color)
    tc_pr.append(shd)


def repeat_header(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    tbl_header = OxmlElement("w:tblHeader")
    tbl_header.set(qn("w:val"), "true")
    tr_pr.append(tbl_header)


def no_split(row) -> None:
    tr_pr = row._tr.get_or_add_trPr()
    cant = OxmlElement("w:cantSplit")
    cant.set(qn("w:val"), "true")
    tr_pr.append(cant)


def cell_text(cell, text: str, *, bold: bool = False, size: float = 9, color=INK) -> None:
    cell.text = ""
    paragraph = cell.paragraphs[0]
    paragraph.paragraph_format.space_after = Pt(0)
    run = paragraph.add_run("" if text is None else str(text))
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    set_east_asia(run)


def add_table(doc, headers: list[str], rows: list[list[str]], widths: list[float] | None = None, size: float = 9):
    table = doc.add_table(rows=1, cols=len(headers))
    table.style = "Table Grid"
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False
    for index, header in enumerate(headers):
        cell = table.rows[0].cells[index]
        cell_text(cell, header, bold=True, size=size)
        shade(cell)
    repeat_header(table.rows[0])
    for row in rows:
        table_row = table.add_row()
        no_split(table_row)
        cells = table_row.cells
        for index, value in enumerate(row):
            cell_text(cells[index], value, size=size)
    if widths:
        for row in table.rows:
            for index, width in enumerate(widths):
                row.cells[index].width = Cm(width)
    return table


def para(doc, text: str = "", *, size: float = 10.5, bold: bool = False, color=INK, space_after: float = 4,
         align=None, style: str | None = None):
    paragraph = doc.add_paragraph(style=style) if style else doc.add_paragraph()
    paragraph.paragraph_format.space_after = Pt(space_after)
    paragraph.paragraph_format.line_spacing = 1.35
    if align is not None:
        paragraph.alignment = align
    run = paragraph.add_run(str(text or ""))
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.color.rgb = color
    set_east_asia(run)
    return paragraph


def kv_line(doc, label: str, value: str, *, size: float = 9.5) -> None:
    paragraph = doc.add_paragraph()
    paragraph.paragraph_format.space_after = Pt(2)
    paragraph.paragraph_format.line_spacing = 1.3
    left = paragraph.add_run(f"{label}：")
    left.font.bold = True
    left.font.size = Pt(size)
    left.font.color.rgb = MUTED
    set_east_asia(left)
    right = paragraph.add_run("—" if value is None or value == "" else str(value))
    right.font.size = Pt(size)
    right.font.color.rgb = INK
    set_east_asia(right)


def source_text(sources: list[dict], limit: int = 80) -> str:
    chunks = []
    for source in sources or []:
        quote = str(source.get("quote") or "").replace("\n", " ")
        if len(quote) > limit:
            quote = quote[:limit] + "…"
        if source.get("kind") == "discussion":
            chunks.append(f"第{source.get('round')}轮·{source.get('agent')}：“{quote}”")
        else:
            chunks.append(f"{source.get('seg_id')}：“{quote}”")
    return "；".join(chunks) or "—"


def load_snapshot(run_id: str, runs_dir: Path) -> tuple[dict, dict, dict]:
    run_dir = runs_dir / run_id
    snapshot = json.loads((run_dir / "snapshots" / "latest.json").read_text(encoding="utf-8"))
    source = json.loads((run_dir / "source.json").read_text(encoding="utf-8"))
    run = json.loads((run_dir / "run.json").read_text(encoding="utf-8"))
    return snapshot, source, run


def build_document(snapshot: dict, source: dict, run: dict) -> Document:
    doc = Document()
    section = doc.sections[0]
    section.page_width = Cm(21)
    section.page_height = Cm(29.7)
    section.top_margin = Cm(2.0)
    section.bottom_margin = Cm(2.0)
    section.left_margin = Cm(2.2)
    section.right_margin = Cm(2.2)

    set_style_font(doc, "Normal", 10.5, font="宋体")
    for level, size in ((1, 16), (2, 13), (3, 11.5)):
        try:
            set_style_font(doc, f"Heading {level}", size, bold=True, color=INK, font="微软雅黑")
        except KeyError:
            pass

    project = snapshot.get("project", {})
    metrics = snapshot.get("metrics", {})
    title = project.get("title") or "未命名项目"
    version = snapshot.get("version", "v0.0")

    # 封面
    para(doc, "需 求 快 照", size=11, bold=True, color=ACCENT, space_after=6, align=WD_ALIGN_PARAGRAPH.CENTER)
    para(doc, title, size=22, bold=True, space_after=6, align=WD_ALIGN_PARAGRAPH.CENTER)
    para(doc, f"{version} ｜ 多 Agent 圆桌讨论与版本化整理", size=11, color=MUTED, space_after=18,
         align=WD_ALIGN_PARAGRAPH.CENTER)

    meta_rows = [
        ["项目编号", project.get("project_id", "—"), "快照编号", snapshot.get("snapshot_id", "—")],
        ["版本", version, "状态", {"approved": "已批准", "approved_with_open_questions": "已批准（含未决项）"}.get(snapshot.get("status"), snapshot.get("status"))],
        ["轮次", f"{snapshot.get('round')} / {snapshot.get('max_rounds')}", "父版本", snapshot.get("parent_version") or "—"],
        ["原文指纹", f"{source.get('sha256_short', '')}（{source.get('segment_count')} 段）", "生成时间", snapshot.get("updated_at", "—")],
        ["批准人", (snapshot.get("approval") or {}).get("by", "—"), "批准时间", snapshot.get("approved_at") or (snapshot.get("approval") or {}).get("at") or "—"],
    ]
    table = add_table(doc, ["字段", "值", "字段", "值"], meta_rows, widths=[2.6, 5.6, 2.6, 5.4], size=9)
    for row in table.rows:
        for cell in row.cells:
            cell.paragraphs[0].paragraph_format.space_after = Pt(0)
    doc.add_paragraph()

    add_table(
        doc,
        ["指标", "数值", "指标", "数值"],
        [
            ["明确要求", metrics.get("requirements", 0), "约束", metrics.get("constraints", 0)],
            ["待澄清项", metrics.get("open_questions", 0), "已回答", metrics.get("answered", 0)],
            ["原文覆盖率", f"{metrics.get('coverage_rate', 0):.0%}", "引用有效率", f"{metrics.get('citation_rate', 0):.0%}"],
            ["验收完整率", f"{metrics.get('acceptance_rate', 0):.0%}", "阻塞项", metrics.get("blocking_open", 0)],
        ],
        widths=[3.2, 5.0, 3.2, 4.8],
        size=9,
    )

    # 修订记录
    doc.add_heading("修订记录", level=1)
    rows = []
    for row in snapshot.get("round_summaries", []):
        rows.append(
            [
                row.get("version", ""),
                MODE.get(row.get("mode"), row.get("mode", "")),
                f"第 {row.get('round')} 轮",
                row.get("summary", ""),
            ]
        )
    rows.append([version, "人工批准", "—", (snapshot.get("approval") or {}).get("note") or "冻结为 v1.0 基线"])
    add_table(doc, ["版本", "阶段", "轮次", "说明"], rows, widths=[2.2, 3.0, 2.0, 9.0], size=9)

    # 1 概述
    doc.add_heading("1. 项目概述", level=1)
    para(doc, project.get("summary") or "（未形成项目摘要）")
    para(
        doc,
        "本快照由 ReqRound 需求圆桌生成：4 位不同立场的 Agent 先独立解读，再交叉质询、聚焦收敛，"
        "主持人把每轮结论落成带编号、带来源引用的版本。每条要求都保留原文引用；修改以新版本落盘，旧版本只读。",
        color=MUTED,
        size=9.5,
    )

    items = [item for item in snapshot.get("items", []) if item.get("status") == "active"]
    requirements = [item for item in items if item["type"] == "requirement"]
    constraints = [item for item in items if item["type"] == "constraint"]
    questions = [item for item in items if item["type"] == "open_question"]
    out_of_scope = [item for item in items if item["type"] == "out_of_scope"]
    decisions = [item for item in items if item["type"] == "decision"]

    # 2 要求
    doc.add_heading("2. 明确要求（REQ）", level=1)
    if requirements:
        rows = []
        for item in requirements:
            rows.append(
                [
                    item["id"],
                    item["title"],
                    PRIORITY.get(item.get("priority"), item.get("priority", "")),
                    item["statement"],
                ]
            )
        add_table(doc, ["编号", "标题", "优先级", "要求陈述"], rows,
                  widths=[1.8, 4.2, 1.6, 6.4], size=9)

        for item in requirements:
            doc.add_heading(f"{item['id']}　{item['title']}", level=2)
            kv_line(doc, "陈述", item["statement"])
            kv_line(doc, "优先级", PRIORITY.get(item.get("priority"), item.get("priority", "")))
            kv_line(doc, "来源类型", ORIGIN.get(item.get("origin"), item.get("origin", "")))
            kv_line(doc, "修订", f"rev.{item.get('revision', 1)}")
            kv_line(doc, "来源引用", source_text(item.get("sources"), 120))
            if item.get("acceptance"):
                kv_line(doc, "验收要点", "；".join(item["acceptance"]))
            if item.get("related"):
                kv_line(doc, "关联", "、".join(item["related"]))
    else:
        para(doc, "本版尚无明确要求。", color=MUTED)

    # 3 约束
    doc.add_heading("3. 约束（CON）", level=1)
    if constraints:
        rows = []
        for item in constraints:
            rows.append(
                [
                    item["id"],
                    item["statement"],
                    CATEGORY.get(item.get("category"), item.get("category") or "其他"),
                    ORIGIN.get(item.get("origin"), item.get("origin", "")),
                    source_text(item.get("sources"), 50),
                ]
            )
        add_table(doc, ["编号", "约束", "类别", "来源类型", "依据"], rows,
                  widths=[1.5, 7.2, 2.0, 2.3, 5.0], size=8.5)
    else:
        para(doc, "本版尚无约束。", color=MUTED)

    # 4 待澄清项
    doc.add_heading("4. 待澄清项（OQ）", level=1)
    if questions:
        rows = []
        for item in questions:
            status = "已回答" if item.get("answer") else ("默认假设" if item.get("assumption") else "待澄清")
            rows.append(
                [
                    item["id"],
                    item["statement"],
                    "是" if item.get("blocking") else "否",
                    status,
                    item.get("answer") or item.get("assumption") or "—",
                ]
            )
        add_table(doc, ["编号", "问题", "阻塞", "状态", "回答 / 默认假设"], rows,
                  widths=[1.5, 7.0, 1.4, 2.0, 5.8], size=8.5)
        for item in questions:
            doc.add_heading(f"{item['id']}　{item['title']}", level=2)
            kv_line(doc, "问题", item["statement"])
            kv_line(doc, "为什么重要", item.get("why") or "—")
            kv_line(doc, "是否阻塞", "是" if item.get("blocking") else "否")
            if item.get("options"):
                kv_line(doc, "可选项", "；".join(item["options"]))
            if item.get("answer"):
                kv_line(doc, "回答", f"{item['answer']}（来源：{item.get('answer_source') or '—'}）")
            elif item.get("assumption"):
                kv_line(doc, "默认假设", f"{item['assumption']}（未经用户确认）")
            elif item.get("suggested_assumption"):
                kv_line(doc, "建议默认值（未采纳）", item["suggested_assumption"])
            kv_line(doc, "来源引用", source_text(item.get("sources"), 120))
    else:
        para(doc, "本版没有待澄清项。", color=MUTED)

    # 5 范围外 / 决策
    doc.add_heading("5. 范围外与关键决策", level=1)
    if out_of_scope:
        para(doc, "范围外（OOS）", bold=True, size=10.5)
        for item in out_of_scope:
            kv_line(doc, item["id"], f"{item['statement']}（{source_text(item.get('sources'), 60)}）")
    if decisions:
        para(doc, "关键决策（DEC）", bold=True, size=10.5)
        for item in decisions:
            kv_line(doc, item["id"], item["statement"])
    if not out_of_scope and not decisions:
        para(doc, "本版没有显式范围外事项或单独立项的决策。", color=MUTED)

    # 6 追踪矩阵
    doc.add_heading("6. 需求追踪矩阵", level=1)
    para(doc, "每个原文段落在快照中的去向；未覆盖段会被质量门禁拦截。", color=MUTED, size=9)
    mapping = snapshot.get("coverage", {}).get("mapping", {})
    ignored = {entry.get("seg_id"): entry.get("reason", "") for entry in snapshot.get("ignored_segments", [])}
    rows = []
    for seg in source.get("segments", []):
        refs = mapping.get(seg["seg_id"], [])
        if seg.get("kind") == "heading":
            state = "结构标题"
        elif refs:
            state = "已覆盖"
        elif seg["seg_id"] in ignored:
            state = "已说明忽略"
        else:
            state = "未覆盖"
        rows.append([seg["seg_id"], seg["text"][:90], "、".join(refs) or "—", state])
    add_table(doc, ["原文段", "原文摘要", "被哪些条目引用", "状态"], rows,
              widths=[2.0, 9.5, 4.0, 2.5], size=8)

    # 7 质量门禁
    doc.add_heading("7. 质量门禁", level=1)
    gates = snapshot.get("quality", {}).get("gates", {})
    gate_labels = {
        "schema_valid": "结构合法",
        "coverage": "原文覆盖 ≥ 90%",
        "citation": "引用有效 ≥ 90%",
        "acceptance": "要求均有验收",
        "requirement_sourced": "要求均有原文来源",
        "no_duplicates": "无重复条目",
        "blocking_resolved": "阻塞项已处理",
    }
    rows = [[gate_labels.get(key, key), "通过" if value else "未通过"] for key, value in gates.items()]
    add_table(doc, ["门禁", "结果"], rows, widths=[8.0, 4.0], size=9)
    issues = snapshot.get("quality", {}).get("issues", [])
    if issues:
        para(doc, "待修复问题", bold=True, size=10)
        for issue in issues:
            para(doc, f"· {issue}", size=9.5)

    # 8 讨论轮次
    doc.add_heading("8. 讨论轮次摘要", level=1)
    rows = []
    for row in snapshot.get("round_summaries", []):
        agents = row.get("agents", {})
        ok = len([a for a in agents.values() if a.get("status") == "ok"])
        failed = len([a for a in agents.values() if a.get("status") != "ok"])
        rows.append(
            [
                str(row.get("round")),
                MODE.get(row.get("mode"), row.get("mode", "")),
                row.get("version", ""),
                f"{ok} 成功" + (f" / {failed} 失败" if failed else ""),
                row.get("summary", ""),
                str(row.get("blocking_open", 0)),
            ]
        )
    add_table(doc, ["轮次", "模式", "版本", "发言", "结论", "阻塞"], rows,
              widths=[1.2, 2.4, 1.6, 2.6, 9.2, 1.2], size=8.5)

    # 附录
    doc.add_heading("附录 A　原始需求（分段存档）", level=1)
    para(
        doc,
        f"原文 {source.get('length')} 字符，SHA-256 前 12 位 {source.get('sha256_short')}。"
        "以下分段编号与正文引用一一对应。",
        color=MUTED,
        size=9,
    )
    for seg in source.get("segments", []):
        para(doc, f"{seg['seg_id']}　{seg['text']}", size=9, space_after=2)

    para(doc, "", space_after=6)
    para(doc, "本文件由 ReqRound 需求圆桌从快照 JSON 渲染生成；正文与快照不一致时，以快照 JSON 为准。",
         size=8.5, color=MUTED, align=WD_ALIGN_PARAGRAPH.CENTER)
    return doc


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    parser.add_argument("--runs", default=str(ROOT / "runs"))
    parser.add_argument("--out", required=True)
    args = parser.parse_args()
    snapshot, source, run = load_snapshot(args.run, Path(args.runs))
    document = build_document(snapshot, source, run)
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    document.save(out)
    print(out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
