#!/usr/bin/env python3
"""把一次真实运行的 Agent 发言导出成可回放的 JSON。

用途：模型额度受限/网络不稳定时，用真实发言 + 本地规则综合稳定演示完整流程。
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from reqround.store import RunStore  # noqa: E402


def mode_for(round_no: int, max_rounds: int) -> str:
    if round_no <= 1:
        return "diverge"
    if round_no >= max_rounds:
        return "finalize"
    if round_no == max_rounds - 1:
        return "converge"
    return "challenge"


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--runs", default=str(ROOT / "runs"))
    args = parser.parse_args()
    store = RunStore(Path(args.runs))
    run = store.load(args.run)
    max_rounds = int(run.get("max_rounds", 4))
    entries = {}
    for record in store.transcript(args.run):
        if record.get("kind") != "discussant" or record.get("status") != "ok":
            continue
        round_no = int(record.get("round", 0))
        mode = mode_for(round_no, max_rounds)
        key = f"{record['agent']}:{round_no}:{mode}"
        entries[key] = record.get("response") or {}
    payload = {
        "schema": "reqround.replay.v1",
        "source_run": args.run,
        "title": run.get("title"),
        "entries": entries,
    }
    out = Path(args.out)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"wrote {out} ({len(entries)} entries)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
