#!/usr/bin/env python3
"""ReqRound（需求圆桌）命令行入口。

用法：
    py -3 run.py run --input cases/lab_booking.md --title 实验室设备预约系统
    py -3 run.py run --input cases/lab_booking.md --auto-assume --max-rounds 4
    py -3 run.py serve --port 8770
    py -3 run.py list
    py -3 run.py show --run R-...
    py -3 run.py approve --run R-... --accept-open
"""

from __future__ import annotations

import argparse
import json
import sys
import threading
import time
from dataclasses import replace
from pathlib import Path

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from reqround.config import Settings  # noqa: E402
from reqround.handoff import (  # noqa: E402
    build_handoff,
    handoff_summary,
    save_handoff,
    to_orchestrator_payload,
)
from reqround.llm import MockClient, ReplayClient  # noqa: E402
from reqround.orchestrator import Orchestrator  # noqa: E402
from reqround.snapshot import render_markdown  # noqa: E402
from reqround.store import RunStore  # noqa: E402


def _utf8() -> None:
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except Exception:
            pass


def _settings(args) -> Settings:
    overrides = {}
    if getattr(args, "runs", None):
        overrides["runs_dir"] = Path(args.runs)
    if getattr(args, "max_rounds", None):
        overrides["max_rounds"] = int(args.max_rounds)
    if getattr(args, "local", False):
        overrides["local_agents"] = True
        overrides["local_moderator"] = True
    if getattr(args, "local_moderator", False):
        overrides["local_moderator"] = True
    return Settings.from_env(**overrides)


def _store(settings: Settings) -> RunStore:
    return RunStore(settings.runs_dir)


def _format_event(event: dict) -> str | None:
    kind = event.get("type")
    ts = str(event.get("ts", ""))[11:19]
    if kind == "run_started":
        return f"[{ts}] 运行开始：{event.get('title')}（模型 {event.get('model')}）"
    if kind == "round_started":
        return f"[{ts}] ==== 第 {event.get('round')} 轮 · {event.get('mode_label')} ===="
    if kind == "agent_started":
        return f"[{ts}]   {event.get('name')} 正在阅读与思考 …"
    if kind == "agent_done":
        vote = f" vote={event.get('vote')}" if event.get("vote") else ""
        return (
            f"[{ts}]   {event.get('name')}：{event.get('findings')} 条发现 / {event.get('items')} 条提案"
            f"（{round(int(event.get('duration_ms') or 0) / 1000, 1)}s）{vote}"
        )
    if kind == "agent_failed":
        return f"[{ts}]   ✗ {event.get('name')} 失败：{event.get('error')}"
    if kind == "moderator_started":
        return f"[{ts}]   主持人在综合 {event.get('agents_ok')} 份发言 …"
    if kind == "moderator_failed":
        return f"[{ts}]   ✗ 主持人失败：{event.get('error')}"
    if kind == "snapshot_published":
        digest = event.get("digest", {})
        diff = event.get("diff", {})
        return (
            f"[{ts}]   → 发布 {event.get('version')}：REQ {digest.get('requirements')} / "
            f"CON {digest.get('constraints')} / OQ {digest.get('open_questions')}，"
            f"阻塞 {digest.get('blocking_open')}，覆盖率 {digest.get('coverage_rate')}，"
            f"变化 +{diff.get('added', 0)} ~{diff.get('modified', 0)}"
        )
    if kind == "convergence_check":
        flag = "已收敛" if event.get("converged") else "未收敛"
        reasons = "；".join(event.get("reasons") or [])
        return f"[{ts}]   收敛检查：{flag}" + (f"（{reasons}）" if reasons else "")
    if kind == "run_paused":
        return f"[{ts}] ⏸ 运行暂停：{event.get('reason')}"
    if kind == "clarification_requested":
        ids = "、".join(q.get("id", "") for q in (event.get("questions") or []))
        return f"[{ts}]   待人工澄清：{ids}"
    if kind == "run_awaiting_approval":
        return f"[{ts}] √ 快照 {event.get('version')} 等待人工批准（阻塞 {event.get('blocking_open')}）"
    if kind == "run_failed":
        return f"[{ts}] ✗ 运行失败：{event.get('error')}"
    if kind == "run_approved":
        return f"[{ts}] ★ 已批准 {event.get('version')}（by {event.get('by')}）"
    if kind == "clarification_received":
        return f"[{ts}]   收到人工澄清 {event.get('oq_id')}：{str(event.get('answer'))[:40]}"
    return None


def _follow(store: RunStore, run_id: str, stop: threading.Event, quiet: bool) -> None:
    since = 0
    while not stop.is_set():
        try:
            events = store.read_events(run_id, since=since, limit=300)
        except Exception:
            break
        for event in events:
            since = int(event.get("seq", since))
            line = _format_event(event)
            if line and not quiet:
                print(line, flush=True)
        stop.wait(0.7)


def _print_state(state: dict) -> None:
    run = state["run"]
    latest = state.get("latest", {})
    print("")
    print("=" * 64)
    print(f"运行 {run['run_id']} · {run['title']}")
    print(f"状态：{run['status']}　轮次：{run.get('round')} / {run.get('max_rounds')}　最新版本：{run.get('latest_version')}")
    if latest:
        print(
            f"快照：REQ {latest.get('requirements')} / CON {latest.get('constraints')} / "
            f"OQ {latest.get('open_questions')}　阻塞 {latest.get('blocking_open')}　"
            f"覆盖率 {latest.get('coverage_rate')}　质量门禁 {'通过' if latest.get('quality_passed') else '未通过'}"
        )
    open_questions = state.get("open_questions") or []
    if open_questions:
        print("\n待澄清项：")
        for item in open_questions:
            flag = "阻塞" if item.get("blocking") else "一般"
            print(f"  [{item['id']}]（{flag}）{item['question']}")
            if item.get("options"):
                print(f"        选项：{' / '.join(item['options'])}")
    print(f"\n产物目录：{state['run'].get('run_dir', '') or ''}")
    print("=" * 64)


def _state_with_dir(store: RunStore, engine: Orchestrator) -> dict:
    state = engine.state()
    state["run"]["run_dir"] = str(store.path(engine.run_id))
    return state


def cmd_run(args) -> int:
    settings = _settings(args)
    store = _store(settings)
    if args.input:
        text = Path(args.input).read_text(encoding="utf-8")
        default_title = Path(args.input).stem
    elif args.text:
        text = args.text
        default_title = "需求圆桌"
    else:
        print("需要 --input 文件或 --text 文本", file=sys.stderr)
        return 2
    client = None
    if args.mock:
        client = MockClient()
    elif args.replay:
        client = ReplayClient(args.replay)
    engine = Orchestrator.create(
        store,
        settings,
        text,
        title=args.title or default_title,
        client=client,
        max_rounds=args.max_rounds,
        auto_assume=args.auto_assume,
    )
    print(f"创建运行 {engine.run_id}：{args.title or default_title}")
    stop = threading.Event()
    follower = threading.Thread(target=_follow, args=(store, engine.run_id, stop, args.quiet), daemon=True)
    follower.start()
    try:
        engine.run_until_pause()
    finally:
        stop.set()
        follower.join(timeout=2)
    state = _state_with_dir(store, engine)
    _print_state(state)
    print(f"\n查看网页：http://127.0.0.1:8770（先运行 py -3 run.py serve）")
    if state["run"]["status"] == "paused":
        print("下一步：在网页澄清台回答，或执行")
        print(f"  py -3 run.py answer --run {engine.run_id} --oq OQ-001 --answer \"...\"")
        print(f"  py -3 run.py continue --run {engine.run_id}")
    if args.json:
        print(json.dumps(state, ensure_ascii=False, indent=2))
    return 0 if state["run"]["status"] not in ("failed",) else 1


def cmd_serve(args) -> int:
    settings = _settings(args)
    from reqround.server import serve

    serve(args.host, args.port, str(settings.runs_dir))
    return 0


def cmd_list(args) -> int:
    settings = _settings(args)
    store = _store(settings)
    runs = store.list()
    if not runs:
        print("暂无运行。")
        return 0
    print(f"{'RUN ID':30} {'状态':18} {'轮次':6} {'版本':8} {'阻塞':4} 标题")
    for run in runs:
        metrics = run.get("metrics", {})
        print(
            f"{run.get('run_id',''):30} {str(run.get('status','')):18} "
            f"{str(run.get('round',0)) + '/' + str(run.get('max_rounds',0)):6} "
            f"{str(run.get('latest_version','')):8} {str(metrics.get('blocking_open','-')):4} {run.get('title','')}"
        )
    return 0


def cmd_show(args) -> int:
    settings = _settings(args)
    store = _store(settings)
    engine = Orchestrator.load(store, settings, args.run, client=MockClient() if _is_mock(store, args.run) else None)
    _print_state(_state_with_dir(store, engine))
    return 0


def _is_mock(store: RunStore, run_id: str) -> bool:
    run = store.load(run_id)
    return run.get("config", {}).get("client", {}).get("client") == "mock"


def cmd_answer(args) -> int:
    settings = _settings(args)
    store = _store(settings)
    engine = Orchestrator.load(store, settings, args.run, client=MockClient() if _is_mock(store, args.run) else None)
    record = engine.answer_question(args.oq, args.answer, by=args.by)
    print(f"已记录澄清 {record['clarification_id']} → {record['oq_id']}")
    print("执行 continue 进入下一轮（定稿轮）以纳入快照。")
    return 0


def cmd_continue(args) -> int:
    settings = _settings(args)
    store = _store(settings)
    engine = Orchestrator.load(store, settings, args.run, client=MockClient() if _is_mock(store, args.run) else None)
    state = engine.continue_run()
    _print_state(_state_with_dir(store, engine))
    return 0 if state.get("status") != "failed" else 1


def cmd_retry(args) -> int:
    settings = _settings(args)
    store = _store(settings)
    engine = Orchestrator.load(store, settings, args.run, client=MockClient() if _is_mock(store, args.run) else None)
    if args.local_moderator:
        engine.settings = replace(engine.settings, local_moderator=True)
    print("复用上一轮已保存的 Agent 发言，只重跑主持人综合 …")
    snapshot = engine.retry_failed_round()
    print(f"已恢复并发布 {snapshot.get('version')}")
    if args.only:
        store.update(args.run, lambda r: r.update({"status": "paused", "pause_reason": "重试完成，等待继续"}))
        print("已停在恢复版本；执行 continue 继续后续轮次。")
    else:
        engine.run_until_pause()
    _print_state(_state_with_dir(store, engine))
    return 0


def cmd_approve(args) -> int:
    settings = _settings(args)
    store = _store(settings)
    engine = Orchestrator.load(store, settings, args.run, client=MockClient() if _is_mock(store, args.run) else None)
    snapshot = engine.approve(by=args.by, note=args.note, accept_open=args.accept_open)
    print(f"已批准 {snapshot['version']}：{snapshot['project']['title']}")
    print(f"交接文件：{store.path(args.run, 'handoff.json')}")
    return 0


def cmd_export(args) -> int:
    settings = _settings(args)
    store = _store(settings)
    run = store.load(args.run)
    snapshot = store.load_snapshot(args.run, args.version)
    source = store.read_json(store.path(args.run, "source.json"))
    out_dir = Path(args.out or (settings.runs_dir / args.run / "exports"))
    out_dir.mkdir(parents=True, exist_ok=True)
    written = []
    if "md" in args.format:
        path = out_dir / f"需求快照_{snapshot['version']}.md"
        path.write_text(render_markdown(snapshot, source, run), encoding="utf-8")
        written.append(path)
    if "handoff" in args.format:
        handoff = build_handoff(snapshot, source, run)
        path = out_dir / "handoff.json"
        save_handoff(path, handoff, to_orchestrator_payload(handoff))
        written.append(path)
        written.append(out_dir / "handoff_orchestrator.json")
    for path in written:
        print(path)
    return 0


def cmd_demo(args) -> int:
    args.input = str(ROOT / "cases" / "lab_booking.md")
    args.title = args.title or "高校实验室设备预约管理系统"
    args.text = None
    return cmd_run(args)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="reqround", description="ReqRound 需求圆桌")
    parser.add_argument("--runs", default=None, help="运行目录，默认 ./runs")
    sub = parser.add_subparsers(dest="command", required=True)

    run = sub.add_parser("run", help="新建并运行一次需求圆桌")
    run.add_argument("--input", help="原始需求 Markdown/TXT 路径")
    run.add_argument("--text", help="直接给一段原始需求")
    run.add_argument("--title", default="", help="项目标题")
    run.add_argument("--max-rounds", type=int, default=None, help="讨论轮数上限（2-6，默认 4）")
    run.add_argument("--auto-assume", action="store_true", help="不暂停等人澄清，由主持人写默认假设")
    run.add_argument("--local", action="store_true", help="完全离线：本地规则 Agent + 本地规则综合（不需 API Key）")
    run.add_argument("--local-moderator", action="store_true", help="Agent 用真实模型，综合用本地规则（模型额度不足时的降级）")
    run.add_argument("--replay", default=None, help="回放一次真实运行的 Agent 发言（配合 --local-moderator）")
    run.add_argument("--mock", action="store_true", help="离线 mock 模型，仅测流程")
    run.add_argument("--json", action="store_true", help="结束时打印完整状态 JSON")
    run.add_argument("--quiet", action="store_true", help="不打印过程事件")
    run.set_defaults(func=cmd_run)

    demo = sub.add_parser("demo", help="用内置案例跑一次")
    demo.add_argument("--title", default="")
    demo.add_argument("--max-rounds", type=int, default=None)
    demo.add_argument("--auto-assume", action="store_true")
    demo.add_argument("--local", action="store_true")
    demo.add_argument("--local-moderator", action="store_true")
    demo.add_argument("--replay", default=None)
    demo.add_argument("--mock", action="store_true")
    demo.add_argument("--json", action="store_true")
    demo.add_argument("--quiet", action="store_true")
    demo.set_defaults(func=cmd_demo)

    serve = sub.add_parser("serve", help="启动网页与 API 服务")
    serve.add_argument("--host", default="127.0.0.1")
    serve.add_argument("--port", type=int, default=8770)
    serve.set_defaults(func=cmd_serve)

    listing = sub.add_parser("list", help="列出运行")
    listing.set_defaults(func=cmd_list)

    show = sub.add_parser("show", help="查看一次运行")
    show.add_argument("--run", required=True)
    show.set_defaults(func=cmd_show)

    answer = sub.add_parser("answer", help="回答待澄清项")
    answer.add_argument("--run", required=True)
    answer.add_argument("--oq", required=True)
    answer.add_argument("--answer", required=True)
    answer.add_argument("--by", default="user")
    answer.set_defaults(func=cmd_answer)

    cont = sub.add_parser("continue", help="继续下一轮")
    cont.add_argument("--run", required=True)
    cont.set_defaults(func=cmd_continue)

    retry = sub.add_parser("retry", help="失败后复用已保存发言，只重跑主持人")
    retry.add_argument("--run", required=True)
    retry.add_argument("--only", action="store_true", help="只恢复到当前版本，不继续后续轮次")
    retry.add_argument("--local-moderator", action="store_true", help="复用 Agent 发言，主持人改用本地规则综合")
    retry.set_defaults(func=cmd_retry)

    approve = sub.add_parser("approve", help="批准并冻结 v1.0")
    approve.add_argument("--run", required=True)
    approve.add_argument("--by", default="user")
    approve.add_argument("--note", default="")
    approve.add_argument("--accept-open", action="store_true")
    approve.set_defaults(func=cmd_approve)

    export = sub.add_parser("export", help="导出需求文档与交接包")
    export.add_argument("--run", required=True)
    export.add_argument("--version", default="latest")
    export.add_argument("--format", default="md,handoff")
    export.add_argument("--out", default=None)
    export.set_defaults(func=cmd_export)
    return parser


def main(argv: list[str] | None = None) -> int:
    _utf8()
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args) or 0)


if __name__ == "__main__":
    raise SystemExit(main())
